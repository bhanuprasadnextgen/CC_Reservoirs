import pytest

from app.utils.text_utils import (
    detect_language,
    detect_language_or_none,
    normalize_for_match,
    parse_reference_filename,
    parse_report_filename,
    slugify,
    split_sentences,
)


@pytest.mark.parametrize(
    "file_name, citation, year, key",
    [
        ("Hernandez et al., 2016, First sealant application in a multi-layered reservoir.pdf", "Hernandez et al., 2016", 2016, "hernandez"),
        ("Angulo Romero et al, 2023, Zonificaction del gradiente geotermico.pdf", "Angulo Romero et al., 2023", 2023, "angulo"),
        ("Collaguazo Lincango & Romero Figeroa 2011, Estudio del sistema.pdf", "Collaguazo Lincango & Romero Figeroa, 2011", 2011, "collaguazo"),
        ("Manoto Quilumba 2019, Estudio del sistema tipo jet instalado.pdf", "Manoto Quilumba, 2019", 2019, "manoto"),
        ("Omar, et al., 2011, Estudio sistema de bombeo - LAGO AGRIO.pdf", "Omar et al., 2011", 2011, "omar"),
        ("Ronquillo del Pozo, et al., 2009, Centralizacion del bombeo.pdf", "Ronquillo del Pozo et al., 2009", 2009, "ronquillo"),
        ("Estupifian et al, 2010,  Reservoir sandstones of the Cretaceous.pdf", "Estupifian et al., 2010", 2010, "estupifian"),
        ("Plúa Plúa & Rivas Segura 2018, Análisis y optimización.pdf", "Plúa Plúa & Rivas Segura, 2018", 2018, "plua"),
        ("Petroecuador, 2007, Informe Estadistico 1972-2006.pdf", "Petroecuador, 2007", 2007, "petroecuador"),
        ("Zarubezhneft, 2015-2020 Annual Reports.pdf", "Zarubezhneft, 2020", 2020, "zarubezhneft"),
    ],
)
def test_reference_filename_variants(file_name, citation, year, key):
    parsed = parse_reference_filename(file_name)
    assert parsed.citation == citation
    assert parsed.year == year
    assert parsed.first_author_key == key


def test_reference_title_drops_field_tag_and_keeps_year_in_title():
    assert parse_reference_filename("Calderon & Romero, 2012, Analysis tecnico - LAGO AGRIO.pdf").title == "Analysis tecnico"
    assert parse_reference_filename("Petroecuador, 2007, Informe Estadistico 1972-2006.pdf").title == "Informe Estadistico 1972-2006"


def test_unparseable_reference_falls_back_to_stem():
    parsed = parse_reference_filename("random notes.pdf")
    assert parsed.year is None and parsed.citation == "random notes"


@pytest.mark.parametrize(
    "file_name, field, reservoir, flag, year",
    [
        ("DAKS Lago Agrio N2020 Report.pdf", "Lago Agrio", None, "N", 2020),
        ("DAKS Lago Agrio_Upper Hollin U2026 Report.pdf", "Lago Agrio", "Upper Hollin", "U", 2026),
        ("DAKS Sulige_Shanxi-Lower Shihezi (P1s1-P2h8) U2026 Report.pdf", "Sulige", "Shanxi-Lower Shihezi (P1s1-P2h8)", "U", 2026),
        ("DAKS Sulige U2019 Report.pdf", "Sulige", None, "U", 2019),
    ],
)
def test_report_filename(file_name, field, reservoir, flag, year):
    parsed = parse_report_filename(file_name)
    assert (parsed.field_name, parsed.reservoir_name, parsed.flag, parsed.year) == (field, reservoir, flag, year)


def test_split_sentences_keeps_abbreviations_initials_and_decimals():
    text = "Found by Texaco et al. in 1967. Production began in May 1972 (Fig. 3). J. Smith noted 3.5 MMbbl. ¿Qué pasó? Fin."
    assert split_sentences(text) == [
        "Found by Texaco et al. in 1967.",
        "Production began in May 1972 (Fig. 3).",
        "J. Smith noted 3.5 MMbbl.",
        "¿Qué pasó?",
        "Fin.",
    ]


def test_detect_language():
    es = "El campo Lago Agrio fue descubierto en 1967 por la compañía Texaco y la producción comenzó en el año de 1972 con los pozos del área"
    en = "The Lago Agrio field was discovered in 1967 by Texaco and production began in 1972 from wells in the north of the basin which is"
    assert detect_language(es) == "es"
    assert detect_language(en) == "en"
    assert detect_language_or_none("too short") is None
    assert detect_language("too short") == "en"  # always en/es, never empty
    assert detect_language("too short", fallback="es") == "es"


def test_normalize_for_match_and_slugify():
    assert normalize_for_match("Producción  “comenzó” en reser-\n voir") == 'produccion "comenzo" en reservoir'
    assert slugify("South Ratqa") == "south-ratqa"
    assert slugify("Bach Ho") == "bach-ho"


def test_detect_chinese():
    assert detect_language("苏里格气田位于鄂尔多斯盆地北部，是中国最大的天然气田之一，储层为二叠系砂岩。") == "zh"
    mixed = "Sulige gas field 苏里格气田 " + "is located in the Ordos Basin and the reservoirs are tight sandstones of the Permian " * 3
    assert detect_language(mixed) == "en"  # mostly English with a Chinese name stays English
