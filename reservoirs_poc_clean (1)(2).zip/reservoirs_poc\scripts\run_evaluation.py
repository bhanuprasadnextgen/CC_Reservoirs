"""Evaluate the latest (or a given) analysis run against the later report version.

Usage:
  python -m scripts.run_evaluation "Lago Agrio"
  python -m scripts.run_evaluation "Lago Agrio" --run <run_id>
"""

from __future__ import annotations

import argparse
import sys

from app.config import get_settings
from app.utils.logging_config import setup_logging
from app.utils.text_utils import slugify
from app.workflows.evaluation_workflow import evaluate_run, to_markdown
from app.workflows.report_update_workflow import AnalysisServices, load_run


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("field")
    parser.add_argument("--run", dest="run_id")
    args = parser.parse_args()

    settings = get_settings()
    setup_logging(settings.app.log_level, settings.app.log_dir)
    svc = AnalysisServices.create(settings)
    run = load_run(svc.storage, settings, slugify(args.field), args.run_id)
    if run is None:
        print("No analysis run found — run `python -m scripts.run_analysis` first.")
        return 1
    print(to_markdown(evaluate_run(run, args.field, svc)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
