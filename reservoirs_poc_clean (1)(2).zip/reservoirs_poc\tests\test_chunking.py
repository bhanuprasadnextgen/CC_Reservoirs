from app.config import ChunkingSettings
from app.models import ReferenceCategory
from app.services.chunking_service import chunk_document, embedding_text
from app.services.report_parser import parse_sections
from app.utils.text_utils import split_sentences

from tests.conftest import make_source, sentence

SETTINGS = ChunkingSettings(words=100, overlap_words=20)


def _long_doc(b):
    b.heading("Introduction")
    for i in range(6):
        b.para(" ".join(sentence(15, f"a{i}s{j}_") for j in range(3)), page=1 + i // 3)
    b.heading("Conclusions")
    b.para(sentence(30, "c"), page=3)
    return b.build()


def test_chunks_never_cross_sections(doc_builder):
    chunks = chunk_document(_long_doc(doc_builder), make_source(), SETTINGS)
    by_section = {}
    for c in chunks:
        by_section.setdefault(c.section_title, []).append(c)
    assert set(by_section) == {"Introduction", "Conclusions"}
    assert all("c0" not in c.content for c in by_section["Introduction"])


def test_chunk_size_limit_and_whole_sentences(doc_builder):
    doc = _long_doc(doc_builder)
    chunks = chunk_document(doc, make_source(), SETTINGS)
    all_sentences = {s for p in doc.paragraphs for s in split_sentences(p.text)}
    for c in chunks:
        assert len(c.content.split()) <= SETTINGS.words * 1.2
        for s in split_sentences(c.content.replace("\n\n", " ")):
            assert s in all_sentences, f"cut sentence: {s!r}"


def test_overlap_is_sentence_aligned(doc_builder):
    chunks = [c for c in chunk_document(_long_doc(doc_builder), make_source(), SETTINGS) if c.section_title == "Introduction"]
    assert len(chunks) >= 2
    for prev, nxt in zip(chunks, chunks[1:]):
        last_sentence = split_sentences(prev.content.replace("\n\n", " "))[-1]
        assert nxt.content.startswith(last_sentence)


def test_pages_tracked(doc_builder):
    chunks = chunk_document(_long_doc(doc_builder), make_source(), SETTINGS)
    assert chunks[0].page_start == 1
    assert max(c.page_end for c in chunks) == 3


def test_tables_are_separate_and_split_with_header(doc_builder):
    rows = [[f"well-{i}", str(i * 10), "producing oil from hollin"] for i in range(60)]
    doc = doc_builder.heading("Data").para(sentence(10)).table(["Well", "BOPD", "Notes"], rows, caption="Table 1 - Wells").build()
    chunks = chunk_document(doc, make_source(), SETTINGS)
    table_chunks = [c for c in chunks if "| Well | BOPD | Notes |" in c.content]
    assert len(table_chunks) > 1
    for i, c in enumerate(table_chunks, start=1):
        assert c.content.startswith("Table: Table 1 - Wells")
        assert f"(part {i} of {len(table_chunks)})" in c.content
    covered = "".join(c.content for c in table_chunks)
    assert all(f"| well-{i} |" in covered for i in range(60))


def test_small_tail_folds_into_previous_chunk(doc_builder):
    doc = doc_builder.heading("Summary").para(" ".join([sentence(30, "x"), sentence(30, "y"), sentence(30, "z"), sentence(10, "t")])).build()
    chunks = chunk_document(doc, make_source(), SETTINGS)
    assert len(chunks) == 1  # 100 words + a 10-word tail stays one chunk


def test_ids_deterministic_and_metadata_carried(doc_builder):
    doc = _long_doc(doc_builder)
    src = make_source(document_id="abc", category=ReferenceCategory.UNUSED)
    first = chunk_document(doc, src, SETTINGS)
    second = chunk_document(doc, src, SETTINGS)
    assert [c.chunk_id for c in first] == [c.chunk_id for c in second]
    assert first[0].chunk_id == "abc-00000"
    assert all(c.category == ReferenceCategory.UNUSED and c.field_id == "lago-agrio" for c in first)


def test_report_chunks_follow_report_sections(doc_builder):
    doc = (
        doc_builder.heading("1. EXECUTIVE SUMMARY").para(sentence(20, "e"))
        .heading("8.1 PRODUCTION HISTORY").para(sentence(20, "p"))
        .heading("KEY REFERENCES").para("Smith, J., 2010, Something: Journal.")
        .build()
    )
    chunks = chunk_document(doc, make_source(category=ReferenceCategory.REPORT), SETTINGS, report_sections=parse_sections(doc))
    assert [c.section_id for c in chunks] == ["1", "8.1"]  # reference list is not indexed


def test_embedding_text_has_context_but_content_stays_raw(doc_builder):
    chunk = chunk_document(_long_doc(doc_builder), make_source(), SETTINGS)[0]
    text = embedding_text(chunk)
    assert text.startswith("Field: Lago Agrio | Source: Hernandez et al., 2016 | Section: Introduction\n")
    assert not chunk.content.startswith("Field:")


def test_language_is_per_passage_with_document_fallback(doc_builder):
    es = "El campo Lago Agrio fue descubierto en 1967 por la compañía Texaco y la producción comenzó en el año de 1972 con los pozos del área norte de la cuenca."
    en = "The Lago Agrio field was discovered in 1967 by Texaco and the production began in 1972 from the wells in the north of the basin which is large."
    doc = (
        doc_builder.heading("Abstract").para(en)
        .heading("Resumen").para(es)
        .heading("Datos").table(["Pozo", "BPPD"], [["LA-1", "300"]])
        .build()
    )
    chunks = chunk_document(doc, make_source(), SETTINGS)
    by_section = {c.section_title: c.language for c in chunks}
    assert by_section == {"Abstract": "en", "Resumen": "es", "Datos": "en"}  # table falls back to the document language
    assert all(c.language in ("en", "es") for c in chunks)


def test_unspaced_chinese_text_is_split_into_bounded_chunks(doc_builder):
    chinese = "苏里格气田位于鄂尔多斯盆地" * 400  # 5,200 characters, no spaces
    chunks = chunk_document(doc_builder.heading("概况").para(chinese).build(), make_source(), SETTINGS)
    assert len(chunks) > 1
    assert all(len(c.content) <= SETTINGS.words * 6 * 1.3 for c in chunks)
    assert "".join(c.content for c in chunks).count("苏里格") >= 400  # nothing lost


def test_embedding_input_is_kept_under_token_limit():
    from app.services.embedding_service import _MAX_TOKENS, _estimated_tokens, _fit

    assert _fit("short text") == "short text"
    assert _estimated_tokens(_fit("气" * 20_000)) <= _MAX_TOKENS
    assert _estimated_tokens(_fit("word " * 20_000)) <= _MAX_TOKENS
