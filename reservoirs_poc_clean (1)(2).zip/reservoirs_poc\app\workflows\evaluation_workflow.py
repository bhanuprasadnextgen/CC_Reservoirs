"""Evaluate an analysis run against the held-back (later) report version.

Ground truth = sentences in the later report that cite a New or Unused reference (i.e. information the
assistant could have found). Metrics:
- precision: share of suggestions the later report supports (LLM judge vs the most similar passages)
- false-recommendation rate: share the later report contradicts
- recall: share of ground-truth facts covered by at least one suggestion
- citation validity: share of model-cited evidence that passed quote verification
- cross-field leaks: evidence from another field (must be 0)
- regression checks: known SME decisions that must hold (e.g. Lago Agrio first production stays 1972)
"""

from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from typing import Literal

from pydantic import BaseModel

from app.models import AnalysisRun, ChangeType, Recommendation, RecommendedAction, ReferenceCategory, ReportRole, SectionKind
from app.prompts import load_prompt
from app.services.citation_validator import locate
from app.services.report_parser import cited_works, match_reference
from app.utils.logging_config import get_logger
from app.utils.text_utils import split_sentences
from app.workflows.ingestion_workflow import load_manifest, load_sections
from app.workflows.report_update_workflow import AnalysisServices

log = get_logger(__name__)

_EVIDENCE_CATEGORIES = {ReferenceCategory.NEW, ReferenceCategory.UNUSED}


class _PrecisionJudgement(BaseModel):
    verdict: Literal["supported", "contradicted", "absent"]
    justification: str


class _RecallJudgement(BaseModel):
    matched_suggestion: str | None
    justification: str


@dataclass
class GroundTruthFact:
    section_id: str
    sentence: str
    citations: list[str]


@dataclass
class EvaluationReport:
    field_id: str
    run_id: str
    ground_truth_report: str
    suggestions: int
    supported: int = 0
    contradicted: int = 0
    absent: int = 0
    ground_truth_facts: int = 0
    covered_facts: int = 0
    evidence_cited: int = 0
    evidence_verified: int = 0
    cross_field_leaks: int = 0
    ungrounded: int = 0
    regression: dict[str, bool] = field(default_factory=dict)
    by_section: dict[str, int] = field(default_factory=dict)
    details: list[dict] = field(default_factory=list)

    @property
    def precision(self) -> float | None:
        judged = self.supported + self.contradicted
        return self.supported / judged if judged else None

    @property
    def false_rate(self) -> float | None:
        return self.contradicted / self.suggestions if self.suggestions else None

    @property
    def recall(self) -> float | None:
        return self.covered_facts / self.ground_truth_facts if self.ground_truth_facts else None

    @property
    def citation_validity(self) -> float | None:
        return self.evidence_verified / self.evidence_cited if self.evidence_cited else None

    def to_dict(self) -> dict:
        data = asdict(self)
        data.update(precision=self.precision, false_rate=self.false_rate, recall=self.recall,
                    citation_validity=self.citation_validity)
        return data


# ----------------------------------------------------------------- regression checks


def _no_1969_start(recs: list[Recommendation]) -> bool:
    """Rod (7 Oct): Lago Agrio first production is 1972; Hernández et al. (2016) quoting 1969 is an error."""
    for r in recs:
        mentions = re.search(r"\b1969\b", r.proposed_text) and re.search(r"product|onstream|on-stream|stream", r.proposed_text, re.I)
        if mentions and r.recommended_action == RecommendedAction.APPLY and r.change_type != ChangeType.NEW_INFORMATION:
            return False
    return True


REGRESSION_CHECKS: dict[str, dict[str, Callable[[list[Recommendation]], bool]]] = {
    "lago-agrio": {"first production stays 1972 (not changed to 1969)": _no_1969_start},
}


# ------------------------------------------------------------------------ workflow


def evaluate_run(run: AnalysisRun, field_name: str, svc: AnalysisServices | None = None) -> EvaluationReport:
    svc = svc or AnalysisServices.create()
    settings = svc.settings
    truth = [v for v in svc.source.report_versions(field_name) if v.role == ReportRole.GROUND_TRUTH]
    if not truth:
        raise ValueError(f"No later report version for {field_name} to evaluate against")
    truth_report = truth[0]
    truth_sections = load_sections(svc.storage, settings, run.field_id, truth_report.report_id)
    if not truth_sections:
        raise ValueError("Later report not parsed yet — run ingestion for this field")

    references = [r.document for r in load_manifest(svc.storage, settings, run.field_id)
                  if r.document.category != ReferenceCategory.REPORT]
    report = EvaluationReport(
        field_id=run.field_id, run_id=run.run_id, ground_truth_report=truth_report.blob_path,
        suggestions=len(run.recommendations), ungrounded=len(run.ungrounded),
    )
    report.by_section = dict(Counter(r.section_id for r in run.recommendations))
    _citation_stats(run, report)
    report.regression = {name: check(run.recommendations) for name, check in REGRESSION_CHECKS.get(run.field_id, {}).items()}

    # Passages of the later report, embedded once for similarity lookups.
    passages = [
        (s.section_id, p.strip())
        for s in truth_sections if s.kind in (SectionKind.BODY, SectionKind.TABLES)
        for p in s.text.split("\n\n") if len(p.split()) >= 8
    ]
    passage_vecs = svc.embeddings.embed([p for _, p in passages]) if passages else []
    rec_vecs = svc.embeddings.embed([r.proposed_text for r in run.recommendations]) if run.recommendations else []

    # Precision
    p_prompt = load_prompt("eval_precision")
    for rec, vec in zip(run.recommendations, rec_vecs):
        top = _top_k(vec, passage_vecs, 3)
        later = "\n\n".join(f"[{passages[i][0]}] {passages[i][1]}" for i in top)
        # A conflict the assistant recommends keeping is judged on the text it keeps.
        outcome = rec.existing_text if rec.recommended_action == RecommendedAction.KEEP_EXISTING else rec.proposed_text
        judged = svc.llm.complete_json(
            p_prompt.text,
            f"SUGGESTION ({rec.change_type.value}, section {rec.section_id}, outcome the assistant recommends):\n{outcome}\n\nLATER REPORT:\n{later}",
            _PrecisionJudgement,
        )
        setattr(report, judged.verdict, getattr(report, judged.verdict) + 1)
        report.details.append({"kind": "suggestion", "section": rec.section_id, "type": rec.change_type.value,
                               "action": rec.recommended_action.value, "text": rec.proposed_text,
                               "verdict": judged.verdict, "why": judged.justification})

    # Recall
    current = [v for v in svc.source.report_versions(field_name) if v.role == ReportRole.CURRENT][0]
    current_text = "\n".join(s.text for s in load_sections(svc.storage, settings, run.field_id, current.report_id))
    facts = ground_truth_facts(truth_sections, references, current_text)
    report.ground_truth_facts = len(facts)
    r_prompt = load_prompt("eval_recall")
    fact_vecs = svc.embeddings.embed([f.sentence for f in facts]) if facts else []
    for fact, vec in zip(facts, fact_vecs):
        top = _top_k(vec, rec_vecs, 3)
        if not top:
            matched = None
            why = "no suggestions"
        else:
            s_ids = {f"S{n}": run.recommendations[i] for n, i in enumerate(top, start=1)}
            listing = "\n".join(f"[{sid}] {r.proposed_text}" for sid, r in s_ids.items())
            judged = svc.llm.complete_json(r_prompt.text, f"EXPECTED FACT:\n{fact.sentence}\n\nSUGGESTIONS:\n{listing}", _RecallJudgement)
            matched, why = (judged.matched_suggestion if judged.matched_suggestion in s_ids else None), judged.justification
        report.covered_facts += matched is not None
        report.details.append({"kind": "expected_fact", "section": fact.section_id, "text": fact.sentence,
                               "citations": fact.citations, "covered": matched is not None, "why": why})

    path = settings.blob.storage_path("runs", run.field_id, run.run_id, "evaluation.json")
    svc.storage.put_json(path, report.to_dict())
    svc.storage.put_bytes(path.replace(".json", ".md"), to_markdown(report).encode("utf-8"), "text/markdown")
    log.info("evaluation saved to %s", path)
    return report


def ground_truth_facts(sections, references, current_report_text: str = "") -> list[GroundTruthFact]:
    """Sentences of the later report that cite a New/Unused reference and are not already in the current report."""
    facts = []
    for s in sections:
        if s.kind != SectionKind.BODY:
            continue
        for sentence in split_sentences(s.text.replace("\n\n", " ")):
            docs = [match_reference(a, y, references) for a, y in cited_works(sentence)]
            new_sources = sorted({d.citation or d.file_name for d in docs if d and d.category in _EVIDENCE_CATEGORIES})
            if not new_sources:
                continue
            if current_report_text and locate(_strip_citations(sentence), current_report_text, 85):
                continue  # carried over from the current report — not a change
            facts.append(GroundTruthFact(s.section_id, sentence, new_sources))
    return facts


def _strip_citations(sentence: str) -> str:
    return re.sub(r"\([^()]*\b(?:19|20)\d{2}[^()]*\)", "", sentence).strip()


def _citation_stats(run: AnalysisRun, report: EvaluationReport) -> None:
    for rec in [*run.recommendations, *run.ungrounded]:
        dropped = [n for n in rec.validation_notes if n.startswith("Dropped evidence")]
        report.evidence_verified += len(rec.evidence)
        report.evidence_cited += len(rec.evidence) + len(dropped)
        report.cross_field_leaks += sum("another field" in n for n in dropped)


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def _top_k(query: list[float], vectors: list[list[float]], k: int) -> list[int]:
    scored = sorted(range(len(vectors)), key=lambda i: _cosine(query, vectors[i]), reverse=True)
    return scored[:k]


def _pct(x: float | None) -> str:
    return "n/a" if x is None else f"{x:.0%}"


def to_markdown(r: EvaluationReport) -> str:
    lines = [
        f"# Evaluation — {r.field_id} (run {r.run_id[:8]})",
        f"Compared with: `{r.ground_truth_report}`",
        "",
        "| Metric | Value |",
        "|---|---|",
        f"| Suggestions reviewed by judge | {r.suggestions} |",
        f"| Supported by later report | {r.supported} |",
        f"| Contradicted (false recommendations) | {r.contradicted} ({_pct(r.false_rate)}) |",
        f"| Not addressed by later report | {r.absent} |",
        f"| Precision (supported / judged) | {_pct(r.precision)} |",
        f"| Recall (expected facts covered) | {r.covered_facts}/{r.ground_truth_facts} ({_pct(r.recall)}) |",
        f"| Citation validity | {r.evidence_verified}/{r.evidence_cited} ({_pct(r.citation_validity)}) |",
        f"| Ungrounded suggestions (hidden from reviewers) | {r.ungrounded} |",
        f"| Cross-field leaks | {r.cross_field_leaks} |",
        "",
        "## Regression checks",
        *[f"- {'PASS' if ok else 'FAIL'} — {name}" for name, ok in r.regression.items()],
        "",
        "Note: later reports may cover a single reservoir while the updated report covers the whole field, "
        "so 'not addressed' is often a scope difference rather than an error.",
        "",
        "## Details",
    ]
    for d in r.details:
        if d["kind"] == "suggestion":
            lines.append(f"- **{d['verdict']}** · {d['section']} · {d['type']} · {d['text'][:200]} — _{d['why']}_")
        else:
            lines.append(f"- expected ({'covered' if d['covered'] else 'MISSED'}) · {d['section']} · {d['text'][:200]} — _{d['why']}_")
    return "\n".join(lines)
