"""Run "Find updates" from the command line.

Usage:
  python -m scripts.run_analysis "Lago Agrio"                       # whole report, new run
  python -m scripts.run_analysis "Lago Agrio" --sections 1,8.1      # only these sections, new run
  python -m scripts.run_analysis "Lago Agrio" --sections 8.1 --rerun --focus "production start date"
"""

from __future__ import annotations

import argparse
import sys

from app.config import get_settings
from app.utils.logging_config import setup_logging
from app.utils.text_utils import slugify
from app.workflows.report_update_workflow import AnalysisServices, load_run, run_analysis


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("field")
    parser.add_argument("--sections", help="Comma-separated section ids")
    parser.add_argument("--focus", help="Reviewer instruction for the re-check")
    parser.add_argument("--rerun", action="store_true", help="Replace these sections inside the latest run")
    args = parser.parse_args()

    settings = get_settings()
    setup_logging(settings.app.log_level, settings.app.log_dir)
    svc = AnalysisServices.create(settings)
    sections = [s.strip() for s in args.sections.split(",")] if args.sections else None
    base = load_run(svc.storage, settings, slugify(args.field)) if args.rerun else None

    run = run_analysis(
        args.field, section_ids=sections, instruction=args.focus, base_run=base, services=svc,
        progress=lambda sid, done, total: print(f"  [{done}/{total}] section {sid}"),
    )
    print(f"\nRun {run.run_id}: {len(run.recommendations)} suggestions, {len(run.ungrounded)} ungrounded, "
          f"{len(run.errors)} errors; {run.llm_calls} LLM calls, {run.llm_input_tokens + run.llm_output_tokens:,} tokens")
    for rec in run.recommendations:
        print(f"\n[{rec.section_id}] {rec.change_type.value} · {rec.recommended_action.value} · {rec.confidence.value}")
        if rec.existing_text:
            print(f"  existing: {rec.existing_text[:220]}")
        print(f"  proposed: {rec.proposed_text[:300]}")
        for e in rec.evidence:
            print(f"    ← {e.citation} ({e.category.value}, p.{e.page_start}): \"{e.quote[:140]}\"")
        for e in rec.key_evidence:
            print(f"    ⚿ {e.citation} (key, p.{e.page_start}): \"{e.quote[:140]}\"")
        if rec.verification_reasoning:
            print(f"  check: {rec.verification_reasoning[:300]}")
    for sid, note in run.section_notes.items():
        print(f"\n[{sid}] no change: {note[:200]}")
    for err in run.errors:
        print(f"\nERROR {err}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
