from __future__ import annotations

import html
from collections import Counter

import streamlit as st

from app.models import ChangeType, Evidence, RecommendedAction, ReviewStatus, SourcePosition, SourceStance
from app.services import evidence_viewer
from app.services.review_service import ReviewError
from app.ui import common

_ACTION_NOTES = {
    RecommendedAction.KEEP_EXISTING: (
        "warning",
        "The assistant checked the Key references and recommends **keeping the existing text**. "
        "Reject unless you have reason to prefer the new source.",
    ),
    RecommendedAction.REVIEW: ("info", "Evidence is balanced or thin — please open the sources before deciding."),
}

_PAGE_SIZE = 5

_STANCES = {
    SourceStance.SUPPORTS: ("✅ Supports", "supports", "support"),
    SourceStance.CONTRADICTS: ("⚠️ Contradicts", "contradicts", "contradict"),
    SourceStance.ADDS_DETAIL: ("➕ Adds detail", "adds detail", "add detail"),
    SourceStance.OLDER_VALUE: ("🕘 Older value", "gives an older value", "give older values"),
}


def render() -> None:
    st.header(f"{common.field_name()} — review changes")
    run = common.require_run()
    store = common.review_store()
    if run is None or store is None:
        return

    counts = store.counts()
    st.caption(
        f"{counts.get('pending', 0)} pending · {counts.get('approved', 0)} approved · {counts.get('rejected', 0)} rejected"
        + ("" if common.reviewer() else " · **enter your name in the sidebar to make decisions**")
    )

    tab_review, tab_audit = st.tabs(["Suggestions", "Audit trail"])
    with tab_review:
        _suggestions(store)
    with tab_audit:
        events = store.audit_events()
        st.dataframe(
            [
                {
                    "When (UTC)": f"{e.timestamp:%Y-%m-%d %H:%M:%S}",
                    "Reviewer": e.reviewer,
                    "Action": e.action.value,
                    "Recommendation": (e.recommendation_id or "")[:8],
                    "Comment": e.comment,
                }
                for e in reversed(events)
            ],
            hide_index=True,
            width="stretch",
        )


def _suggestions(store) -> None:
    run = store.run
    summary_id = common.summary_section_id()  # reviewed on the Final report page; older runs may still hold one
    section_ids = list(dict.fromkeys(r.section_id for r in run.recommendations if r.section_id != summary_id))
    titles = {r.section_id: r.section_title for r in run.recommendations}
    c1, c2, c3 = st.columns([2, 2, 2])
    section = c1.selectbox("Section", [None, *section_ids], format_func=lambda s: "All sections" if s is None else f"{s} {titles[s]}")
    ctype = c2.selectbox("Type", [None, *ChangeType], format_func=lambda t: "All types" if t is None else common.TYPE_LABELS[t.value])
    status = c3.selectbox("Status", [None, *ReviewStatus], format_func=lambda s: "All statuses" if s is None else s.value.title())

    items = [(r, s) for r, s in store.items(section_id=section, change_type=ctype, status=status) if r.section_id != summary_id]
    if not items:
        st.info("Nothing matches these filters.")
        return
    pages = (len(items) + _PAGE_SIZE - 1) // _PAGE_SIZE
    page = 1
    if pages > 1:
        left, right = st.columns([1, 4], vertical_alignment="bottom")
        page = left.selectbox("Page", range(1, pages + 1), key=f"page::{section}::{ctype}::{status}")
    first = (page - 1) * _PAGE_SIZE
    shown = items[first : first + _PAGE_SIZE]
    if pages > 1:
        right.caption(f"Showing {first + 1}–{first + len(shown)} of {len(items)} suggestions")
    _prefetch_sources(shown)
    for rec, state in shown:
        _card(store, rec, state)


def _card(store, rec, state) -> None:
    rid = rec.recommendation_id
    with st.container(border=True):
        badge = {"approved": "🟢 Approved", "rejected": "🔴 Rejected", "pending": "⚪ Pending"}[state.status.value]
        st.markdown(
            f"**{rec.section_id} {rec.section_title}** · {common.TYPE_LABELS[rec.change_type.value]} · {badge}"
            + (" (edited)" if state.edited else "")
            + (f" · {stance_summary(rec.source_comparison)}" if rec.source_comparison else "")
        )
        if rec.recommended_action in _ACTION_NOTES:
            kind, text = _ACTION_NOTES[rec.recommended_action]
            getattr(st, kind)(text)

        left, right = st.columns(2)
        with left:
            st.markdown("**Current report**")
            if rec.change_type == ChangeType.NEW_INFORMATION:
                st.caption("Addition — inserted after:" if rec.existing_text else "Addition — appended to the end of the section")
            st.markdown(f"> {rec.existing_text}" if rec.existing_text else "_—_")
        with right:
            st.markdown("**Suggested wording**")
            edited = st.text_area(
                "Suggested wording", value=state.final_text or rec.proposed_text, key=f"text::{rid}",
                label_visibility="collapsed", height=140, disabled=state.status != ReviewStatus.PENDING,
            )

        st.markdown(f"**Why:** {rec.rationale}")
        if rec.impact:
            st.caption(f"Impact: {rec.impact}")
        if rec.context_summary:
            st.markdown(f"**Context across sources:** {rec.context_summary}")
        if rec.verification_reasoning:
            st.markdown(f"**Checked against Key references:** {rec.verification_reasoning}")

        if rec.source_comparison:
            with st.expander(f"Source comparison ({len(rec.source_comparison)} sources)", expanded=True):
                _comparison(rec.source_comparison, key=f"view::{rid}::d")
        with st.expander(f"Supporting evidence ({len(rec.evidence)})", expanded=False):
            for i, ev in enumerate(rec.evidence):
                _evidence(ev, key=f"view::{rid}::e{i}")
        if rec.key_evidence:
            with st.expander(f"Key reference evidence ({len(rec.key_evidence)})"):
                for i, ev in enumerate(rec.key_evidence):
                    _evidence(ev, key=f"view::{rid}::k{i}")
        for note in rec.validation_notes:
            st.caption(f"ℹ {note}")

        _actions(store, rec, state, edited)


def stance_summary(positions: list[SourcePosition]) -> str:
    counts = Counter(p.stance for p in positions)
    return " · ".join(
        f"1 source {one}" if counts[s] == 1 else f"{counts[s]} sources {many}"
        for s, (_, one, many) in _STANCES.items() if counts[s]
    )


def comparison_table(positions: list[SourcePosition]) -> str:
    def cell(value: object) -> str:
        return " ".join(str(value or "").split()).replace("|", "\\|")

    rows = [
        f"| {cell(p.evidence.citation or p.evidence.file_name)} | {cell(p.evidence.publication_year)} | "
        f"{cell(common.CATEGORY_LABELS[p.evidence.category.value])} | {_STANCES[p.stance][0]} | {cell(p.states)} |"
        for p in positions
    ]
    return "\n".join(["| Source | Year | Type | Position | What it says |", "|---|---|---|---|---|", *rows])


def _comparison(positions: list[SourcePosition], key: str) -> None:
    order = list(_STANCES)
    ranked = sorted(positions, key=lambda p: (order.index(p.stance), -(p.evidence.publication_year or 0)))
    st.markdown(comparison_table(ranked))
    for i, p in enumerate(ranked):
        st.markdown(f"**{_STANCES[p.stance][0]}** — {p.states}")
        _evidence(p.evidence, key=f"{key}{i}")


def highlight_passage(passage: str, quote: str) -> str:
    out = html.escape(passage)
    for part in (p.strip() for p in quote.split(" … ")):
        escaped = html.escape(part)
        if escaped and escaped in out:
            out = out.replace(escaped, f"<mark>{escaped}</mark>", 1)
    return out.replace("\n", "<br>")


def _evidence(ev: Evidence, key: str) -> None:
    head, view = st.columns([6, 1], vertical_alignment="center")
    head.markdown(
        f"**{ev.citation}** · {common.CATEGORY_LABELS[ev.category.value]} · {common.pages(ev.page_start, ev.page_end)}  \n"
        f"<small>{ev.file_name}</small>",
        unsafe_allow_html=True,
    )
    if view.button("View", key=key, icon=":material/visibility:", help="Open the source page with this quote highlighted"):
        _view_source(ev)
    st.markdown(f"> {ev.quote}")
    if ev.translation:
        st.caption(f"Translation: {ev.translation}")
    if ev.passage and ev.passage.strip() != ev.quote.strip():
        st.markdown(
            "<details><summary><small>Show the surrounding passage</small></summary>"
            f"<div style='font-size:0.9em;opacity:0.9;padding:0.4em 0.8em;border-left:3px solid #06ACB7'>"
            f"{highlight_passage(ev.passage, ev.quote)}</div></details>",
            unsafe_allow_html=True,
        )
    if ev.verification_note:
        st.caption(ev.verification_note)


_PREFETCH_MAX_DOCUMENTS = 25


def _blob_paths() -> dict[str, str]:
    return {r.document.document_id: r.document.blob_path for r in common.manifest(common.field_id())}


def _prefetch_sources(items) -> None:
    """Start downloading the source PDFs of the listed suggestions in the background, in display order,
    so "View" opens instantly. Downloads continue across reruns and are shared by all sessions."""
    paths = _blob_paths()
    wanted = [
        paths[ev.document_id]
        for rec, _ in items
        for ev in (*rec.evidence, *rec.key_evidence, *(p.evidence for p in rec.source_comparison))
        if ev.document_id in paths
    ]
    common.pdf_cache().prefetch(list(dict.fromkeys(wanted))[:_PREFETCH_MAX_DOCUMENTS])


@st.dialog("Source document", width="large")
def _view_source(ev: Evidence) -> None:
    st.markdown(f"**{ev.citation}** · {common.pages(ev.page_start, ev.page_end)}  \n<small>{ev.file_name}</small>",
                unsafe_allow_html=True)
    blob_path = _blob_paths().get(ev.document_id)
    if blob_path is None:
        st.error("This document is not in the field's ingestion manifest.")
        return
    cache = common.pdf_cache()
    try:
        message = "Opening the document…" if cache.is_cached(blob_path) else "Downloading the document — large PDFs can take a minute…"
        with st.spinner(message):
            pdf = cache.get(blob_path)
            last = evidence_viewer.page_count(pdf)
            first = min(max(ev.page_start or 1, 1), last)
            numbers = list(range(first, min(max(ev.page_end or first, first), last) + 1))
            words = evidence_viewer.pdf_page_words(pdf, numbers)
            boxes = evidence_viewer.find_boxes(words, numbers, ev.quote)
        if not boxes and not any(words[n]["words"] for n in numbers):
            # Scanned page: no text layer, so use the word positions from ingestion (slower download).
            with st.spinner("Scanned page — loading text positions…"):
                words = common.page_words(common.field_id(), ev.document_id)
                boxes = evidence_viewer.find_boxes(words, numbers, ev.quote)
    except Exception as err:  # the reviewer should still see the evidence card if the PDF can't be opened
        st.error(f"Could not open the document: {type(err).__name__}: {err}")
        return

    if not boxes:
        st.warning("The quoted text could not be pinpointed on the page; showing the cited page(s).")
    try:
        st.link_button("Open full PDF", f"{common.services().source.sas_url(blob_path)}#page={first}",
                       icon=":material/open_in_new:")
    except Exception:  # SAS links need an account-key connection string
        pass
    for number in numbers:
        png = evidence_viewer.render_page(pdf, number, words.get(number), boxes.get(number, []))
        st.image(png, caption=f"Page {number} of {last}", width="stretch")


def _actions(store, rec, state, edited_text: str) -> None:
    rid = rec.recommendation_id
    who = common.reviewer()
    try:
        if state.status == ReviewStatus.PENDING:
            a, b, c = st.columns([1, 3, 1])
            if a.button("Approve", key=f"approve::{rid}", type="primary", disabled=not who):
                store.approve(rid, who, final_text=edited_text)
                st.rerun()
            reason = b.text_input("Reason for rejecting", key=f"reason::{rid}", placeholder="Required to reject", label_visibility="collapsed")
            if c.button("Reject", key=f"reject::{rid}", disabled=not who or not reason.strip()):
                store.reject(rid, who, comment=reason)
                st.rerun()
        else:
            a, b = st.columns([1, 4])
            if state.comment:
                b.caption(f"{state.reviewer}: {state.comment}")
            if a.button("Undo", key=f"undo::{rid}", disabled=not who):
                store.undo(rid, who)
                st.rerun()
    except ReviewError as err:
        st.error(str(err))
