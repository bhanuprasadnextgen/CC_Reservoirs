"""Create the search index (no-op if it already exists).

Usage:  python -m scripts.create_index
"""

from __future__ import annotations

from app.config import get_settings
from app.services.search_service import SearchService
from app.utils.logging_config import setup_logging


def main() -> None:
    settings = get_settings()
    setup_logging(settings.app.log_level)
    index = SearchService(settings).ensure_index()
    print(f"Index '{index.name}'")
    for f in index.fields:
        flags = [n for n in ("key", "filterable", "searchable", "sortable", "facetable") if getattr(f, n, False)]
        dims = f" dims={f.vector_search_dimensions}" if f.vector_search_dimensions else ""
        print(f"  {f.name:18} {str(f.type):28} {','.join(flags)}{dims}")
    print(f"  semantic config: {'yes' if index.semantic_search else 'no'}")


if __name__ == "__main__":
    main()
