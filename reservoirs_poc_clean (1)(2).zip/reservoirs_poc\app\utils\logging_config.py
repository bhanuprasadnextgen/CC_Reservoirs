"""Logging setup: console + rotating file, with an optional run_id on every line."""

from __future__ import annotations

import logging
import logging.handlers
from contextvars import ContextVar
from pathlib import Path

_run_id: ContextVar[str] = ContextVar("run_id", default="-")

_FORMAT = "%(asctime)s %(levelname)-7s [%(run_id)s] %(name)s: %(message)s"

# Azure SDKs log every HTTP request at INFO; keep them quiet unless debugging.
_NOISY_LOGGERS = (
    "azure.core.pipeline.policies.http_logging_policy",
    "azure.identity",
    "httpx",
    "httpx2",
    "openai",
    "anthropic",
)

_configured = False


class _RunIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.run_id = _run_id.get()
        return True


def set_run_id(run_id: str) -> None:
    """Tag subsequent log lines in this context with an analysis run ID."""
    _run_id.set(run_id)


def setup_logging(level: str = "INFO", log_dir: Path | None = None) -> None:
    """Configure the root logger once. Safe to call repeatedly (e.g. on Streamlit reruns)."""
    global _configured
    if _configured:
        return

    root = logging.getLogger()
    root.setLevel(level.upper())
    formatter = logging.Formatter(_FORMAT)
    run_filter = _RunIdFilter()

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.addFilter(run_filter)
    root.addHandler(console)

    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            log_dir / "reservoirs_poc.log", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
        )
        file_handler.setFormatter(formatter)
        file_handler.addFilter(run_filter)
        root.addHandler(file_handler)

    for name in _NOISY_LOGGERS:
        logging.getLogger(name).setLevel(logging.WARNING)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
