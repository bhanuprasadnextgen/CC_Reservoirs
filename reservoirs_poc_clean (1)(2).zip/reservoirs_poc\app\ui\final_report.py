from __future__ import annotations

import streamlit as st

from app.services.report_export_service import build_docx, publish
from app.ui import common, review
from app.workflows.report_update_workflow import draft_executive_summary


def render() -> None:
    st.header(f"{common.field_name()} — final report")
    run = common.require_run()
    store = common.review_store()
    report = common.current_report()
    if run is None or store is None or report is None:
        return

    counts = store.counts()
    pending = counts.get("pending", 0)
    st.caption(f"{counts.get('approved', 0)} approved · {counts.get('rejected', 0)} rejected · {pending} pending")
    if pending:
        st.info(f"{pending} suggestion(s) are still pending; they will not be included.")

    approved = store.approved_changes()
    st.subheader("Approved changes")
    if not approved:
        st.write("No changes approved yet.")
    for rec, state in approved:
        with st.container(border=True):
            st.markdown(f"**{rec.section_id} {rec.section_title}** · {common.TYPE_LABELS[rec.change_type.value]}"
                        + (" · edited" if state.edited else "") + f" · by {state.reviewer}")
            st.markdown(f":orange-background[{state.final_text}]")

    st.divider()
    _executive_summary(run, store, approved)

    st.divider()
    svc = common.services()
    if st.button("Generate Word document", type="primary"):
        secs = common.sections(common.field_id(), report.report_id)
        st.session_state["docx"] = build_docx(common.field_name(), report, secs, store)
    data = st.session_state.get("docx")
    if data:
        file_name = f"{common.field_name()} {report.year} report - updated draft.docx"
        st.download_button("Download .docx", data, file_name=file_name,
                           mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        if st.button("Save version to Blob Storage", disabled=not common.reviewer()):
            path = publish(svc.storage, svc.settings, store, report, data, common.reviewer())
            st.success(f"Saved as `{path}` and recorded in the audit trail.")


def _executive_summary(run, store, approved) -> None:
    """Draft the executive summary from the approved changes, then review it here like any other change."""
    st.subheader("Executive summary")
    st.caption(
        "Drafted from the approved changes above, so the summary reflects them. Review it here: only an approved "
        "summary goes into the Word document."
    )
    item = store.summary_item()
    if item and store.summary_is_stale():
        st.warning("The approved changes have changed since this summary was drafted — draft it again.")

    label = "Draft executive summary again" if item else "Draft executive summary"
    if st.button(label, type="primary" if not item else "secondary", disabled=not approved or not common.reviewer(),
                 help=None if approved else "Approve changes in Review changes first"):
        with st.spinner("Drafting the executive summary from the approved changes…"):
            note = draft_executive_summary(common.field_name(), run, approved, common.services())
        common.set_run(run)  # new review store, so the new draft starts as pending
        st.session_state.pop("docx", None)
        if note:
            st.session_state["summary_note"] = note
        st.rerun()
    if note := st.session_state.pop("summary_note", None):
        st.info(note)

    if item:
        review._card(store, *item)
    elif not approved:
        st.write("Approve changes in **Review changes** first; the summary is drafted from them.")
