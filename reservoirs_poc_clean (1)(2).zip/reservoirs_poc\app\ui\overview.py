from __future__ import annotations

from collections import Counter
from pathlib import PurePosixPath

import streamlit as st

from app.models import IngestionStatus, ReferenceCategory, SectionKind
from app.services.report_parser import analysable
from app.ui import common


def render() -> None:
    st.header(f"{common.field_name()} — overview")
    report = common.current_report()
    if report is None:
        st.error("No report PDF found in this field folder.")
        return

    held_back = common.ground_truth_report()
    st.markdown(
        f"**Report being updated:** {PurePosixPath(report.blob_path).name}  \n"
        + (f"**Held back for evaluation (not searched):** {PurePosixPath(held_back.blob_path).name}" if held_back else "")
    )

    records = common.manifest(common.field_id())
    if not records:
        st.warning(
            "This field has not been ingested yet. Run:\n\n"
            f'`python -m scripts.ingest_field "{common.field_name()}"`'
        )
        return

    refs = [r for r in records if r.document.category != ReferenceCategory.REPORT]
    cols = st.columns(4)
    for col, category in zip(cols, (ReferenceCategory.NEW, ReferenceCategory.UNUSED, ReferenceCategory.KEY)):
        in_cat = [r for r in refs if r.document.category == category]
        indexed = sum(r.status == IngestionStatus.INDEXED for r in in_cat)
        col.metric(common.CATEGORY_PLURALS[category.value], len(in_cat), f"{indexed} searchable", delta_color="off")
    status = Counter(r.status.value for r in refs)
    cols[3].metric("Skipped / failed", status.get("skipped", 0) + status.get("failed", 0))

    searched = ", ".join(common.CATEGORY_PLURALS[c.value] for c in common.services().settings.analysis.search_categories)
    st.caption(
        f"The assistant searches **{searched}** for new information, and uses **Key references** "
        "to verify where the report's existing figures came from when a conflict is found."
    )

    st.subheader("Report sections the assistant checks")
    secs = common.sections(common.field_id(), report.report_id)
    if not secs:
        st.warning("The report has not been parsed yet — re-run ingestion.")
        return
    rows = [
        {
            "Section": s.section_id if s.kind == SectionKind.BODY else "—",
            "Title": s.title,
            "Words": len(s.text.split()),
            "Pages": common.pages(s.page_start, s.page_end),
        }
        for s in analysable(secs)
    ]
    st.dataframe(rows, hide_index=True, width="stretch")
