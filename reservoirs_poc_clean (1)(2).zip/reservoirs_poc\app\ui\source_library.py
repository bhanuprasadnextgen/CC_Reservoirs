from __future__ import annotations

import streamlit as st

from app.models import ReferenceCategory
from app.ui import common


def render() -> None:
    st.header(f"{common.field_name()} — source library")
    records = common.manifest(common.field_id())
    if not records:
        st.info("No documents ingested for this field yet.")
        return

    options = [ReferenceCategory.NEW, ReferenceCategory.UNUSED, ReferenceCategory.KEY, ReferenceCategory.REPORT]
    chosen = st.pills(
        "Show", options, selection_mode="multi", default=options[:3],
        format_func=lambda c: common.CATEGORY_PLURALS[c.value],
    )
    rows = [
        {
            "Category": common.CATEGORY_LABELS[r.document.category.value],
            "Citation": r.document.citation,
            "Title": r.document.title,
            "Year": r.document.publication_year,
            "Language": r.document.language,
            "Pages": r.document.page_count,
            "Status": r.status.value,
            "Passages": r.chunk_count or None,
            "Note": r.reason,
            "File": r.document.file_name,
        }
        for r in sorted(records, key=lambda r: (r.document.category.value, r.document.file_name))
        if r.document.category in (chosen or [])
    ]
    st.dataframe(rows, hide_index=True, width="stretch")

    report = common.current_report()
    if report:
        # Only citations traced to a report section; ones found only in the reference list are left out.
        cites = [c for c in common.citations(common.field_id(), report.report_id) if any(s != "REF" for s in c.section_ids)]
        if cites:
            st.subheader("Citations in the current report")
            st.caption("Used to trace where an existing statement came from when a new source disagrees. "
                       "Only citations found in the report's sections are listed.")
            by_id = {r.document.document_id: r.document for r in records}
            st.dataframe(
                [
                    {
                        "Cited as": c.citation,
                        "Sections": ", ".join(s for s in c.section_ids if s != "REF"),
                        "Linked file": by_id[c.document_id].file_name if c.document_id in by_id else "— not provided",
                        "Folder": common.CATEGORY_LABELS[by_id[c.document_id].category.value] if c.document_id in by_id else "",
                    }
                    for c in cites
                ],
                hide_index=True,
                width="stretch",
            )
