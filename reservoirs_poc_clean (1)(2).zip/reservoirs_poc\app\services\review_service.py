"""Human review: approve / edit / reject / undo / comment, with an append-only audit trail.

State:  poc-fresh/runs/<field_id>/<run_id>/review.json   — per recommendation, a history of states (undo pops)
Audit:  poc-fresh/audit/<field_id>/<run_id>.jsonl          — append-only; never rewritten
"""

from __future__ import annotations

from collections import Counter

from app.config import Settings
from app.models import (
    AnalysisRun,
    AuditAction,
    AuditEvent,
    ChangeType,
    Recommendation,
    ReviewState,
    ReviewStatus,
    _utcnow,
)
from app.services.blob_service import StorageRepository


class ReviewError(ValueError):
    pass


class ReviewStore:
    def __init__(self, storage: StorageRepository, settings: Settings, run: AnalysisRun) -> None:
        self._storage = storage
        self._run = run
        self._state_path = settings.blob.storage_path("runs", run.field_id, run.run_id, "review.json")
        self._audit_path = settings.blob.storage_path("audit", run.field_id, f"{run.run_id}.jsonl")
        self._recs = {r.recommendation_id: r for r in run.recommendations}
        if run.executive_summary is not None:
            self._recs[run.executive_summary.recommendation_id] = run.executive_summary
        raw = storage.get_json(self._state_path) or {}
        self._history: dict[str, list[ReviewState]] = {
            rec_id: [ReviewState.model_validate(s) for s in states] for rec_id, states in raw.items()
        }

    # ------------------------------------------------------------------ queries

    @property
    def run(self) -> AnalysisRun:
        return self._run

    def recommendation(self, rec_id: str) -> Recommendation:
        try:
            return self._recs[rec_id]
        except KeyError:
            raise ReviewError(f"Unknown recommendation {rec_id}") from None

    def state(self, rec_id: str) -> ReviewState:
        history = self._history.get(rec_id)
        return history[-1] if history else ReviewState(recommendation_id=rec_id)

    def can_undo(self, rec_id: str) -> bool:
        return bool(self._history.get(rec_id))

    def items(
        self,
        section_id: str | None = None,
        change_type: ChangeType | None = None,
        status: ReviewStatus | None = None,
    ) -> list[tuple[Recommendation, ReviewState]]:
        out = []
        for rec in self._run.recommendations:
            st = self.state(rec.recommendation_id)
            if section_id and rec.section_id != section_id:
                continue
            if change_type and rec.change_type != change_type:
                continue
            if status and st.status != status:
                continue
            out.append((rec, st))
        return out

    def approved(self) -> list[tuple[Recommendation, ReviewState]]:
        """Approved section changes, plus the executive summary (first) once it is approved."""
        summary = self.summary_item()
        head = [summary] if summary and summary[1].status == ReviewStatus.APPROVED else []
        return head + self.items(status=ReviewStatus.APPROVED)

    def approved_changes(self) -> list[tuple[Recommendation, ReviewState]]:
        """Approved section changes only — the input for drafting the executive summary."""
        return self.items(status=ReviewStatus.APPROVED)

    def summary_item(self) -> tuple[Recommendation, ReviewState] | None:
        summary = self._run.executive_summary
        return (summary, self.state(summary.recommendation_id)) if summary else None

    def summary_is_stale(self) -> bool:
        """The approved changes differ from the ones the executive summary was drafted from."""
        current = {r.recommendation_id for r, _ in self.approved_changes()}
        return self._run.executive_summary is not None and current != set(self._run.executive_summary_basis)

    def counts(self) -> Counter:
        return Counter(self.state(r.recommendation_id).status.value for r in self._run.recommendations)

    def audit_events(self) -> list[AuditEvent]:
        return [AuditEvent.model_validate(e) for e in self._storage.read_jsonl(self._audit_path)]

    # ------------------------------------------------------------------ actions

    def approve(self, rec_id: str, reviewer: str, final_text: str | None = None, comment: str | None = None) -> ReviewState:
        rec = self.recommendation(rec_id)
        reviewer = self._reviewer(reviewer)
        text = (final_text if final_text is not None else rec.proposed_text).strip()
        if not text:
            raise ReviewError("Approved text cannot be empty — reject the recommendation instead.")
        edited = text != rec.proposed_text.strip()
        if edited:
            self._audit(AuditAction.EDIT, rec_id, reviewer, comment, rec.proposed_text, text)
        self._audit(AuditAction.APPROVE, rec_id, reviewer, comment, rec.existing_text, text)
        return self._push(
            ReviewState(
                recommendation_id=rec_id, status=ReviewStatus.APPROVED, final_text=text, edited=edited,
                reviewer=reviewer, comment=comment,
            )
        )

    def reject(self, rec_id: str, reviewer: str, comment: str) -> ReviewState:
        rec = self.recommendation(rec_id)
        reviewer = self._reviewer(reviewer)
        # AuditEvent itself refuses a rejection without a reason.
        self._audit(AuditAction.REJECT, rec_id, reviewer, comment, rec.proposed_text, None)
        return self._push(
            ReviewState(recommendation_id=rec_id, status=ReviewStatus.REJECTED, reviewer=reviewer, comment=comment)
        )

    def undo(self, rec_id: str, reviewer: str) -> ReviewState:
        self.recommendation(rec_id)
        reviewer = self._reviewer(reviewer)
        history = self._history.get(rec_id)
        if not history:
            raise ReviewError("Nothing to undo.")
        undone = history.pop()
        self._audit(
            AuditAction.UNDO, rec_id, reviewer, f"Undid '{undone.status.value}' by {undone.reviewer}",
            undone.final_text, None,
        )
        self._save()
        return self.state(rec_id)

    def comment(self, rec_id: str, reviewer: str, comment: str) -> None:
        self.recommendation(rec_id)
        if not comment.strip():
            raise ReviewError("Comment is empty.")
        self._audit(AuditAction.COMMENT, rec_id, self._reviewer(reviewer), comment, None, None)

    def record_publish(self, reviewer: str, output_path: str) -> None:
        self._audit(AuditAction.PUBLISH, None, self._reviewer(reviewer), f"Published {output_path}", None, output_path)

    # ------------------------------------------------------------------ internals

    @staticmethod
    def _reviewer(name: str) -> str:
        if not name or not name.strip():
            raise ReviewError("Enter a reviewer name before making review decisions.")
        return name.strip()

    def _push(self, state: ReviewState) -> ReviewState:
        state = state.model_copy(update={"updated_at": _utcnow()})
        self._history.setdefault(state.recommendation_id, []).append(state)
        self._save()
        return state

    def _save(self) -> None:
        self._storage.put_json(
            self._state_path,
            {rid: [s.model_dump(mode="json") for s in states] for rid, states in self._history.items() if states},
        )

    def _audit(
        self,
        action: AuditAction,
        rec_id: str | None,
        reviewer: str,
        comment: str | None,
        before: str | None,
        after: str | None,
    ) -> None:
        event = AuditEvent(
            run_id=self._run.run_id, recommendation_id=rec_id, action=action, reviewer=reviewer,
            comment=comment, text_before=before, text_after=after,
        )
        self._storage.append_jsonl(self._audit_path, event.model_dump(mode="json"))
