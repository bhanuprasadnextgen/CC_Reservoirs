"""Ingest a field into the search index.

Usage:
  python -m scripts.ingest_field "Lago Agrio" --dry-run
  python -m scripts.ingest_field "Lago Agrio" --limit 3
  python -m scripts.ingest_field "Lago Agrio" --categories new,unused
  python -m scripts.ingest_field --all
"""

from __future__ import annotations

import argparse
import sys

from app.config import get_settings
from app.models import IngestionRecord, ReferenceCategory
from app.utils.logging_config import setup_logging
from app.workflows.ingestion_workflow import IngestionServices, ingest_field


def _print_records(records: list[IngestionRecord]) -> None:
    for r in sorted(records, key=lambda r: (r.document.category.value, r.document.file_name)):
        d = r.document
        extra = f"{r.chunk_count} chunks" if r.chunk_count else (r.reason or "")
        print(f"  {d.category.value:7} {r.status.value:9} {(d.citation or '')[:40]:40} {d.file_name[:55]:55} {extra}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("field", nargs="?", help='Field folder name, e.g. "Lago Agrio"')
    parser.add_argument("--all", action="store_true", help="Ingest every field folder")
    parser.add_argument("--categories", help="Comma-separated subset: new,unused,key (reports always included)")
    parser.add_argument("--limit", type=int, help="Process at most N documents this run")
    parser.add_argument("--dry-run", action="store_true", help="List and classify files only")
    parser.add_argument("--reindex", action="store_true", help="Re-chunk and re-index already indexed documents")
    args = parser.parse_args()

    settings = get_settings()
    setup_logging(settings.app.log_level, settings.app.log_dir)
    services = IngestionServices.create(settings)
    fields = services.source.list_fields() if args.all else [args.field] if args.field else []
    if not fields:
        parser.error("give a field name or --all")
    categories = [ReferenceCategory(c.strip()) for c in args.categories.split(",")] if args.categories else None

    for name in fields:
        print(f"\n=== {name}")
        result = ingest_field(
            name,
            categories=categories,
            limit=args.limit,
            dry_run=args.dry_run,
            reindex=args.reindex,
            services=services,
            progress=lambda rec, done, total: print(f"  [{done}/{total}] {rec.status.value:9} {rec.document.file_name}"),
        )
        for v in result.reports:
            print(f"  report {v.role.value:12} {v.report_id:20} {v.blob_path}")
        if args.dry_run:
            _print_records(result.records)
        print(f"  totals: {dict(result.counts)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
