"""LLM access behind one interface: `complete_json(system, user, schema) -> schema instance`.

Azure OpenAI (default) uses the Responses API with strict structured output.
Anthropic is available behind the same interface when LLM_PROVIDER=anthropic.
"""

from __future__ import annotations

import json
import random
import threading
import time
from dataclasses import dataclass
from typing import Protocol, TypeVar

from openai import APIConnectionError, APITimeoutError, InternalServerError, RateLimitError
from pydantic import BaseModel

from app.config import Settings
from app.services.embedding_service import azure_openai_client
from app.utils.logging_config import get_logger

log = get_logger(__name__)

T = TypeVar("T", bound=BaseModel)

_MIN_RATE_LIMIT_WAIT = 20  # the shared deployment's token window is 60 s; short hints just re-trigger 429s
_MAX_SINGLE_WAIT = 90

class LLMError(RuntimeError):
    pass


@dataclass
class Usage:
    calls: int = 0
    input_tokens: int = 0
    output_tokens: int = 0

    def add(self, input_tokens: int, output_tokens: int) -> None:
        self.calls += 1
        self.input_tokens += input_tokens
        self.output_tokens += output_tokens


class LLMClient(Protocol):
    model_name: str
    usage: Usage

    def complete_json(self, system: str, user: str, schema: type[T]) -> T: ...


def _retry_after(err: Exception) -> float | None:
    response = getattr(err, "response", None)
    value = response.headers.get("retry-after") if response is not None else None
    try:
        return float(value) if value else None
    except ValueError:
        return None


def _with_retries(call, what: str, budget_seconds: float):
    """Retry transient failures until `budget_seconds` is spent, honouring Retry-After on 429."""
    deadline = time.monotonic() + budget_seconds
    attempt = 0
    while True:
        attempt += 1
        try:
            return call()
        except (RateLimitError, APIConnectionError, APITimeoutError, InternalServerError) as err:
            hinted = _retry_after(err) or 0
            floor = _MIN_RATE_LIMIT_WAIT if isinstance(err, RateLimitError) else 2
            wait = min(_MAX_SINGLE_WAIT, max(hinted, floor, 2 ** min(attempt, 6))) + random.uniform(0, 5)
            if time.monotonic() + wait > deadline:
                raise
            log.warning("%s: %s (attempt %d), retrying in %.0fs", what, type(err).__name__, attempt, wait)
            time.sleep(wait)


class AzureOpenAIClient:
    def __init__(self, settings: Settings) -> None:
        self._client = azure_openai_client(settings)
        self.model_name = settings.aoai.chat_deployment
        self._effort = settings.llm.reasoning_effort
        self._max_output = settings.llm.max_output_tokens
        self._retry_budget = settings.llm.retry_budget_seconds
        self.usage = Usage()
        self._lock = threading.Lock()

    def complete_json(self, system: str, user: str, schema: type[T]) -> T:
        def call():
            return self._client.responses.parse(
                model=self.model_name,
                instructions=system,
                input=user,
                text_format=schema,
                reasoning={"effort": self._effort},
                max_output_tokens=self._max_output,
                store=False,
            )

        response = _with_retries(call, f"{self.model_name}/{schema.__name__}", self._retry_budget)
        if response.usage:
            with self._lock:
                self.usage.add(response.usage.input_tokens, response.usage.output_tokens)
        parsed = response.output_parsed
        if parsed is None:
            raise LLMError(f"{schema.__name__}: model returned no parseable output (status={response.status})")
        return parsed


class AnthropicClient:
    """Claude via Azure AI Foundry (or the Anthropic API). JSON is forced through a single tool."""

    def __init__(self, settings: Settings) -> None:
        import anthropic

        self._client = anthropic.Anthropic(
            api_key=settings.anthropic.api_key, base_url=settings.anthropic.base_url or None, max_retries=0
        )
        self.model_name = settings.anthropic.model
        self._max_output = settings.llm.max_output_tokens
        self._retry_budget = settings.llm.retry_budget_seconds
        self.usage = Usage()
        self._lock = threading.Lock()

    def complete_json(self, system: str, user: str, schema: type[T]) -> T:
        import anthropic

        tool = {"name": "submit", "description": "Return the result.", "input_schema": schema.model_json_schema()}

        def call():
            try:
                return self._client.messages.create(
                    model=self.model_name,
                    system=system,
                    messages=[{"role": "user", "content": user}],
                    tools=[tool],
                    tool_choice={"type": "tool", "name": "submit"},
                    max_tokens=self._max_output,
                )
            except anthropic.RateLimitError as err:  # map to the shared retry path
                raise RateLimitError(str(err), response=err.response, body=None) from err

        message = _with_retries(call, f"{self.model_name}/{schema.__name__}", self._retry_budget)
        with self._lock:
            self.usage.add(message.usage.input_tokens, message.usage.output_tokens)
        for block in message.content:
            if block.type == "tool_use":
                return schema.model_validate(block.input)
        raise LLMError(f"{schema.__name__}: no tool output in response: {json.dumps([b.type for b in message.content])}")


def create_llm_client(settings: Settings) -> LLMClient:
    if settings.llm.provider == "anthropic":
        return AnthropicClient(settings)
    return AzureOpenAIClient(settings)
