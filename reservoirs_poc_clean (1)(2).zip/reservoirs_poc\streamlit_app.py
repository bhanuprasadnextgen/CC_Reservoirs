"""Reservoir Report Update Assistant — Streamlit entry point.

Run:  streamlit run streamlit_app.py
"""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from app.config import get_settings
from app.ui import common, final_report, find_updates, overview, review, source_library
from app.utils.logging_config import setup_logging

st.set_page_config(page_title="Reservoir Report Update Assistant", page_icon="🛢️", layout="wide")
_settings = get_settings()
setup_logging(_settings.app.log_level, _settings.app.log_dir)
st.logo(str(Path(__file__).parent / "app" / "assets" / "logo.png"), size="large")

with st.sidebar:
    st.markdown("### Reservoir Report Update Assistant")
    fields = common.list_fields()
    st.selectbox("Field", fields, key="field_name", index=fields.index("Lago Agrio") if "Lago Agrio" in fields else 0)
    st.text_input("Reviewer name", key="reviewer", placeholder="Required for decisions and the audit trail")
    st.caption("PoC · suggestions are never applied without reviewer approval")

page = st.navigation(
    [
        st.Page(overview.render, title="Overview", icon="🏠", url_path="overview", default=True),
        st.Page(source_library.render, title="Source library", icon="📚", url_path="sources"),
        st.Page(find_updates.render, title="Find updates", icon="🔎", url_path="find"),
        st.Page(review.render, title="Review changes", icon="✅", url_path="review"),
        st.Page(final_report.render, title="Final report", icon="📄", url_path="report"),
    ]
)
page.run()
