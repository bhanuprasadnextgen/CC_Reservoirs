"""Shared UI state: cached services, the selected field, reviewer, current run and review store."""

from __future__ import annotations

import streamlit as st

from app.models import AnalysisRun, IngestionRecord, ReportCitation, ReportRole, ReportSection, ReportVersion
from app.services import evidence_viewer
from app.services.document_intelligence_service import cache_path as extraction_cache_path
from app.services.review_service import ReviewStore
from app.utils.text_utils import slugify
from app.workflows.ingestion_workflow import load_citations, load_manifest, load_sections
from app.workflows.report_update_workflow import AnalysisServices, executive_summary_section, load_run


@st.cache_resource(show_spinner="Connecting to Azure…")
def services() -> AnalysisServices:
    return AnalysisServices.create()


@st.cache_data(ttl=600, show_spinner=False)
def list_fields() -> list[str]:
    return services().source.list_fields()


@st.cache_data(ttl=600, show_spinner=False)
def report_versions(field_name: str) -> list[ReportVersion]:
    return services().source.report_versions(field_name)


@st.cache_data(ttl=60, show_spinner=False)
def manifest(field_id: str) -> list[IngestionRecord]:
    svc = services()
    return load_manifest(svc.storage, svc.settings, field_id)


@st.cache_data(ttl=300, show_spinner=False)
def sections(field_id: str, report_id: str) -> list[ReportSection]:
    svc = services()
    return load_sections(svc.storage, svc.settings, field_id, report_id)


@st.cache_data(ttl=300, show_spinner=False)
def citations(field_id: str, report_id: str) -> list[ReportCitation]:
    svc = services()
    return load_citations(svc.storage, svc.settings, field_id, report_id)


@st.cache_resource(show_spinner=False)
def pdf_cache() -> evidence_viewer.PdfCache:
    """Source PDFs in memory, shared by all sessions; the Review page prefetches them in the background."""
    return evidence_viewer.PdfCache(services().source.download)


@st.cache_data(ttl=3600, max_entries=4, show_spinner=False)
def page_words(field_id: str, document_id: str) -> dict[int, dict]:
    """Word positions per page from the cached Document Intelligence result ({} if not cached).

    Only needed for scanned PDFs, which have no text layer — it is a slow download.
    """
    svc = services()
    cached = svc.storage.get_json(extraction_cache_path(svc.settings, field_id, document_id)) or {}
    return evidence_viewer.page_words(cached.get("parts", []))


# ------------------------------------------------------------------ selection


def field_name() -> str:
    return st.session_state["field_name"]


def field_id() -> str:
    return slugify(field_name())


def reviewer() -> str:
    return st.session_state.get("reviewer", "").strip()


def current_report() -> ReportVersion | None:
    versions = [v for v in report_versions(field_name()) if v.role == ReportRole.CURRENT]
    return versions[0] if versions else None


def summary_section_id() -> str | None:
    report = current_report()
    summary = executive_summary_section(sections(field_id(), report.report_id)) if report else None
    return summary.section_id if summary else None


def ground_truth_report() -> ReportVersion | None:
    versions = [v for v in report_versions(field_name()) if v.role == ReportRole.GROUND_TRUTH]
    return versions[0] if versions else None


# ------------------------------------------------------------------ run + review


def current_run() -> AnalysisRun | None:
    key = f"run::{field_id()}"
    if key not in st.session_state:
        svc = services()
        st.session_state[key] = load_run(svc.storage, svc.settings, field_id())
    return st.session_state[key]


def set_run(run: AnalysisRun) -> None:
    st.session_state[f"run::{run.field_id}"] = run
    st.session_state.pop(f"review::{run.field_id}", None)


def review_store() -> ReviewStore | None:
    run = current_run()
    if run is None:
        return None
    key = f"review::{run.field_id}"
    store = st.session_state.get(key)
    if store is None or store.run.run_id != run.run_id:
        svc = services()
        store = ReviewStore(svc.storage, svc.settings, run)
        st.session_state[key] = store
    return store


def require_run() -> AnalysisRun | None:
    run = current_run()
    if run is None:
        st.info("No analysis has been run for this field yet. Open **Find updates** to start one.")
    return run


TYPE_LABELS = {"update": "Update", "new_information": "New information", "conflict": "Conflict"}
CATEGORY_LABELS = {"key": "Key reference", "unused": "Previously unused", "new": "New reference", "report": "Report"}
CATEGORY_PLURALS = {"key": "Key references", "unused": "Previously unused references", "new": "New references", "report": "Reports"}


def pages(start: int | None, end: int | None) -> str:
    if start is None:
        return ""
    return f"p. {start}" if end in (None, start) else f"pp. {start}–{end}"
