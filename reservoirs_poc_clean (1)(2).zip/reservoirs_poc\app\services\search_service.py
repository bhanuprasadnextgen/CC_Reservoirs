"""Azure AI Search: index schema, upload, hybrid retrieval with metadata filters.

Every query goes through `build_filter`, so "retrieval is constrained to the relevant field"
(SOW acceptance criterion) is enforced in one place.
"""

from __future__ import annotations

from collections.abc import Iterable

from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError, ServiceRequestError, ServiceResponseError
from azure.search.documents import SearchClient
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    HnswAlgorithmConfiguration,
    HnswParameters,
    SearchableField,
    SearchField,
    SearchFieldDataType,
    SearchIndex,
    SemanticConfiguration,
    SemanticField,
    SemanticPrioritizedFields,
    SemanticSearch,
    SimpleField,
    VectorSearch,
    VectorSearchProfile,
)
from azure.search.documents.models import VectorizedQuery

from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.config import Settings
from app.models import Chunk, ReferenceCategory, SearchHit
from app.utils.logging_config import get_logger

log = get_logger(__name__)

_VECTOR_FIELD = "content_vector"
_PROFILE = "hnsw-cosine"
_SEMANTIC_CONFIG = "chunks-semantic"
_UPLOAD_BATCH = 500
_CHUNK_FIELDS = list(Chunk.model_fields.keys() - {"embedding"})


def _quote(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def build_filter(
    field_id: str,
    categories: Iterable[ReferenceCategory] | None = None,
    *,
    report_id: str | None = None,
    document_ids: Iterable[str] | None = None,
    exclude_document_ids: Iterable[str] = (),
    exclude_section_id: str | None = None,
) -> str:
    """OData filter. `field_id` is mandatory — no query may span fields."""
    if not field_id:
        raise ValueError("field_id is required for every search")
    clauses = [f"field_id eq {_quote(field_id)}"]
    if categories:
        values = ",".join(c.value for c in categories)
        clauses.append(f"search.in(category, '{values}', ',')")
    if report_id:
        clauses.append(f"report_id eq {_quote(report_id)}")
    if document_ids is not None:
        ids = ",".join(document_ids)
        clauses.append(f"search.in(document_id, '{ids}', ',')")
    excluded = list(exclude_document_ids)
    if excluded:
        clauses.append(f"not search.in(document_id, '{','.join(excluded)}', ',')")
    if exclude_section_id:
        clauses.append(f"section_id ne {_quote(exclude_section_id)}")
    return " and ".join(clauses)


class SearchService:
    def __init__(self, settings: Settings) -> None:
        credential = AzureKeyCredential(settings.search.key)
        self._settings = settings
        self._index_name = settings.search.index
        self._dimensions = settings.aoai.embedding_dimensions
        self._index_client = SearchIndexClient(settings.search.endpoint, credential)
        self._client = SearchClient(settings.search.endpoint, self._index_name, credential)

    @property
    def index_name(self) -> str:
        return self._index_name

    # ------------------------------------------------------------------- schema

    def index_definition(self, semantic: bool = True) -> SearchIndex:
        filterable = dict(filterable=True, facetable=True)
        fields = [
            SimpleField(name="chunk_id", type=SearchFieldDataType.String, key=True, filterable=True),
            SimpleField(name="document_id", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="field_id", type=SearchFieldDataType.String, **filterable),
            SimpleField(name="field_name", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="reservoir_id", type=SearchFieldDataType.String, **filterable),
            SimpleField(name="report_id", type=SearchFieldDataType.String, **filterable),
            SimpleField(name="category", type=SearchFieldDataType.String, **filterable),
            SimpleField(name="file_name", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="citation", type=SearchFieldDataType.String, filterable=True),
            SimpleField(name="publication_year", type=SearchFieldDataType.Int32, filterable=True, sortable=True),
            SimpleField(name="language", type=SearchFieldDataType.String, **filterable),
            SimpleField(name="section_id", type=SearchFieldDataType.String, filterable=True),
            SearchableField(name="section_title", type=SearchFieldDataType.String),
            SimpleField(name="page_start", type=SearchFieldDataType.Int32),
            SimpleField(name="page_end", type=SearchFieldDataType.Int32),
            SimpleField(name="chunk_index", type=SearchFieldDataType.Int32, sortable=True),
            SearchableField(name="content", type=SearchFieldDataType.String, analyzer_name="standard.lucene"),
            SearchField(
                name=_VECTOR_FIELD,
                type=SearchFieldDataType.Collection(SearchFieldDataType.Single),
                searchable=True,
                retrievable=False,
                stored=False,
                vector_search_dimensions=self._dimensions,
                vector_search_profile_name=_PROFILE,
            ),
        ]
        vector_search = VectorSearch(
            algorithms=[
                HnswAlgorithmConfiguration(name="hnsw", parameters=HnswParameters(metric="cosine", m=4, ef_construction=400))
            ],
            profiles=[VectorSearchProfile(name=_PROFILE, algorithm_configuration_name="hnsw")],
        )
        semantic_search = (
            SemanticSearch(
                configurations=[
                    SemanticConfiguration(
                        name=_SEMANTIC_CONFIG,
                        prioritized_fields=SemanticPrioritizedFields(
                            title_field=SemanticField(field_name="section_title"),
                            content_fields=[SemanticField(field_name="content")],
                            keywords_fields=[SemanticField(field_name="citation")],
                        ),
                    )
                ]
            )
            if semantic
            else None
        )
        return SearchIndex(
            name=self._index_name, fields=fields, vector_search=vector_search, semantic_search=semantic_search
        )

    def ensure_index(self) -> SearchIndex:
        """Create the index if missing. Never modifies or deletes an existing index."""
        try:
            return self._index_client.get_index(self._index_name)
        except ResourceNotFoundError:
            pass
        try:
            created = self._index_client.create_index(self.index_definition(semantic=True))
        except HttpResponseError as err:
            if "semantic" not in str(err).lower():
                raise
            log.warning("Semantic configuration not supported on this service; creating index without it")
            created = self._index_client.create_index(self.index_definition(semantic=False))
        log.info("Created index %s", self._index_name)
        return created

    # ------------------------------------------------------------------- writes

    def upload_chunks(self, chunks: list[Chunk], vectors: list[list[float]]) -> int:
        if len(chunks) != len(vectors):
            raise ValueError("chunks and vectors must align")
        docs = [
            {**chunk.model_dump(mode="json", exclude={"embedding"}), _VECTOR_FIELD: vector}
            for chunk, vector in zip(chunks, vectors)
        ]
        uploaded = 0
        for start in range(0, len(docs), _UPLOAD_BATCH):
            results = self._upload_batch(docs[start : start + _UPLOAD_BATCH])
            failed = [r for r in results if not r.succeeded]
            if failed:
                raise RuntimeError(f"{len(failed)} chunk(s) failed to index, e.g. {failed[0].key}: {failed[0].error_message}")
            uploaded += len(results)
        return uploaded

    @retry(
        retry=retry_if_exception_type((ServiceRequestError, ServiceResponseError)),
        wait=wait_exponential(multiplier=2, min=2, max=60),
        stop=stop_after_attempt(6),
        reraise=True,
    )
    def _upload_batch(self, batch: list[dict]):
        # merge_or_upload is idempotent (keyed by chunk_id), so retrying a half-sent batch is safe.
        return self._client.merge_or_upload_documents(documents=batch)

    def delete_document(self, document_id: str) -> int:
        keys = [
            {"chunk_id": d["chunk_id"]}
            for d in self._client.search(search_text="*", filter=f"document_id eq {_quote(document_id)}", select=["chunk_id"])
        ]
        if keys:
            self._client.delete_documents(documents=keys)
        return len(keys)

    # -------------------------------------------------------------------- reads

    def get_chunk(self, chunk_id: str) -> Chunk | None:
        try:
            doc = self._client.get_document(key=chunk_id, selected_fields=_CHUNK_FIELDS)
        except ResourceNotFoundError:
            return None
        return Chunk.model_validate({k: doc.get(k) for k in _CHUNK_FIELDS})

    def count(self, filter: str) -> int:
        results = self._client.search(search_text="*", filter=filter, top=0, include_total_count=True)
        return results.get_count() or 0

    def hybrid_search(
        self,
        text: str,
        vector: list[float] | None,
        filter: str,
        top_k: int | None = None,
    ) -> list[SearchHit]:
        """Keyword (BM25) + vector search fused by RRF, constrained by `filter`."""
        top = top_k or self._settings.search.top_k
        vector_queries = (
            [VectorizedQuery(vector=vector, k_nearest_neighbors=max(top * 5, 50), fields=_VECTOR_FIELD)]
            if vector is not None
            else None
        )
        semantic = self._settings.search.use_semantic_ranker
        results = self._client.search(
            search_text=text or None,
            filter=filter,
            vector_queries=vector_queries,
            vector_filter_mode="preFilter",
            select=_CHUNK_FIELDS,
            top=top,
            query_type="semantic" if semantic else None,
            semantic_configuration_name=_SEMANTIC_CONFIG if semantic else None,
        )
        hits = []
        for doc in results:
            chunk = Chunk.model_validate({k: doc.get(k) for k in _CHUNK_FIELDS})
            hits.append(
                SearchHit(chunk=chunk, score=doc.get("@search.score") or 0.0, reranker_score=doc.get("@search.reranker_score"))
            )
        return hits
