"""Document Intelligence extraction with a Blob cache.

The raw AnalyzeResult is cached (not just our normalised form) so chunking and normalisation
can be changed later without paying for extraction again.
"""

from __future__ import annotations

from bisect import bisect_right
from collections.abc import Callable

from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest, AnalyzeResult, DocumentTable
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError, ServiceRequestError, ServiceResponseError
from tenacity import retry, retry_if_exception, stop_after_attempt, wait_exponential

from app.config import Settings
from app.models import ExtractedDocument, ExtractedParagraph, ExtractedTable, SourceDocument
from app.services.blob_service import StorageRepository
from app.utils.logging_config import get_logger

log = get_logger(__name__)

_DROPPED_ROLES = {"pageHeader", "pageFooter", "pageNumber"}
_PART_STRIDE = 10**9  # keeps reading-order offsets unique across page-range parts


def cache_path(settings: Settings, field_id: str, document_id: str) -> str:
    """Where the raw AnalyzeResult of a document is cached (gzipped JSON, one entry per page-range part)."""
    return settings.blob.storage_path("cache", field_id, f"{document_id}.{settings.docintel.model_id}.json.gz")


def _is_transient(err: BaseException) -> bool:
    if isinstance(err, (ServiceRequestError, ServiceResponseError)):
        return True
    return isinstance(err, HttpResponseError) and (err.status_code == 429 or (err.status_code or 0) >= 500)


class DocumentIntelligenceService:
    def __init__(self, settings: Settings, storage: StorageRepository) -> None:
        self._settings = settings
        self._storage = storage
        self._model_id = settings.docintel.model_id
        self._client = DocumentIntelligenceClient(settings.docintel.endpoint, AzureKeyCredential(settings.docintel.key))

    def cache_path(self, doc: SourceDocument) -> str:
        return cache_path(self._settings, doc.field_id, doc.document_id)

    def is_cached(self, doc: SourceDocument) -> bool:
        return self._storage.exists(self.cache_path(doc))

    def extract(self, doc: SourceDocument, url_for: Callable[[str], str]) -> ExtractedDocument:
        """Extract a document, reading from cache when available. `url_for` returns a readable URL for a blob path."""
        path = self.cache_path(doc)
        cached = self._storage.get_json(path)
        if cached is not None:
            parts = [AnalyzeResult(p) for p in cached["parts"]]
            log.info("cache hit  %s (%d part(s))", doc.file_name, len(parts))
        else:
            parts = self._analyze_all_pages(url_for(doc.blob_path), doc.file_name)
            self._storage.put_json(path, {"model_id": self._model_id, "parts": [p.as_dict() for p in parts]}, compress=True)
        return normalize(parts, doc.document_id, self._model_id)

    # ---------------------------------------------------------------- calling DI

    def _analyze_all_pages(self, url: str, name: str) -> list[AnalyzeResult]:
        """Analyse in page ranges so documents longer than the per-call page limit are fully covered."""
        limit = self._settings.ingestion.docintel_max_pages_per_call
        parts: list[AnalyzeResult] = []
        first = 1
        while True:
            pages = f"{first}-{first + limit - 1}"
            log.info("analyse    %s pages %s", name, pages)
            try:
                result = self._analyze(url, pages)
            except HttpResponseError as err:
                # Asking for a range that starts past the last page means we are done.
                if parts and err.status_code == 400:
                    break
                raise
            parts.append(result)
            if len(result.pages or []) < limit:
                break
            first += limit
        return parts

    @retry(
        retry=retry_if_exception(_is_transient),
        wait=wait_exponential(multiplier=2, min=4, max=120),
        stop=stop_after_attempt(6),
        reraise=True,
    )
    def _analyze(self, url: str, pages: str) -> AnalyzeResult:
        poller = self._client.begin_analyze_document(
            self._model_id, AnalyzeDocumentRequest(url_source=url), pages=pages
        )
        return poller.result()


# ------------------------------------------------------------------- normalisation


def normalize(parts: list[AnalyzeResult], document_id: str, model_id: str) -> ExtractedDocument:
    """Turn raw results into reading-order paragraphs and markdown tables.

    Dropped, because they are noise for text analysis (figure analysis is out of PoC scope):
    - page headers / footers / page numbers, and short lines repeated on many pages (running titles)
    - table cells reported as paragraphs (table text is kept once, inside its table)
    - short labels inside figures (axis labels, map annotations); sentence-length text inside a
      figure is kept, since scanned text pages are sometimes detected as figures
    - tables detected inside figures (charts and log plots rendered as grids)
    """
    paragraphs: list[ExtractedParagraph] = []
    tables: list[ExtractedTable] = []
    page_count = 0

    for part_no, result in enumerate(parts):
        base = part_no * _PART_STRIDE
        page_of = _page_lookup(result)
        page_count += len(result.pages or [])
        figure_spans = _span_ranges(result.figures)

        table_spans: list[tuple[int, int]] = []
        for table in result.tables or []:
            if not table.spans:
                continue
            start, end = _span_range(table.spans)
            table_spans.append((start, end))
            if _inside(start, figure_spans):
                continue
            extracted = _table_to_markdown(table, page_of, base + start)
            if extracted:
                tables.append(extracted)
        table_spans.sort()

        for para in result.paragraphs or []:
            text = (para.content or "").strip()
            if not text or para.role in _DROPPED_ROLES or not para.spans:
                continue
            offset = para.spans[0].offset
            if _inside(offset, table_spans):
                continue
            if _inside(offset, figure_spans) and len(text.split()) < _FIGURE_TEXT_MIN_WORDS:
                continue
            page = para.bounding_regions[0].page_number if para.bounding_regions else page_of(offset)
            paragraphs.append(ExtractedParagraph(text=text, role=para.role, page=page, offset=base + offset))

    paragraphs.sort(key=lambda p: p.offset)
    tables.sort(key=lambda t: t.offset)
    return ExtractedDocument(
        document_id=document_id,
        model_id=model_id,
        page_count=page_count,
        paragraphs=_drop_running_lines(paragraphs),
        tables=tables,
    )


_FIGURE_TEXT_MIN_WORDS = 12
_RUNNING_LINE_MAX_WORDS = 15
_RUNNING_LINE_MIN_PAGES = 3


def _drop_running_lines(paragraphs: list[ExtractedParagraph]) -> list[ExtractedParagraph]:
    """Remove short lines that recur on many pages (running titles, 'C&C Reservoirs' footers).

    For heading/title lines the first occurrence is kept, so a real title that later repeats as a
    running header survives. Plain-text repeats are all dropped.
    """
    pages_by_key: dict[str, set[int]] = {}
    for p in paragraphs:
        if len(p.text.split()) <= _RUNNING_LINE_MAX_WORDS:
            pages_by_key.setdefault(_line_key(p.text), set()).add(p.page)
    running = {k for k, pages in pages_by_key.items() if len(pages) >= _RUNNING_LINE_MIN_PAGES}

    kept: list[ExtractedParagraph] = []
    seen: set[str] = set()
    for p in paragraphs:
        key = _line_key(p.text) if len(p.text.split()) <= _RUNNING_LINE_MAX_WORDS else ""
        if key in running:
            if key in seen or p.role not in ("title", "sectionHeading"):
                continue
            seen.add(key)
        kept.append(p)
    return kept


def _line_key(text: str) -> str:
    return "".join(ch for ch in text.lower() if ch.isalpha())


def _span_range(spans) -> tuple[int, int]:
    return min(s.offset for s in spans), max(s.offset + s.length for s in spans)


def _span_ranges(items) -> list[tuple[int, int]]:
    return sorted(_span_range(item.spans) for item in items or [] if item.spans)


def _page_lookup(result: AnalyzeResult) -> Callable[[int], int]:
    """Map a character offset to a page number using page spans (works for DOCX, which has no bounding boxes)."""
    starts: list[int] = []
    numbers: list[int] = []
    for page in result.pages or []:
        for span in page.spans or []:
            starts.append(span.offset)
            numbers.append(page.page_number)
    order = sorted(range(len(starts)), key=starts.__getitem__)
    starts = [starts[i] for i in order]
    numbers = [numbers[i] for i in order]

    def page_of(offset: int) -> int:
        i = bisect_right(starts, offset) - 1
        return numbers[i] if i >= 0 else (numbers[0] if numbers else 1)

    return page_of


def _inside(offset: int, spans: list[tuple[int, int]]) -> bool:
    i = bisect_right(spans, (offset, float("inf"))) - 1
    return i >= 0 and spans[i][0] <= offset < spans[i][1]


def _cell_text(text: str | None) -> str:
    return " ".join((text or "").replace("|", "\\|").split())


def _table_to_markdown(table: DocumentTable, page_of: Callable[[int], int], offset: int) -> ExtractedTable | None:
    if not table.cells or not table.row_count or not table.column_count:
        return None
    grid = [["" for _ in range(table.column_count)] for _ in range(table.row_count)]
    header_rows: set[int] = set()
    for cell in table.cells:
        grid[cell.row_index][cell.column_index] = _cell_text(cell.content)
        if cell.kind == "columnHeader":
            header_rows.add(cell.row_index)

    # Header = leading run of column-header rows; fall back to the first row.
    n_header = 0
    while n_header in header_rows:
        n_header += 1
    n_header = max(n_header, 1)

    def row(cells: list[str]) -> str:
        return "| " + " | ".join(cells) + " |"

    header_lines = [row(r) for r in grid[:n_header]]
    header = "\n".join([*header_lines, row(["---"] * table.column_count)])
    body = [row(r) for r in grid[n_header:] if any(r)]

    pages = [br.page_number for br in table.bounding_regions or []] or [page_of(offset % _PART_STRIDE)]
    caption = _cell_text(table.caption.content) if table.caption else None
    markdown = "\n".join([f"Table: {caption}" if caption else "", header, *body]).strip()
    return ExtractedTable(
        markdown=markdown,
        header=header,
        rows=body,
        caption=caption,
        page_start=min(pages),
        page_end=max(pages),
        offset=offset,
    )
