"""Run the analysis over a report: all sections (batch "Find updates") or one section with an
optional reviewer instruction (iterative mode). Runs are saved under poc-fresh/runs/<field_id>/<run_id>/.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from app.config import Settings, get_settings
from app.models import AnalysisRun, Recommendation, ReportRole, ReportSection, ReportVersion, ReviewState, _utcnow
from app.services.blob_service import SourceRepository, StorageRepository
from app.services.embedding_service import EmbeddingService
from app.services.llm_service import LLMClient, create_llm_client
from app.services.report_analysis_service import ReportAnalysisService, SectionContext, SectionResult
from app.services.report_parser import analysable, is_executive_summary
from app.services.search_service import SearchService
from app.utils.logging_config import get_logger, set_run_id
from app.utils.text_utils import slugify
from app.workflows.ingestion_workflow import load_citations, load_sections

log = get_logger(__name__)

ProgressCallback = Callable[[str, int, int], None]  # (section_id, done, total)


@dataclass
class AnalysisServices:
    settings: Settings
    source: SourceRepository
    storage: StorageRepository
    search: SearchService
    embeddings: EmbeddingService
    llm: LLMClient
    analysis: ReportAnalysisService

    @classmethod
    def create(cls, settings: Settings | None = None) -> AnalysisServices:
        settings = settings or get_settings()
        search, embeddings, llm = SearchService(settings), EmbeddingService(settings), create_llm_client(settings)
        return cls(
            settings=settings,
            source=SourceRepository(settings),
            storage=StorageRepository(settings),
            search=search,
            embeddings=embeddings,
            llm=llm,
            analysis=ReportAnalysisService(settings, search, embeddings, llm),
        )


# ------------------------------------------------------------------------ storage


def run_path(settings: Settings, field_id: str, run_id: str) -> str:
    return settings.blob.storage_path("runs", field_id, run_id, "run.json")


def latest_path(settings: Settings, field_id: str) -> str:
    return settings.blob.storage_path("runs", field_id, "latest.json")


def save_run(storage: StorageRepository, settings: Settings, run: AnalysisRun) -> None:
    storage.put_json(run_path(settings, run.field_id, run.run_id), run.model_dump(mode="json"))
    storage.put_json(latest_path(settings, run.field_id), {"run_id": run.run_id})


def load_run(storage: StorageRepository, settings: Settings, field_id: str, run_id: str | None = None) -> AnalysisRun | None:
    if run_id is None:
        pointer = storage.get_json(latest_path(settings, field_id))
        if not pointer:
            return None
        run_id = pointer["run_id"]
    data = storage.get_json(run_path(settings, field_id, run_id))
    return AnalysisRun.model_validate(data) if data else None


def current_report(source: SourceRepository, field_name: str) -> ReportVersion:
    versions = [v for v in source.report_versions(field_name) if v.role == ReportRole.CURRENT]
    if not versions:
        raise ValueError(f"No report found for field '{field_name}'")
    return versions[0]


def executive_summary_section(sections: list[ReportSection]) -> ReportSection | None:
    return next((s for s in analysable(sections) if is_executive_summary(s)), None)


def checked_sections(sections: list[ReportSection]) -> list[ReportSection]:
    """Sections "Find updates" checks against the sources: every analysable one except the executive summary."""
    return [s for s in analysable(sections) if not is_executive_summary(s)]


def report_outline(sections: list[ReportSection], words: int = 30) -> str:
    lines = []
    for s in analysable(sections):
        summary = " ".join(s.text.split()[:words])
        lines.append(f"{s.section_id} {s.title}: {summary}…")
    return "\n".join(lines)


# ----------------------------------------------------------------------- workflow


def run_analysis(
    field_name: str,
    *,
    section_ids: list[str] | None = None,
    instruction: str | None = None,
    base_run: AnalysisRun | None = None,
    services: AnalysisServices | None = None,
    progress: ProgressCallback | None = None,
) -> AnalysisRun:
    """Analyse the field's current report.

    - No `section_ids`: every analysable section (batch mode).
    - `section_ids` + `base_run`: re-analyse just those sections inside the existing run, replacing their
      previous recommendations (iterative mode; review decisions on other sections are untouched).
    - The executive summary is skipped: it is drafted on the Final report page from the approved changes
      (see `draft_executive_summary`).
    """
    svc = services or AnalysisServices.create()
    settings = svc.settings
    field_id = slugify(field_name)
    report = current_report(svc.source, field_name)
    sections = load_sections(svc.storage, settings, field_id, report.report_id)
    if not sections:
        raise ValueError(f"Report for '{field_name}' has not been ingested yet — run ingestion first")
    citations = load_citations(svc.storage, settings, field_id, report.report_id)

    # The executive summary is not checked against sources; it is drafted from the approved changes later.
    all_targets = checked_sections(sections)
    targets = [s for s in all_targets if s.section_id in set(section_ids)] if section_ids else all_targets

    run = base_run or AnalysisRun(
        field_id=field_id, report_id=report.report_id, categories_searched=list(settings.analysis.search_categories)
    )
    set_run_id(run.run_id)
    if base_run and section_ids:
        keep = lambda r: r.section_id not in set(section_ids)  # noqa: E731
        run.recommendations = [r for r in run.recommendations if keep(r)]
        run.ungrounded = [r for r in run.ungrounded if keep(r)]
        run.discarded = [d for d in run.discarded if d.split(":", 1)[0] not in set(section_ids)]
        for sid in section_ids:
            run.section_notes.pop(sid, None)
    run.sections_total = len(all_targets)
    run.model = svc.llm.model_name
    run.prompt_version = svc.analysis.prompt_version

    outline = report_outline(sections)
    calls_before = (svc.llm.usage.calls, svc.llm.usage.input_tokens, svc.llm.usage.output_tokens)
    lock = threading.Lock()
    done = 0
    total = len(targets)

    def context(section: ReportSection) -> SectionContext:
        return SectionContext(
            run_id=run.run_id,
            field_id=field_id,
            field_name=field_name,
            report_id=report.report_id,
            reservoir_name=report.reservoir_name,
            section=section,
            outline=outline,
            citations=citations,
        )

    def analyse(section: ReportSection) -> SectionResult:
        set_run_id(run.run_id)
        return svc.analysis.analyse_section(context(section), instruction=instruction)

    def collect(section: ReportSection, outcome: Callable[[], SectionResult]) -> None:
        nonlocal done
        with lock:
            try:
                result = outcome()
                run.recommendations.extend(result.recommendations)
                run.ungrounded.extend(result.ungrounded)
                run.discarded.extend(result.discarded)
                if result.note:
                    run.section_notes[section.section_id] = result.note
            except Exception as err:  # one failed section must not lose the others
                log.exception("section %s failed", section.section_id)
                run.errors.append(f"Section {section.section_id}: {type(err).__name__}: {err}"[:500])
            done += 1
            if not base_run:
                run.sections_done = done
            save_run(svc.storage, settings, run)  # partial results survive interruptions
        if progress:
            progress(section.section_id, done, total)

    # Sections are analysed in parallel but collected in report order, so progress reads 1, 2, 3 …
    with ThreadPoolExecutor(max_workers=settings.analysis.max_concurrent_sections) as pool:
        futures = [(s, pool.submit(analyse, s)) for s in targets]
        for section, future in futures:
            collect(section, future.result)

    order = {s.section_id: s.order for s in sections}
    run.recommendations.sort(key=lambda r: (order.get(r.section_id, 999), r.created_at))
    run.ungrounded.sort(key=lambda r: (order.get(r.section_id, 999), r.created_at))
    run.finished_at = _utcnow()
    run.llm_calls += svc.llm.usage.calls - calls_before[0]
    run.llm_input_tokens += svc.llm.usage.input_tokens - calls_before[1]
    run.llm_output_tokens += svc.llm.usage.output_tokens - calls_before[2]
    save_run(svc.storage, settings, run)
    log.info(
        "run %s: %d recommendations, %d ungrounded, %d errors",
        run.run_id, len(run.recommendations), len(run.ungrounded), len(run.errors),
    )
    return run


def draft_executive_summary(
    field_name: str, run: AnalysisRun, approved: list[tuple[Recommendation, ReviewState]], services: AnalysisServices
) -> str | None:
    """Draft the executive summary from the approved section changes (with the reviewers' final wording)
    and store it on the run for review. Returns a note instead when there is nothing to change."""
    svc = services
    report = current_report(svc.source, field_name)
    sections = load_sections(svc.storage, svc.settings, run.field_id, report.report_id)
    summary = executive_summary_section(sections)
    if summary is None:
        return "This report has no executive summary section."
    changes = [rec.model_copy(update={"proposed_text": state.final_text or rec.proposed_text}) for rec, state in approved]
    ctx = SectionContext(
        run_id=run.run_id, field_id=run.field_id, field_name=field_name, report_id=report.report_id,
        reservoir_name=report.reservoir_name, section=summary, outline=report_outline(sections), citations=[],
    )
    calls_before = (svc.llm.usage.calls, svc.llm.usage.input_tokens, svc.llm.usage.output_tokens)
    result = svc.analysis.summarise(ctx, changes)
    run.llm_calls += svc.llm.usage.calls - calls_before[0]
    run.llm_input_tokens += svc.llm.usage.input_tokens - calls_before[1]
    run.llm_output_tokens += svc.llm.usage.output_tokens - calls_before[2]
    if not result.recommendations:
        save_run(svc.storage, svc.settings, run)
        return result.note
    run.executive_summary = result.recommendations[0]
    run.executive_summary_basis = [rec.recommendation_id for rec, _ in approved]
    save_run(svc.storage, svc.settings, run)
    return None
