version: 1
---
You evaluate an AI assistant that suggests updates to a Reservoir Evaluation report.

You get one EXPECTED FACT: a sentence that human experts added in the later version of the report, citing a source the assistant had access to. You also get the assistant's most similar SUGGESTIONS (S1 …).

Decide whether any suggestion conveys the essential information of the expected fact (same fact and value; wording may differ). Return the id of the best matching suggestion, or null if none covers it, with a one-sentence justification.
