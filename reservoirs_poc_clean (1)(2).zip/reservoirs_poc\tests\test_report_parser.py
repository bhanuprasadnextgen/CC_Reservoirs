from app.models import ReferenceCategory, SectionKind
from app.services.report_parser import analysable, citation_years, cited_works, parse_report_citations, parse_sections

from tests.conftest import make_source


def _report(b):
    return (
        b.heading("LAGO AGRIO FIELD LOWER AND UPPER HOLLÍN RESERVOIRS", role="title")
        .heading("TABLE OF CONTENTS")
        .heading("Accessing Reservoir Table of Parameters")  # mixed case — must not open the appendix
        .para("Front matter text.")
        .heading("1. EXECUTIVE SUMMARY")
        .para("The field was discovered in 1967 and brought onstream in 1972.")
        .heading("8. RESERVOIR PERFORMANCE")
        .heading("8.1 DEVELOPMENT STRATEGY & PRODUCTION HISTORY")
        .para("Production commenced in May 1972 (Sarango Sánchez, 2018). Peak came in 1973 (Vásquez Bungacho, 2018; Romo Peláez, 2018).", page=10)
        .para("Hernandez et al. (2016) describe a sealant job.")
        .heading("KEY REFERENCES")
        .para("Sarango Sánchez, M.A., 2018, Modelo integrado de gestión: Tesis, Quito, 120 p.", page=13)
        .para("Estupiñan, J., Marfil, R., 2010, Reservoir sandstones of the Napo Formation: Geologica Acta.")
        .heading("LAGO AGRIO FIELD I TABLE OF PARAMETERS", role="title")
        .table(["Reservoir", "STOIIP (MMBO)"], [["Lower Hollín", "450"]], caption="Table 2 - In-place volumes (Andrade Díaz, 2017).")
        .heading("LAGO AGRIO FIELD I TABLES & FIGURES", role="title")
        .table(["Depth", "GR"], [["9000", "x"]])  # uncaptioned grid — figure artefact
        .build()
    )


def test_sections_numbering_kinds_and_parents(doc_builder):
    sections = {s.section_id: s for s in parse_sections(_report(doc_builder))}
    assert list(sections) == ["FRONT", "1", "8", "8.1", "REF", "TABLES"]
    assert sections["1"].kind == SectionKind.BODY
    assert sections["8.1"].parent_id == "8" and sections["8.1"].level == 2
    assert sections["8.1"].page_start == 10
    assert sections["REF"].kind == SectionKind.REFERENCES
    assert "Front matter text." in sections["FRONT"].text


def test_tables_section_keeps_only_captioned_tables(doc_builder):
    tables = next(s for s in parse_sections(_report(doc_builder)) if s.section_id == "TABLES")
    assert len(tables.tables) == 1
    assert "450" in tables.text and "9000" not in tables.text


def test_analysable_excludes_empty_parents_references_and_front_matter(doc_builder):
    ids = [s.section_id for s in analysable(parse_sections(_report(doc_builder)))]
    assert ids == ["1", "8.1", "TABLES"]


def test_toc_lines_are_not_headings(doc_builder):
    doc = (
        doc_builder.para("1. EXECUTIVE SUMMARY ........ 3")
        .heading("1. EXECUTIVE SUMMARY")
        .para("Body.")
        .build()
    )
    sections = parse_sections(doc)
    assert [s.section_id for s in sections] == ["FRONT", "1"]


def test_citations_found_and_traced_to_files(doc_builder):
    sections = parse_sections(_report(doc_builder))
    refs = [
        make_source("sarango", ReferenceCategory.KEY, "Sarango Sanchez, 2018, Modelo.pdf", authors=["Sarango Sanchez"], year=2018),
        make_source("estupi", ReferenceCategory.KEY, "Estupifian et al, 2010, Reservoir.pdf", authors=["Estupifian"], year=2010),
        make_source("hern", ReferenceCategory.UNUSED, "Hernandez et al., 2016, First.pdf", authors=["Hernandez"], year=2016),
    ]
    citations = {c.surname.split()[0].lower(): c for c in parse_report_citations(sections, refs)}

    assert citations["sarango"].document_id == "sarango"
    assert "8.1" in citations["sarango"].section_ids and "REF" in citations["sarango"].section_ids
    assert citations["estupiñan"].document_id == "estupi"  # fuzzy match absorbs the file-name typo
    assert citations["hernandez"].document_id == "hern"  # narrative "Hernandez et al. (2016)"
    assert citations["vásquez"].document_id is None  # cited but no file provided
    assert "may" not in citations  # "May 1972" is not an author


def test_same_first_author_same_year_is_disambiguated_by_full_authors():
    from app.services.report_parser import match_reference

    refs = [
        make_source("key", ReferenceCategory.KEY, "Hernandez & Bustillos, 2016, Integrated.pdf", authors=["Hernandez", "Bustillos"], year=2016),
        make_source("unused", ReferenceCategory.UNUSED, "Hernandez et al., 2016, First sealant.pdf", authors=["Hernandez"], year=2016),
    ]
    assert match_reference("Hernandez and Bustillos", 2016, refs).document_id == "key"
    assert match_reference("Hernandez et al.", 2016, refs).document_id == "unused"
    assert match_reference("Hernandez", 2015, refs) is None


def test_one_author_with_several_years_counts_each_year():
    text = ("…metamorphic basement (Smith, 1989; Balkwill et al., 1995; Pindell and Tabbutt, 1995; Baby et al., 1998, 1999). "
            "Gil (2001a, 2001b) revised it in 2005 (since 2005).")
    assert cited_works(text) == [
        ("Smith", 1989), ("Balkwill et al.", 1995), ("Pindell and Tabbutt", 1995),
        ("Baby et al.", 1998), ("Baby et al.", 1999), ("Gil", 2001), ("Gil", 2001),
    ]
    assert citation_years(text) == [1989, 1995, 1995, 1998, 1999, 2001, 2001]
