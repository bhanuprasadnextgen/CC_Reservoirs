"""Prompt files. Each .md starts with a `version:` line and a `---` separator, then the prompt text.

The version is stored on every recommendation so prompt-tuning changes stay traceable.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

_DIR = Path(__file__).parent


@dataclass(frozen=True)
class Prompt:
    name: str
    version: str
    text: str

    @property
    def tag(self) -> str:
        return f"{self.name}@{self.version}"


@lru_cache
def load_prompt(name: str) -> Prompt:
    raw = (_DIR / f"{name}.md").read_text(encoding="utf-8")
    header, sep, body = raw.partition("\n---\n")
    if not sep or not header.startswith("version:"):
        raise ValueError(f"Prompt {name}.md must start with 'version: X' and a '---' line")
    return Prompt(name=name, version=header.removeprefix("version:").strip(), text=body.strip())
