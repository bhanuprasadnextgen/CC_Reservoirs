"""Per-section change, new-information and conflict analysis.

Pipeline for one report section:
  1. claims    — LLM lists checkable claims + English/Spanish search queries
  2. retrieve  — hybrid search per query and per section passage, constrained to the field and to the
                 evidence categories (New/Unused); fused by reciprocal rank
  3. coverage  — related passages from OTHER report sections, so the model doesn't re-add covered facts
  4. analyse   — LLM proposes findings with verbatim quotes
  4b. rules   — the 2020 report is the baseline: updates/conflicts only from New References newer than
                 the statement's citation year; Previously Unused references only for additions
  5. verify    — for update/conflict: retrieve Key References (preferring the ones the report cites in
                 this section) and let the LLM judge keep_existing / propose_change / needs_review
  6. validate  — every quote checked against the indexed chunk; ungrounded findings separated out
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Literal

from pydantic import BaseModel

from app.config import Settings
from app.models import (
    ChangeType,
    Chunk,
    Confidence,
    Evidence,
    ExtractedParagraph,
    Recommendation,
    RecommendedAction,
    ReferenceCategory,
    ReportCitation,
    ReportSection,
    SearchHit,
    SourcePosition,
    SourceStance,
)
from app.prompts import load_prompt
from app.services.citation_validator import (
    QUOTE_MIN_SCORE,
    is_grounded,
    locate,
    locate_abridged,
    validate_recommendation,
)
from app.services.embedding_service import EmbeddingService
from app.services.llm_service import LLMClient
from app.services.report_parser import citation_years
from app.services.search_service import SearchService, build_filter
from app.utils.logging_config import get_logger

log = get_logger(__name__)

_RRF_K = 60
_HITS_PER_QUERY = 8
_ELSEWHERE_PER_QUERY = 3
_ELSEWHERE_MAX = 6
_KEY_EVIDENCE_MAX = 6
_REPORT_STATEMENTS_MAX = 4
_SECTION_PIECE_WORDS = 300
_DOSSIER_PER_DOCUMENT = 2
_DOSSIER_NEIGHBOUR_WORDS = 120
_DOSSIER_QUERY_CHARS = 1000


# ------------------------------------------------------------- LLM I/O schemas


class _Claim(BaseModel):
    claim: str
    query_en: str
    query_es: str


class _SectionQueries(BaseModel):
    claims: list[_Claim]


class _EvidenceRef(BaseModel):
    id: str  # "E3" / "K2"
    quote: str
    translation: str | None


class _Finding(BaseModel):
    change_type: Literal["update", "new_information", "conflict"]
    existing_text: str
    proposed_text: str
    rationale: str
    evidence: list[_EvidenceRef]
    confidence: Literal["low", "medium", "high"]
    impact: str


class _ChangeAnalysis(BaseModel):
    findings: list[_Finding]
    no_change_reason: str | None


class _Verdict(BaseModel):
    verdict: Literal["keep_existing", "propose_change", "needs_review"]
    reasoning: str
    supporting_evidence: list[_EvidenceRef]


class _SourceNote(BaseModel):
    id: str
    position: Literal["supports", "contradicts", "adds_detail", "older_value"]
    states: str
    quote: str
    translation: str | None


class _Dossier(BaseModel):
    context_summary: str
    sources: list[_SourceNote]
    revised_proposed_text: str | None


class _SummaryUpdate(BaseModel):
    updated_summary: str
    used_changes: list[str]  # "S1", "S2" …
    rationale: str
    no_change_reason: str | None


_VERDICT_ACTION = {
    "keep_existing": RecommendedAction.KEEP_EXISTING,
    "propose_change": RecommendedAction.APPLY,
    "needs_review": RecommendedAction.REVIEW,
}


# ------------------------------------------------------------------ inputs/outputs


@dataclass
class SectionContext:
    run_id: str
    field_id: str
    field_name: str
    report_id: str
    reservoir_name: str | None
    section: ReportSection
    outline: str  # one line per report section
    citations: list[ReportCitation]  # citations found in the report, linked to files where possible


@dataclass
class SectionResult:
    section_id: str
    recommendations: list[Recommendation] = field(default_factory=list)
    ungrounded: list[Recommendation] = field(default_factory=list)
    note: str | None = None  # e.g. the model's no-change reason
    evidence_count: int = 0
    discarded: list[str] = field(default_factory=list)  # findings removed by the source rules


# -------------------------------------------------------------------------- service


class ReportAnalysisService:
    def __init__(self, settings: Settings, search: SearchService, embeddings: EmbeddingService, llm: LLMClient) -> None:
        self._settings = settings
        self._search = search
        self._embeddings = embeddings
        self._llm = llm
        self._p_query = load_prompt("section_query")
        self._p_analysis = load_prompt("change_analysis")
        self._p_verify = load_prompt("conflict_verification")
        self._p_summary = load_prompt("executive_summary")
        self._p_dossier = load_prompt("evidence_dossier")

    @property
    def prompt_version(self) -> str:
        prompts = (self._p_query, self._p_analysis, self._p_verify, self._p_dossier, self._p_summary)
        return "+".join(p.tag for p in prompts)

    def summarise(self, ctx: SectionContext, approved: list[Recommendation]) -> SectionResult:
        """Rewrite the executive summary from the changes reviewers approved for the other sections.

        Pass each approved change with `proposed_text` set to the reviewer's final wording. The summary is not
        checked against sources itself: its evidence is the verified evidence of the changes it reflects.
        """
        section = ctx.section
        result = SectionResult(section_id=section.section_id)
        candidates = [r for r in approved if r.section_id != section.section_id]
        if not candidates:
            result.note = "No approved changes in the other sections to reflect in the executive summary."
            return result

        s_ids = {f"S{i}": r for i, r in enumerate(candidates, start=1)}
        listing = "\n\n".join(
            f"[{sid}] section {r.section_id} {r.section_title} · {r.change_type.value}\n"
            + (f"Report text: {r.existing_text}\n" if r.existing_text else "")
            + f"New text: {r.proposed_text}"
            for sid, r in s_ids.items()
        )
        user = "\n\n".join([
            f"FIELD: {ctx.field_name}" + (f" (reservoir: {ctx.reservoir_name})" if ctx.reservoir_name else ""),
            f"CURRENT EXECUTIVE SUMMARY (section {section.section_id} {section.title}):\n{section.text}",
            f"CHANGES:\n{listing}",
        ])
        update = self._llm.complete_json(self._p_summary.text, user, _SummaryUpdate)
        used = [s_ids[sid.strip().strip("[]")] for sid in dict.fromkeys(update.used_changes) if sid.strip().strip("[]") in s_ids]
        new_text = update.updated_summary.strip()
        if not used or not new_text or " ".join(new_text.split()) == " ".join(section.text.split()):
            result.note = update.no_change_reason or "The approved changes do not affect the executive summary."
            return result

        evidence = list({(e.chunk_id, e.quote): e for r in used for e in r.evidence}.values())
        if not evidence:
            result.note = "The changes reflected in the summary have no verified evidence."
            return result
        rank = {Confidence.LOW: 0, Confidence.MEDIUM: 1, Confidence.HIGH: 2}
        sources = ", ".join(dict.fromkeys(r.section_id for r in used))
        result.recommendations.append(
            Recommendation(
                run_id=ctx.run_id,
                field_id=ctx.field_id,
                report_id=ctx.report_id,
                section_id=section.section_id,
                section_title=section.title,
                change_type=ChangeType.UPDATE,
                existing_text=section.text,
                proposed_text=new_text,
                rationale=update.rationale,
                evidence=evidence,
                confidence=min((r.confidence for r in used), key=rank.__getitem__),
                impact=f"Keeps the executive summary consistent with the approved changes in section(s) {sources}.",
                model=self._llm.model_name,
                prompt_version=self.prompt_version,
                validation_notes=[f"Drafted from {len(used)} approved change(s) in section(s) {sources}."],
            )
        )
        log.info("section %-6s executive summary updated from %d change(s)", section.section_id, len(used))
        return result

    def analyse_section(self, ctx: SectionContext, instruction: str | None = None) -> SectionResult:
        section = ctx.section
        categories = self._settings.analysis.search_categories
        chunks: dict[str, Chunk] = {}

        # 1. claims and queries
        claims = self._llm.complete_json(self._p_query.text, self._query_input(ctx, instruction), _SectionQueries).claims
        pieces = _split_words(section.text, _SECTION_PIECE_WORDS)
        vectors = self._embeddings.embed([c.query_en for c in claims] + pieces)
        claim_vectors, piece_vectors = vectors[: len(claims)], vectors[len(claims) :]

        # 2. evidence retrieval, constrained to the field. New References get ~95% of the evidence slots;
        #    Previously Unused references get the rest (and may only support additions — see _apply_source_rules).
        evidence = []
        for category, slots in self._evidence_quotas(categories):
            category_filter = build_filter(ctx.field_id, [category])
            ranked: list[list[SearchHit]] = []
            for claim, vec in zip(claims, claim_vectors):
                ranked.append(self._search.hybrid_search(f"{claim.query_en} {claim.query_es}", vec, category_filter, _HITS_PER_QUERY))
            for piece, vec in zip(pieces, piece_vectors):
                ranked.append(self._search.hybrid_search("", vec, category_filter, _HITS_PER_QUERY))
            evidence += _fuse(ranked, slots)
        chunks.update({h.chunk.chunk_id: h.chunk for h in evidence})
        result = SectionResult(section_id=section.section_id, evidence_count=len(evidence))
        if not evidence:
            result.note = "No relevant passages found in the reference documents."
            return result

        # 3. coverage elsewhere in the report
        elsewhere_filter = build_filter(
            ctx.field_id, [ReferenceCategory.REPORT], report_id=ctx.report_id, exclude_section_id=section.section_id
        )
        elsewhere = _fuse(
            [self._search.hybrid_search(c.query_en, v, elsewhere_filter, _ELSEWHERE_PER_QUERY) for c, v in zip(claims, claim_vectors)],
            _ELSEWHERE_MAX,
        )

        # 4. analysis
        e_ids = {f"E{i}": h.chunk for i, h in enumerate(evidence, start=1)}
        analysis = self._llm.complete_json(
            self._p_analysis.text, self._analysis_input(ctx, e_ids, elsewhere, instruction), _ChangeAnalysis
        )
        result.note = analysis.no_change_reason if not analysis.findings else None

        recs = []
        for finding in analysis.findings:
            rec, reason = _apply_source_rules(self._to_recommendation(ctx, finding, e_ids), section)
            if rec is None:
                result.discarded.append(f"{section.section_id}: {reason} — {finding.proposed_text[:160]}")
                log.info("section %-6s discarded finding: %s", section.section_id, reason)
            else:
                recs.append(rec)

        # 5. verify updates/conflicts against Key References
        if self._settings.analysis.verify_conflicts_with_key_refs:
            recs = [self._verify(ctx, r, chunks) if r.change_type != ChangeType.NEW_INFORMATION else r for r in recs]

        if self._settings.analysis.dossier:
            recs = [self._dossier(ctx, r, chunks) for r in recs]

        # 6. ground every quote in the index
        def lookup(chunk_id: str) -> Chunk | None:
            return chunks.get(chunk_id) or self._search.get_chunk(chunk_id)

        for rec in recs:
            checked = validate_recommendation(rec, section.text, lookup, categories)
            (result.recommendations if is_grounded(checked, section.text) else result.ungrounded).append(checked)
        log.info(
            "section %-6s evidence=%d findings=%d grounded=%d ungrounded=%d discarded=%d",
            section.section_id, len(evidence), len(analysis.findings), len(result.recommendations),
            len(result.ungrounded), len(result.discarded),
        )
        return result

    def _evidence_quotas(self, categories: list[ReferenceCategory]) -> list[tuple[ReferenceCategory, int]]:
        """Evidence slots per category: New References ~95%, Previously Unused ~5% (at least one slot)."""
        total = self._settings.analysis.evidence_per_section
        share = self._settings.analysis.unused_share
        quotas = []
        if ReferenceCategory.UNUSED in categories and share > 0:
            quotas.append((ReferenceCategory.UNUSED, max(1, round(total * share))))
        unused_slots = quotas[0][1] if quotas else 0
        if ReferenceCategory.NEW in categories:
            quotas.insert(0, (ReferenceCategory.NEW, total - unused_slots))
        return quotas

    # ------------------------------------------------------------- verification

    def _verify(self, ctx: SectionContext, rec: Recommendation, chunks: dict[str, Chunk]) -> Recommendation:
        """Rod's check: where did the existing figure come from, and does a second source confirm it?

        The same fact is often stated in several report sections (e.g. the executive summary repeats the
        production start date that section 8.1 cites), so the report is searched for every place it states
        the fact, and the citations used there decide which Key References are checked first.
        """
        query = f"{rec.existing_text}\n{rec.proposed_text}"
        vector = self._embeddings.embed_one(query)
        report_hits = self._search.hybrid_search(
            rec.existing_text, vector,
            build_filter(ctx.field_id, [ReferenceCategory.REPORT], report_id=ctx.report_id), _REPORT_STATEMENTS_MAX,
        )
        sections = {ctx.section.section_id} | {h.chunk.section_id for h in report_hits if h.chunk.section_id}
        relevant_citations = [c for c in ctx.citations if sections & set(c.section_ids)]
        cited_docs = sorted({c.document_id for c in relevant_citations if c.document_id})
        hit_lists = []
        if cited_docs:
            hit_lists.append(
                self._search.hybrid_search(
                    rec.existing_text, vector, build_filter(ctx.field_id, [ReferenceCategory.KEY], document_ids=cited_docs), _KEY_EVIDENCE_MAX
                )
            )
        hit_lists.append(
            self._search.hybrid_search(rec.existing_text, vector, build_filter(ctx.field_id, [ReferenceCategory.KEY]), _KEY_EVIDENCE_MAX)
        )
        key_hits = _fuse(hit_lists, _KEY_EVIDENCE_MAX)
        if not key_hits:
            return rec.model_copy(
                update={
                    "recommended_action": RecommendedAction.REVIEW,
                    "verification_reasoning": "No Key Reference passages found to verify the existing statement.",
                }
            )
        chunks.update({h.chunk.chunk_id: h.chunk for h in key_hits})
        k_ids = {f"K{i}": h.chunk for i, h in enumerate(key_hits, start=1)}
        report_statements = "\n\n".join(
            f"[section {h.chunk.section_id} {h.chunk.section_title}]\n{h.chunk.content}" for h in report_hits
        )

        user = "\n\n".join(
            [
                f"FIELD: {ctx.field_name}",
                f"EXISTING (report section {ctx.section.section_id} {ctx.section.title}):\n{rec.existing_text}",
                f"WHERE THE REPORT STATES THIS FACT (other passages of the same report):\n{report_statements or 'none found'}",
                f"Citations the report uses in those sections: {'; '.join(sorted({c.citation for c in relevant_citations})) or 'none'}",
                f"PROPOSED ({rec.change_type.value}):\n{rec.proposed_text}\nRationale: {rec.rationale}",
                "PROPOSED EVIDENCE:\n"
                + "\n".join(f"- {e.citation} ({e.category.value}): \"{e.quote}\"" for e in rec.evidence),
                "KEY REFERENCES:\n" + _format_passages(k_ids),
            ]
        )
        verdict = self._llm.complete_json(self._p_verify.text, user, _Verdict)
        key_evidence = [_evidence_from_ref(ref, k_ids) for ref in verdict.supporting_evidence]
        return rec.model_copy(
            update={
                "recommended_action": _VERDICT_ACTION[verdict.verdict],
                "verification_reasoning": verdict.reasoning,
                "key_evidence": [e for e in key_evidence if e is not None],
            }
        )

    def _dossier(self, ctx: SectionContext, rec: Recommendation, chunks: dict[str, Chunk]) -> Recommendation:
        try:
            return self._build_dossier(ctx, rec, chunks)
        except Exception:
            log.exception("section %-6s dossier failed; keeping the finding without it", ctx.section.section_id)
            return rec

    def _build_dossier(self, ctx: SectionContext, rec: Recommendation, chunks: dict[str, Chunk]) -> Recommendation:
        limit = self._settings.analysis.dossier_sources
        query = f"{rec.existing_text} {rec.proposed_text}"[:_DOSSIER_QUERY_CHARS]
        vector = self._embeddings.embed_one(f"{rec.existing_text}\n{rec.proposed_text}")
        cited = [chunks[e.chunk_id] for e in (*rec.evidence, *rec.key_evidence) if e.chunk_id in chunks]
        hit_lists = [[SearchHit(chunk=c, score=1.0) for c in cited]]
        for category in dict.fromkeys([*self._settings.analysis.search_categories, ReferenceCategory.KEY]):
            hit_lists.append(self._search.hybrid_search(query, vector, build_filter(ctx.field_id, [category]), limit))
        hits = _per_document(_fuse(hit_lists, limit * 3), limit, _DOSSIER_PER_DOCUMENT)
        if not hits:
            return rec

        groups: dict[str, list[Chunk]] = {}
        for i, hit in enumerate(hits, start=1):
            chunks[hit.chunk.chunk_id] = hit.chunk
            before, after = self._neighbours(hit.chunk, chunks)
            groups[f"D{i}"] = [c for c in (hit.chunk, before, after) if c is not None]

        baseline = _baseline_year(rec.existing_text, ctx.section) if rec.change_type != ChangeType.NEW_INFORMATION else None
        check = (
            f"{rec.recommended_action.value}: {rec.verification_reasoning}" if rec.verification_reasoning else "not checked"
        )
        user = "\n\n".join([
            f"FIELD: {ctx.field_name}" + (f" (reservoir: {ctx.reservoir_name})" if ctx.reservoir_name else ""),
            f"CHANGE ({rec.change_type.value}) in section {ctx.section.section_id} {ctx.section.title}:\n"
            f"EXISTING: {rec.existing_text or '(addition — no existing text)'}\n"
            f"PROPOSED: {rec.proposed_text}\nRationale: {rec.rationale}",
            f"BASELINE YEAR: {baseline or 'none'}",
            f"KEY REFERENCE CHECK: {check}",
            "SOURCES:\n" + _format_dossier_sources(hits, groups),
        ])
        dossier = self._llm.complete_json(self._p_dossier.text, user, _Dossier)

        positions = []
        for note in dossier.sources:
            group = groups.get(note.id.strip().strip("[]"))
            if group is None:
                log.warning("section %-6s dossier cited unknown source id %r", ctx.section.section_id, note.id)
                continue
            chunk, quote = _chunk_with_quote(note.quote, group)
            evidence = _evidence_from_chunk(chunk, quote, note.translation)
            positions.append(SourcePosition(evidence=evidence, stance=SourceStance(note.position), states=note.states))
        compared = bool(positions)
        if not compared:
            log.warning("section %-6s dossier compared no sources; showing the finding's own evidence", ctx.section.section_id)
        listed = {p.evidence.document_id for p in positions}
        positions += [
            SourcePosition(evidence=e, stance=SourceStance.SUPPORTS, states=rec.proposed_text)
            for e in rec.evidence if e.document_id not in listed
        ]
        updated = rec.model_copy(
            update={"context_summary": dossier.context_summary.strip() or None, "source_comparison": positions}
        )

        revised = (dossier.revised_proposed_text or "").strip() if compared else ""
        if revised and " ".join(revised.split()) != " ".join(rec.proposed_text.split()):
            known = {e.chunk_id for e in rec.evidence}
            extra = [
                p.evidence for p in positions
                if p.stance == SourceStance.SUPPORTS and p.evidence.category != ReferenceCategory.KEY
                and p.evidence.chunk_id not in known
            ]
            candidate, _ = _apply_source_rules(
                updated.model_copy(update={
                    "proposed_text": revised,
                    "evidence": rec.evidence + extra,
                    "validation_notes": rec.validation_notes + ["Wording expanded from the cross-source comparison."],
                }),
                ctx.section,
            )
            if candidate is not None:
                updated = candidate
        log.info(
            "section %-6s dossier: %d source(s) compared%s", ctx.section.section_id, len(positions),
            ", wording expanded" if updated.proposed_text != rec.proposed_text else "",
        )
        return updated.model_copy(update={"validation_notes": list(dict.fromkeys(updated.validation_notes))})

    def _neighbours(self, chunk: Chunk, chunks: dict[str, Chunk]) -> tuple[Chunk | None, Chunk | None]:
        found = []
        for index in (chunk.chunk_index - 1, chunk.chunk_index + 1):
            if index < 0:
                found.append(None)
                continue
            chunk_id = f"{chunk.document_id}-{index:05d}"
            neighbour = chunks.get(chunk_id) or self._search.get_chunk(chunk_id)
            if neighbour is not None:
                chunks[chunk_id] = neighbour
            found.append(neighbour)
        return found[0], found[1]

    # ---------------------------------------------------------------- prompts

    def _query_input(self, ctx: SectionContext, instruction: str | None) -> str:
        parts = [
            f"FIELD: {ctx.field_name}" + (f" (reservoir: {ctx.reservoir_name})" if ctx.reservoir_name else ""),
            f"SECTION {ctx.section.section_id} {ctx.section.title}:\n{ctx.section.text}",
        ]
        if instruction:
            parts.append(f"REVIEWER INSTRUCTION (focus on this): {instruction}")
        return "\n\n".join(parts)

    def _analysis_input(
        self, ctx: SectionContext, e_ids: dict[str, Chunk], elsewhere: list[SearchHit], instruction: str | None
    ) -> str:
        r_ids = {f"R{i}": h.chunk for i, h in enumerate(elsewhere, start=1)}
        parts = [
            f"FIELD: {ctx.field_name}" + (f" (reservoir: {ctx.reservoir_name})" if ctx.reservoir_name else ""),
            f"SECTION {ctx.section.section_id} {ctx.section.title}:\n{ctx.section.text}",
            f"OUTLINE:\n{ctx.outline}",
            "ELSEWHERE IN REPORT:\n"
            + ("\n\n".join(f"[{rid}] section {c.section_id} {c.section_title}\n{c.content}" for rid, c in r_ids.items()) or "none"),
            "EVIDENCE:\n" + _format_passages(e_ids),
        ]
        if instruction:
            parts.append(f"REVIEWER INSTRUCTION (focus on this, rules still apply): {instruction}")
        return "\n\n".join(parts)

    def _to_recommendation(self, ctx: SectionContext, f: _Finding, e_ids: dict[str, Chunk]) -> Recommendation:
        evidence = [_evidence_from_ref(ref, e_ids) for ref in f.evidence]
        unknown = [ref.id for ref, e in zip(f.evidence, evidence) if e is None]
        return Recommendation(
            run_id=ctx.run_id,
            field_id=ctx.field_id,
            report_id=ctx.report_id,
            section_id=ctx.section.section_id,
            section_title=ctx.section.title,
            change_type=ChangeType(f.change_type),
            existing_text=f.existing_text,
            proposed_text=f.proposed_text,
            rationale=f.rationale,
            evidence=[e for e in evidence if e is not None],
            confidence=Confidence(f.confidence),
            impact=f.impact,
            model=self._llm.model_name,
            prompt_version=self.prompt_version,
            validation_notes=[f"Model cited unknown evidence id(s): {', '.join(unknown)}"] if unknown else [],
        )


# ---------------------------------------------------------------------- helpers


def _fuse(hit_lists: list[list[SearchHit]], limit: int) -> list[SearchHit]:
    """Reciprocal-rank fusion across several result lists, de-duplicated by chunk."""
    scores: dict[str, float] = defaultdict(float)
    best: dict[str, SearchHit] = {}
    for hits in hit_lists:
        for rank, hit in enumerate(hits, start=1):
            scores[hit.chunk.chunk_id] += 1.0 / (_RRF_K + rank)
            best.setdefault(hit.chunk.chunk_id, hit)
    order = sorted(scores, key=scores.__getitem__, reverse=True)[:limit]
    return [best[cid].model_copy(update={"score": scores[cid]}) for cid in order]


def _format_passages(ids: dict[str, Chunk]) -> str:
    blocks = []
    for pid, c in ids.items():
        pages = f"pp. {c.page_start}-{c.page_end}" if c.page_start != c.page_end else f"p. {c.page_start}"
        meta = " | ".join(str(x) for x in (c.citation, c.category.value, pages, c.language or "?", c.section_title or "") if x)
        blocks.append(f"[{pid}] {meta}\n{c.content}")
    return "\n\n".join(blocks)


def _per_document(hits: list[SearchHit], limit: int, per_document: int) -> list[SearchHit]:
    counts: dict[str, int] = defaultdict(int)
    kept = []
    for hit in hits:
        if counts[hit.chunk.document_id] < per_document:
            counts[hit.chunk.document_id] += 1
            kept.append(hit)
        if len(kept) == limit:
            break
    return kept


def _clip(text: str, words: int, tail: bool) -> str:
    parts = text.split()
    if len(parts) <= words:
        return text
    return "… " + " ".join(parts[-words:]) if tail else " ".join(parts[:words]) + " …"


def _format_dossier_sources(hits: list[SearchHit], groups: dict[str, list[Chunk]]) -> str:
    blocks = []
    for (did, group), hit in zip(groups.items(), hits):
        main = hit.chunk
        before = next((c for c in group[1:] if c.chunk_index < main.chunk_index), None)
        after = next((c for c in group[1:] if c.chunk_index > main.chunk_index), None)
        pages = f"pp. {main.page_start}-{main.page_end}" if main.page_start != main.page_end else f"p. {main.page_start}"
        meta = " | ".join(
            str(x) for x in (main.citation, main.category.value, main.publication_year, pages, main.language or "?",
                             main.section_title or "") if x
        )
        text = [f"[{did}] {meta}"]
        if before:
            text.append(f"(before) {_clip(before.content, _DOSSIER_NEIGHBOUR_WORDS, tail=True)}")
        text.append(f"(passage) {main.content}")
        if after:
            text.append(f"(after) {_clip(after.content, _DOSSIER_NEIGHBOUR_WORDS, tail=False)}")
        blocks.append("\n".join(text))
    return "\n\n".join(blocks)


_OMISSION = re.compile(r"\s*(?:\.{3,}|…)\s*")


def _quote_in(quote: str, text: str) -> bool:
    return bool(locate(quote, text, QUOTE_MIN_SCORE) or locate_abridged(quote, text, QUOTE_MIN_SCORE))


def _chunk_with_quote(quote: str, group: list[Chunk]) -> tuple[Chunk, str]:
    for chunk in group:
        if _quote_in(quote, chunk.content):
            return chunk, quote
    parts = [p.strip() for line in quote.splitlines() for p in _OMISSION.split(line) if p.strip()]
    best = max(group, key=lambda c: sum(_quote_in(p, c.content) for p in parts))
    kept = [p for p in parts if _quote_in(p, best.content)]
    return best, "\n".join(kept) if kept else quote


def _evidence_from_chunk(chunk: Chunk, quote: str, translation: str | None) -> Evidence:
    return Evidence(
        chunk_id=chunk.chunk_id,
        document_id=chunk.document_id,
        citation=chunk.citation,
        file_name=chunk.file_name,
        category=chunk.category,
        page_start=chunk.page_start,
        page_end=chunk.page_end,
        publication_year=chunk.publication_year,
        quote=quote,
        translation=translation,
    )


def _evidence_from_ref(ref: _EvidenceRef, ids: dict[str, Chunk]) -> Evidence | None:
    chunk = ids.get(ref.id.strip().strip("[]"))
    return None if chunk is None else _evidence_from_chunk(chunk, ref.quote, ref.translation)


def _apply_source_rules(rec: Recommendation, section: ReportSection) -> tuple[Recommendation | None, str | None]:
    """The 2020 report is the baseline (SME rules, 7 and 14 Oct):

    - Updates/conflicts may only be based on New References. Previously Unused references are for
      additions only; an update/conflict resting on them alone is dropped (Hernández et al. 2016 "1969").
    - An update/conflict to a cited statement needs a New Reference published AFTER the newest citation the
      report uses for that statement (the sentence's own citations, else its paragraph's).
    - Additions (new_information) may come from any New Reference regardless of year, and from Unused ones.
    """
    if rec.change_type == ChangeType.NEW_INFORMATION:
        return rec, None

    new_evidence = [e for e in rec.evidence if e.category == ReferenceCategory.NEW]
    if not new_evidence:
        return None, "change based only on Previously Unused references"

    baseline = _baseline_year(rec.existing_text, section)
    if baseline is not None:
        newer = [e for e in new_evidence if e.publication_year is not None and e.publication_year > baseline]
        if not newer:
            return None, f"no New Reference newer than the report's citation ({baseline}) for this statement"
        new_evidence = newer
    note = f"Only sources newer than the report's citation year ({baseline}) were used." if baseline else None
    return rec.model_copy(
        update={"evidence": new_evidence, "validation_notes": rec.validation_notes + ([note] if note else [])}
    ), None


def _baseline_year(existing_text: str, section: ReportSection) -> int | None:
    """Newest citation year backing a report statement: its own citations, else those of its paragraph."""
    years = citation_years(existing_text)
    if not years and existing_text.strip():
        for paragraph in section.paragraphs or [ExtractedParagraph(text=p, page=0, offset=0) for p in section.text.split("\n\n")]:
            if locate(existing_text, paragraph.text, 92):
                years = citation_years(paragraph.text)
                break
    return max(years) if years else None


def _split_words(text: str, size: int) -> list[str]:
    """Paragraph-respecting pieces of roughly `size` words, used as vector queries for the section."""
    pieces: list[str] = []
    current: list[str] = []
    count = 0
    for para in [p for p in text.split("\n\n") if p.strip()]:
        n = len(para.split())
        if current and count + n > size:
            pieces.append("\n\n".join(current))
            current, count = [], 0
        current.append(para)
        count += n
    if current:
        pieces.append("\n\n".join(current))
    return pieces
