from app.models import ReferenceCategory
from app.services.citation_validator import is_grounded, locate, validate_recommendation

from tests.conftest import make_chunk, make_evidence, make_recommendation

SOURCE = "El campo Lago Agrio fue descubierto en 1967 y puesto en producción en 1969 por la compañía Texaco."
SECTION = "The field was discovered in 1967 and brought onstream in 1972. STOIIP is 863.9 MMBO."
ALLOWED = [ReferenceCategory.NEW, ReferenceCategory.UNUSED]


def lookup_for(*chunks):
    by_id = {c.chunk_id: c for c in chunks}
    return by_id.get


def test_locate_exact_accent_insensitive_and_returns_source_span():
    assert locate("puesto en produccion en 1969", SOURCE, 90) == ("puesto en producción en 1969", 100.0)
    span, score = locate("puesto en  produción en 1969", SOURCE, 90)
    assert span == "puesto en producción en 1969" and 90 <= score < 100
    assert locate("started production in 1972", SOURCE, 90) is None


def test_verified_quote_takes_metadata_from_chunk_not_model():
    chunk = make_chunk("doc-00001", SOURCE, page_start=7, page_end=8, citation="Hernandez et al., 2016")
    rec = make_recommendation(
        [make_evidence("doc-00001", "puesto en produccion en 1969", page_start=99, citation="made up")],
        change_type="conflict", existing="brought onstream in 1972",
    )
    out = validate_recommendation(rec, SECTION, lookup_for(chunk), ALLOWED)
    ev = out.evidence[0]
    assert ev.verified and ev.quote == "puesto en producción en 1969"
    assert (ev.page_start, ev.page_end, ev.citation) == (7, 8, "Hernandez et al., 2016")
    assert is_grounded(out, SECTION)


def test_wrong_quote_is_dropped_and_rec_becomes_ungrounded():
    chunk = make_chunk("doc-00001", SOURCE)
    rec = make_recommendation([make_evidence("doc-00001", "production started in 1975 from 40 wells")], existing="brought onstream in 1972")
    out = validate_recommendation(rec, SECTION, lookup_for(chunk), ALLOWED)
    assert out.evidence == []
    assert any("quote not found" in n for n in out.validation_notes)
    assert not is_grounded(out, SECTION)


def test_cross_field_chunk_is_rejected():
    chunk = make_chunk("doc-00001", SOURCE, field_id="sulige")
    rec = make_recommendation([make_evidence("doc-00001", "puesto en producción en 1969")], existing="brought onstream in 1972")
    out = validate_recommendation(rec, SECTION, lookup_for(chunk), ALLOWED)
    assert out.evidence == [] and any("another field" in n for n in out.validation_notes)


def test_disallowed_category_is_rejected_for_support_but_key_allowed_for_verification():
    key_chunk = make_chunk("key-00001", "Production commenced in May 1972 from 24 producers.", category=ReferenceCategory.KEY)
    rec = make_recommendation(
        [make_evidence("key-00001", "Production commenced in May 1972")],
        key_evidence=[make_evidence("key-00001", "Production commenced in May 1972")],
        existing="brought onstream in 1972",
    )
    out = validate_recommendation(rec, SECTION, lookup_for(key_chunk), ALLOWED)
    assert out.evidence == []  # Key References are not evidence for a change
    assert len(out.key_evidence) == 1 and out.key_evidence[0].verified


def test_missing_chunk_and_missing_existing_text():
    rec = make_recommendation([make_evidence("nope", "x")], existing="sentence that is not in the section")
    out = validate_recommendation(rec, SECTION, lookup_for(), ALLOWED)
    assert any("not found in index" in n for n in out.validation_notes)
    assert any("Existing text not found" in n for n in out.validation_notes)


PROSE = (
    "El Campo Lago Agrio fue descubierto en abril de 1967 por el Consorcio Texaco-Gulf, pozo que se denominó así "
    "por Sour Lake. Lago Agrio - 01 alcanzó una producción de 2955 BPPD. Inició su etapa productiva en mayo de 1972."
)
TABLE = "\n".join([
    "Table: TABLA 1.2 CARACTERÍSTICAS",
    "| Formación | Zona | Tope - Base (ft) | Espesor (ft) | Porosidad |",
    "| --- | --- | --- | --- | --- |",
    "| HOLLÍN | Hollín Inf. | 9994 - 10161 | 184 a 295 | 8 % a 20 % |",
    "|  | Hollín Sup. | 9903 - 10048 | 16 a 70 |  |",
    "| Pb (psia) | 660 | 508 |",
    "| GOR (Scf/Bbl) | 188 | 117 |",
])


def _check(quote, content):
    chunk = make_chunk("doc-00001", content)
    rec = make_recommendation([make_evidence("doc-00001", quote)], change_type="new_information", existing="")
    return validate_recommendation(rec, SECTION, lookup_for(chunk), ALLOWED)


def test_prose_quote_abridged_with_ellipsis_is_verified_as_source_parts():
    out = _check("descubierto en abril de 1967 por el Consorcio Texaco-Gulf... Lago Agrio - 01 alcanzó una producción de 2955 BPPD.", PROSE)
    ev = out.evidence[0]
    assert ev.verified and "abridged" in ev.verification_note
    assert ev.quote == "descubierto en abril de 1967 por el Consorcio Texaco-Gulf … Lago Agrio - 01 alcanzó una producción de 2955 BPPD."


def test_lines_and_rows_from_one_passage_are_verified_even_out_of_order():
    out = _check("GOR (Scf/Bbl) | 188 | 117\nPb (psia) | 660 | 508\nInició su etapa productiva en mayo de 1972.", TABLE + "\n" + PROSE)
    assert out.evidence and out.evidence[0].verified


def test_table_row_with_a_column_left_out_is_verified():
    out = _check("HOLLÍN | Hollín Inf. | 184 a 295 | 8 % a 20 %", TABLE)
    assert out.evidence[0].quote == "| HOLLÍN | Hollín Inf. | 9994 - 10161 | 184 a 295 | 8 % a 20 % |"


def test_abridged_quote_with_an_invented_part_fails():
    assert _check("descubierto en abril de 1967... produjo 9000 BPPD desde el primer día.", PROSE).evidence == []


def test_rebuilt_table_rows_fail():
    assert _check("| Hollín Sup. | 184 a 295 |", TABLE).evidence == []  # cells from two different rows
    assert _check("| HOLLÍN | Porosidad 8 % a 20 % |", TABLE).evidence == []  # header label moved into the row
    assert _check("| Hollín Inf. | 184 a 295 | 9994 - 10161 |", TABLE).evidence == []  # cells reordered


def test_tiny_fragments_cannot_ground_a_quote():
    assert _check("Lago Agrio... 1969", PROSE).evidence == []
    assert _check("| ... | 508 |", TABLE).evidence == []  # a lone cell picked out of a row


def test_quote_longer_than_passage_needs_a_whole_match():
    short = "Production started in 1972."
    assert locate("Production started in 1972. It reached 90,000 BOPD in 1973 from 40 wells.", short, 90) is None
    assert locate("Production started in 1972.", short, 90) == (short, 100.0)


def test_new_information_with_unknown_anchor_appends_at_end():
    chunk = make_chunk("doc-00001", SOURCE)
    rec = make_recommendation(
        [make_evidence("doc-00001", "descubierto en 1967")], change_type="new_information", existing="not in section"
    )
    out = validate_recommendation(rec, SECTION, lookup_for(chunk), ALLOWED)
    assert out.existing_text == "" and is_grounded(out, SECTION)
