import pytest

from app.models import ReferenceCategory
from app.services.search_service import build_filter


def test_filter_always_scoped_to_field():
    assert build_filter("lago-agrio") == "field_id eq 'lago-agrio'"
    with pytest.raises(ValueError):
        build_filter("")


def test_filter_categories_and_exclusions():
    f = build_filter(
        "lago-agrio",
        [ReferenceCategory.NEW, ReferenceCategory.UNUSED],
        report_id="lago-agrio-2020",
        exclude_document_ids=["d1", "d2"],
    )
    assert f == (
        "field_id eq 'lago-agrio' and search.in(category, 'new,unused', ',') "
        "and report_id eq 'lago-agrio-2020' and not search.in(document_id, 'd1,d2', ',')"
    )


def test_filter_escapes_quotes():
    assert build_filter("o'brien") == "field_id eq 'o''brien'"


# ----------------------------------------------------- analyse_section orchestration

import re  # noqa: E402

from app.models import ChangeType, RecommendedAction, ReportCitation, ReportSection, SearchHit, SourceStance  # noqa: E402
from app.services.llm_service import Usage  # noqa: E402
from app.services.report_analysis_service import (  # noqa: E402
    ReportAnalysisService,
    SectionContext,
    _ChangeAnalysis,
    _Claim,
    _Dossier,
    _EvidenceRef,
    _Finding,
    _SectionQueries,
    _SourceNote,
    _Verdict,
)

from tests.conftest import make_chunk  # noqa: E402

SECTION_TEXT = "Production commenced in May 1972 (Sarango Sánchez, 2018). Oil rates peaked in 1973."
EXISTING = "Production commenced in May 1972 (Sarango Sánchez, 2018)."
NEW = make_chunk("card-00001", "El campo fue puesto en producción en 1969 según los registros.", category=ReferenceCategory.NEW,
                 document_id="card", citation="Cardenas, 2020", publication_year=2020, chunk_index=1)
OLD_NEW = make_chunk("del-00001", "El campo fue puesto en producción en 1969 según los registros.", category=ReferenceCategory.NEW,
                     document_id="del", citation="Del Pozo, 2009", publication_year=2009)
UNUSED = make_chunk("hern-00001", "The field was discovered in 1967 and was put in production in 1969.",
                    category=ReferenceCategory.UNUSED, citation="Hernandez et al., 2016", publication_year=2016)
KEY = make_chunk("sar-00003", "La producción del campo inició en mayo de 1972 con 24 pozos productores.",
                 category=ReferenceCategory.KEY, document_id="sar", citation="Sarango Sanchez, 2018", publication_year=2018,
                 chunk_index=3)
NEW_NEXT = make_chunk("card-00002", "La perforación del pozo descubridor comenzó en 1967 con apoyo de Texaco.",
                      category=ReferenceCategory.NEW, document_id="card", citation="Cardenas, 2020", publication_year=2020,
                      chunk_index=2)


class FakeSearch:
    def __init__(self, new_chunk=NEW):
        self.filters = []
        self.new_chunk = new_chunk

    def hybrid_search(self, text, vector, filter, top_k=None):
        self.filters.append((filter, top_k))
        if "'key'" in filter:
            return [SearchHit(chunk=KEY, score=1.0)]
        if "'report'" in filter:
            return []
        if "'unused'" in filter:
            return [SearchHit(chunk=UNUSED, score=1.0)]
        return [SearchHit(chunk=self.new_chunk, score=1.0)]

    def get_chunk(self, chunk_id):
        return {c.chunk_id: c for c in (NEW, NEW_NEXT, OLD_NEW, UNUSED, KEY)}.get(chunk_id)


class FakeEmbeddings:
    def embed(self, texts):
        return [[1.0, 0.0] for _ in texts]

    def embed_one(self, text):
        return [1.0, 0.0]


def _finding(change_type, evidence_id, quote, existing=EXISTING, proposed="Production commenced in 1969 (X, 2020)."):
    return _Finding(
        change_type=change_type, existing_text=existing, proposed_text=proposed, rationale="r",
        evidence=[_EvidenceRef(id=evidence_id, quote=quote, translation=None)], confidence="medium", impact="i",
    )


def source_id(prompt, citation):
    return re.search(rf"\[(D\d+)\] {re.escape(citation)} \|", prompt).group(1)


class FakeLLM:
    model_name = "fake"

    def __init__(self, findings, verdict="keep_existing", dossier=None):
        self.usage = Usage()
        self.findings = findings
        self.verdict = verdict
        self.dossier = dossier or (lambda prompt: _Dossier(context_summary="", sources=[], revised_proposed_text=None))
        self.prompts = []

    def complete_json(self, system, user, schema):
        self.prompts.append((schema.__name__, user))
        if schema is _SectionQueries:
            return _SectionQueries(claims=[_Claim(claim="first production 1972", query_en="Lago Agrio first production", query_es="inicio producción Lago Agrio")])
        if schema is _ChangeAnalysis:
            return _ChangeAnalysis(findings=self.findings, no_change_reason=None)
        if schema is _Verdict:
            return _Verdict(verdict=self.verdict, reasoning="Key reference confirms May 1972.",
                            supporting_evidence=[_EvidenceRef(id="K1", quote="inició en mayo de 1972", translation="started in May 1972")])
        if schema is _Dossier:
            return self.dossier(user)
        raise AssertionError(schema)


def _ctx():
    section = ReportSection(section_id="8.1", title="PRODUCTION HISTORY", level=2, order=1, text=SECTION_TEXT)
    return SectionContext(
        run_id="run1", field_id="lago-agrio", field_name="Lago Agrio", report_id="lago-agrio-2020", reservoir_name=None,
        section=section, outline="8.1 PRODUCTION HISTORY: ...",
        citations=[ReportCitation(citation="Sarango Sánchez, 2018", surname="Sarango Sánchez", year=2018, section_ids=["8.1"], document_id="sar")],
    )


def _analyse(settings, findings, search=None, verdict="keep_existing", instruction=None, dossier=None):
    search = search or FakeSearch()
    llm = FakeLLM(findings, verdict, dossier)
    result = ReportAnalysisService(settings, search, FakeEmbeddings(), llm).analyse_section(_ctx(), instruction=instruction)
    return result, search, llm


def test_evidence_quota_is_95_percent_new(settings):
    _, search, llm = _analyse(settings, [])
    evidence_searches = [(f, k) for f, k in search.filters if "'new'" in f or "'unused'" in f]
    assert all(f.startswith("field_id eq 'lago-agrio'") for f, _ in search.filters)
    prompt = next(u for name, u in llm.prompts if name == "_ChangeAnalysis")
    assert "[E1] Cardenas, 2020 | new" in prompt and "[E2] Hernandez et al., 2016 | unused" in prompt
    assert "'key'" not in "".join(f for f, _ in evidence_searches)
    service = ReportAnalysisService(settings, search, FakeEmbeddings(), llm)
    assert service._evidence_quotas([ReferenceCategory.NEW, ReferenceCategory.UNUSED]) == [
        (ReferenceCategory.NEW, 19), (ReferenceCategory.UNUSED, 1)
    ]


def test_conflict_from_newer_new_reference_is_verified_and_kept(settings):
    result, search, _ = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")])
    rec = result.recommendations[0]
    assert rec.recommended_action == RecommendedAction.KEEP_EXISTING
    assert rec.evidence[0].citation == "Cardenas, 2020" and rec.evidence[0].verified
    assert rec.key_evidence[0].citation == "Sarango Sanchez, 2018"
    assert any("search.in(document_id, 'sar', ',')" in f for f, _ in search.filters)  # cited Key Reference searched


def test_conflict_based_only_on_unused_reference_is_dropped(settings):
    result, _, _ = _analyse(settings, [_finding("conflict", "E2", "put in production in 1969")])
    assert result.recommendations == [] and result.ungrounded == []
    assert "Previously Unused" in result.discarded[0]


def test_change_needs_new_reference_newer_than_report_citation(settings):
    result, _, _ = _analyse(settings, [_finding("update", "E1", "puesto en producción en 1969")], search=FakeSearch(OLD_NEW))
    assert result.recommendations == []
    assert "newer than the report's citation (2018)" in result.discarded[0]


def test_unused_reference_can_still_add_information(settings):
    addition = _finding("new_information", "E2", "discovered in 1967", existing="", proposed="It was discovered in 1967 (Hernandez et al., 2016).")
    result, _, _ = _analyse(settings, [addition])
    assert len(result.recommendations) == 1 and result.recommendations[0].change_type == ChangeType.NEW_INFORMATION


def test_old_new_reference_can_still_add_information(settings):
    addition = _finding("new_information", "E1", "según los registros", existing="", proposed="Records exist (Del Pozo, 2009).")
    result, _, _ = _analyse(settings, [addition], search=FakeSearch(OLD_NEW))
    assert len(result.recommendations) == 1  # Rod: old-but-new-to-us references are still useful for additions


def test_invented_evidence_is_ungrounded(settings):
    result, _, _ = _analyse(settings, [_finding("new_information", "E9", "nothing", existing="", proposed="Invented.")])
    assert result.recommendations == [] and len(result.ungrounded) == 1


def test_reviewer_instruction_reaches_prompts(settings):
    _, _, llm = _analyse(settings, [], instruction="focus on start date")
    assert all("focus on start date" in u for name, u in llm.prompts if name in ("_SectionQueries", "_ChangeAnalysis"))


def _note(prompt, citation, position, quote, states="s"):
    return _SourceNote(id=source_id(prompt, citation), position=position, states=states, quote=quote, translation=None)


def test_dossier_compares_sources_across_documents_and_categories(settings):
    def dossier(prompt):
        return _Dossier(
            context_summary="The report cites Sarango (2018) for 1972; Cardenas (2020) gives 1969.",
            sources=[
                _note(prompt, "Cardenas, 2020", "supports", "puesto en producción en 1969"),
                _note(prompt, "Cardenas, 2020", "adds_detail", "La perforación del pozo descubridor comenzó en 1967"),
                _note(prompt, "Sarango Sanchez, 2018", "older_value", "inició en mayo de 1972"),
                _note(prompt, "Hernandez et al., 2016", "supports", "an invented quote that is nowhere"),
            ],
            revised_proposed_text=None,
        )

    result, search, llm = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")], dossier=dossier)
    rec = result.recommendations[0]
    prompt = next(u for name, u in llm.prompts if name == "_Dossier")
    assert "(after) La perforación del pozo descubridor" in prompt
    assert "Hernandez et al., 2016 | unused" in prompt and "Sarango Sanchez, 2018 | key" in prompt
    assert rec.context_summary.startswith("The report cites Sarango")
    stances = {(p.evidence.chunk_id, p.stance) for p in rec.source_comparison}
    assert stances == {
        ("card-00001", SourceStance.SUPPORTS), ("card-00002", SourceStance.ADDS_DETAIL), ("sar-00003", SourceStance.OLDER_VALUE)
    }
    assert all(p.evidence.verified and p.evidence.passage for p in rec.source_comparison)
    assert any("Dropped compared source Hernandez" in n for n in rec.validation_notes)
    assert rec.proposed_text == "Production commenced in 1969 (X, 2020)."


def test_dossier_revision_adds_new_sources_but_not_unused_ones_to_an_update(settings):
    def dossier(prompt):
        return _Dossier(
            context_summary="c",
            sources=[
                _note(prompt, "Cardenas, 2020", "supports", "puesto en producción en 1969"),
                _note(prompt, "Hernandez et al., 2016", "supports", "was put in production in 1969"),
            ],
            revised_proposed_text="Production commenced in 1969, as field records show (Cardenas, 2020).",
        )

    result, _, _ = _analyse(settings, [_finding("update", "E1", "puesto en producción en 1969")], dossier=dossier)
    rec = result.recommendations[0]
    assert rec.proposed_text == "Production commenced in 1969, as field records show (Cardenas, 2020)."
    assert [e.citation for e in rec.evidence] == ["Cardenas, 2020"]
    assert len(rec.source_comparison) == 2
    assert "Wording expanded from the cross-source comparison." in rec.validation_notes


def test_dossier_revision_can_add_supporting_sources_to_an_addition(settings):
    addition = _finding("new_information", "E2", "discovered in 1967", existing="", proposed="It was discovered in 1967 (Hernandez et al., 2016).")

    def dossier(prompt):
        return _Dossier(
            context_summary="c",
            sources=[_note(prompt, "Cardenas, 2020", "supports", "La perforación del pozo descubridor comenzó en 1967")],
            revised_proposed_text="The discovery well was drilled in 1967 (Hernandez et al., 2016; Cardenas, 2020).",
        )

    result, _, _ = _analyse(settings, [addition], dossier=dossier)
    assert {e.chunk_id for e in result.recommendations[0].evidence} == {"hern-00001", "card-00002"}


def test_dossier_quote_spanning_two_passages_keeps_the_parts_in_one(settings):
    def dossier(prompt):
        spanning = "puesto en producción en 1969 según los registros.\nLa perforación del pozo descubridor comenzó en 1967"
        return _Dossier(context_summary="c", sources=[_note(prompt, "Cardenas, 2020", "supports", spanning)], revised_proposed_text=None)

    result, _, _ = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")], dossier=dossier)
    [position] = result.recommendations[0].source_comparison
    assert position.evidence.verified and position.evidence.chunk_id in ("card-00001", "card-00002")


def test_dossier_with_no_sources_still_lists_own_evidence_and_keeps_wording(settings):
    def dossier(prompt):
        return _Dossier(context_summary="c", sources=[_SourceNote(id="D99", position="supports", states="s", quote="q", translation=None)],
                        revised_proposed_text="An unsupported rewrite (Somebody, 2030).")

    result, _, _ = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")], dossier=dossier)
    rec = result.recommendations[0]
    assert rec.proposed_text == "Production commenced in 1969 (X, 2020)."
    assert [(p.evidence.citation, p.stance) for p in rec.source_comparison] == [("Cardenas, 2020", SourceStance.SUPPORTS)]


def test_dossier_adds_own_evidence_document_the_model_left_out(settings):
    def dossier(prompt):
        return _Dossier(context_summary="c", sources=[_note(prompt, "Sarango Sanchez, 2018", "older_value", "inició en mayo de 1972")],
                        revised_proposed_text=None)

    result, _, _ = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")], dossier=dossier)
    assert {p.evidence.citation for p in result.recommendations[0].source_comparison} == {"Sarango Sanchez, 2018", "Cardenas, 2020"}


def test_dossier_failure_keeps_the_finding(settings):
    def dossier(prompt):
        raise RuntimeError("model timeout")

    result, _, _ = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")], dossier=dossier)
    assert len(result.recommendations) == 1 and result.recommendations[0].source_comparison == []


def test_dossier_can_be_switched_off(settings):
    settings.analysis.dossier = False
    _, _, llm = _analyse(settings, [_finding("conflict", "E1", "puesto en producción en 1969")])
    assert "_Dossier" not in [name for name, _ in llm.prompts]
