"""Domain models shared across ingestion, retrieval, analysis and review."""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import StrEnum

from pydantic import BaseModel, Field, model_validator


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _new_id() -> str:
    return uuid.uuid4().hex


# --------------------------------------------------------------------------- enums


class ReferenceCategory(StrEnum):
    """Where a document sits in the field folder layout."""

    REPORT = "report"
    KEY = "key"  # used to write the current report
    UNUSED = "unused"  # reviewed but not used
    NEW = "new"  # found after the report was written

    @property
    def folder_name(self) -> str:
        return _CATEGORY_FOLDERS[self]


# Folder names as they exist in the source container, relative to "<Field Name>/".
# Report PDFs sit directly in the field folder, so REPORT maps to "".
_CATEGORY_FOLDERS = {
    ReferenceCategory.REPORT: "",
    ReferenceCategory.KEY: "Key References",
    ReferenceCategory.UNUSED: "Unused References",
    ReferenceCategory.NEW: "New References",
}


class ChangeType(StrEnum):
    UPDATE = "update"  # existing statement should change
    NEW_INFORMATION = "new_information"  # addition not covered by the report
    CONFLICT = "conflict"  # sources disagree; needs a human judgement


class ReviewStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class AuditAction(StrEnum):
    APPROVE = "approve"
    EDIT = "edit"
    REJECT = "reject"
    UNDO = "undo"
    COMMENT = "comment"
    PUBLISH = "publish"


class RecommendedAction(StrEnum):
    APPLY = "apply"  # AI suggests making the change
    KEEP_EXISTING = "keep_existing"  # conflict checked against Key References; existing text is better supported
    REVIEW = "review"  # evidence balanced or insufficient; reviewer must open the sources


class SourceStance(StrEnum):
    SUPPORTS = "supports"
    CONTRADICTS = "contradicts"
    ADDS_DETAIL = "adds_detail"
    OLDER_VALUE = "older_value"


class Confidence(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


# ----------------------------------------------------------------------- documents


class SourceDocument(BaseModel):
    """A report or reference file stored in Blob Storage."""

    document_id: str
    field_id: str  # stable ID; survives field renames
    field_name: str
    reservoir_id: str
    report_id: str
    category: ReferenceCategory
    blob_path: str
    file_name: str
    title: str | None = None
    authors: list[str] = Field(default_factory=list)
    publication_year: int | None = None
    language: str | None = None  # ISO 639-1, e.g. "en", "es"
    citation: str | None = None  # short form, e.g. "Hernández et al., 2016"
    page_count: int | None = None
    size_bytes: int | None = None


class ReportRole(StrEnum):
    CURRENT = "current"  # the report being updated
    GROUND_TRUTH = "ground_truth"  # later version, held back for evaluation only


class ReportVersion(BaseModel):
    report_id: str  # "<field_id>-<year>"
    field_id: str
    year: int
    flag: str | None = None  # "N" or "U" from the DAKS file name
    reservoir_name: str | None = None  # e.g. "Upper Hollin" for reservoir-level reports
    blob_path: str
    role: ReportRole


class IngestionStatus(StrEnum):
    PENDING = "pending"
    EXTRACTED = "extracted"
    INDEXED = "indexed"
    SKIPPED = "skipped"
    FAILED = "failed"


class IngestionRecord(BaseModel):
    """One row of a field's ingestion manifest."""

    document: SourceDocument
    status: IngestionStatus = IngestionStatus.PENDING
    reason: str | None = None  # skip reason or error message
    chunk_count: int = 0
    updated_at: datetime = Field(default_factory=_utcnow)


# ------------------------------------------------------------------------ extraction


class ExtractedParagraph(BaseModel):
    text: str
    role: str | None = None  # Document Intelligence role: title, sectionHeading, footnote …
    page: int
    offset: int  # position in the document's reading order


class ExtractedTable(BaseModel):
    markdown: str
    header: str  # markdown header + separator rows, repeated when a table is split
    rows: list[str]  # markdown body rows
    caption: str | None = None
    page_start: int
    page_end: int
    offset: int


class ExtractedDocument(BaseModel):
    """Normalised Document Intelligence output, in reading order."""

    document_id: str
    model_id: str
    page_count: int
    paragraphs: list[ExtractedParagraph]
    tables: list[ExtractedTable]

    @property
    def text(self) -> str:
        return "\n".join(p.text for p in self.paragraphs)


class SectionKind(StrEnum):
    BODY = "body"  # numbered narrative section — analysed
    TABLES = "tables"  # data tables (Table 1, 2, 3 …) — analysed
    REFERENCES = "references"  # the report's reference list — used for citation tracing, not analysed
    FRONT_MATTER = "front_matter"  # title page, table of contents — ignored


class ReportSection(BaseModel):
    """A numbered section of an RE report, e.g. 8.1 Production History."""

    section_id: str  # "8.1"
    title: str
    kind: SectionKind = SectionKind.BODY
    level: int = Field(ge=1)
    parent_id: str | None = None
    order: int  # position in the report
    text: str
    page_start: int | None = None
    page_end: int | None = None
    paragraphs: list[ExtractedParagraph] = Field(default_factory=list, repr=False)
    tables: list[ExtractedTable] = Field(default_factory=list, repr=False)


class ReportCitation(BaseModel):
    """An (Author, Year) citation found in the report, linked to a source file when possible."""

    citation: str  # as written in the report, e.g. "Sarango Sanchez, 2018"
    surname: str
    year: int
    section_ids: list[str] = Field(default_factory=list)
    document_id: str | None = None  # matched Key/Unused/New reference


class Chunk(BaseModel):
    """A retrievable passage. Never crosses a section boundary."""

    chunk_id: str
    document_id: str
    field_id: str
    field_name: str
    reservoir_id: str
    report_id: str
    category: ReferenceCategory
    file_name: str
    citation: str | None = None
    publication_year: int | None = None
    language: str | None = None
    section_id: str | None = None
    section_title: str | None = None
    page_start: int | None = None
    page_end: int | None = None
    chunk_index: int
    content: str
    embedding: list[float] | None = Field(default=None, exclude=True, repr=False)


class SearchHit(BaseModel):
    chunk: Chunk
    score: float
    reranker_score: float | None = None


# -------------------------------------------------------------------------- analysis


class Evidence(BaseModel):
    """A quoted passage supporting a recommendation."""

    chunk_id: str
    document_id: str
    citation: str | None = None
    file_name: str
    category: ReferenceCategory
    page_start: int | None = None
    page_end: int | None = None
    publication_year: int | None = None
    quote: str  # verbatim text from the source (original language)
    translation: str | None = None  # English rendering when the source isn't English
    verified: bool = False  # set by citation_validator
    verification_note: str | None = None
    passage: str | None = None


class SourcePosition(BaseModel):
    evidence: Evidence
    stance: SourceStance
    states: str


class Recommendation(BaseModel):
    """One AI-suggested change to one report section."""

    recommendation_id: str = Field(default_factory=_new_id)
    run_id: str
    field_id: str
    report_id: str
    section_id: str
    section_title: str
    change_type: ChangeType
    # update/conflict: the exact report text to replace.
    # new_information: the report sentence the addition follows ("" = end of section).
    existing_text: str
    proposed_text: str  # replacement text, or only the new sentence(s) for new_information
    rationale: str
    evidence: list[Evidence] = Field(default_factory=list)  # supporting evidence from New/Unused References
    key_evidence: list[Evidence] = Field(default_factory=list)  # Key Reference passages from conflict verification
    recommended_action: RecommendedAction = RecommendedAction.APPLY
    verification_reasoning: str | None = None
    context_summary: str | None = None
    source_comparison: list[SourcePosition] = Field(default_factory=list)
    confidence: Confidence = Confidence.MEDIUM
    impact: str | None = None
    validation_notes: list[str] = Field(default_factory=list)
    model: str | None = None
    prompt_version: str | None = None
    created_at: datetime = Field(default_factory=_utcnow)

    @property
    def is_grounded(self) -> bool:
        return bool(self.evidence) and all(e.verified for e in self.evidence)


class AnalysisRun(BaseModel):
    run_id: str = Field(default_factory=_new_id)
    field_id: str
    report_id: str
    categories_searched: list[ReferenceCategory]
    started_at: datetime = Field(default_factory=_utcnow)
    finished_at: datetime | None = None
    sections_total: int = 0
    sections_done: int = 0
    recommendations: list[Recommendation] = Field(default_factory=list)
    ungrounded: list[Recommendation] = Field(default_factory=list)  # failed citation validation; shown separately
    section_notes: dict[str, str] = Field(default_factory=dict)  # e.g. why a section needs no change
    discarded: list[str] = Field(default_factory=list)  # findings removed by source rules (unused-only, older than report citation)
    # Drafted on the Final report page from the approved changes, and reviewed there (not in Review changes).
    executive_summary: Recommendation | None = None
    executive_summary_basis: list[str] = Field(default_factory=list)  # ids of the approved changes it was drafted from
    errors: list[str] = Field(default_factory=list)
    model: str | None = None
    prompt_version: str | None = None
    llm_calls: int = 0
    llm_input_tokens: int = 0
    llm_output_tokens: int = 0


# ---------------------------------------------------------------------------- review


class ReviewState(BaseModel):
    """Current review position of a recommendation."""

    recommendation_id: str
    status: ReviewStatus = ReviewStatus.PENDING
    final_text: str | None = None  # proposed_text, or the reviewer's edited version
    edited: bool = False
    reviewer: str | None = None
    comment: str | None = None
    updated_at: datetime = Field(default_factory=_utcnow)


class AuditEvent(BaseModel):
    """Append-only record of every review action."""

    event_id: str = Field(default_factory=_new_id)
    run_id: str
    recommendation_id: str | None = None  # None for report-level events like publish
    action: AuditAction
    reviewer: str
    comment: str | None = None
    text_before: str | None = None
    text_after: str | None = None
    timestamp: datetime = Field(default_factory=_utcnow)

    @model_validator(mode="after")
    def _reject_needs_reason(self) -> AuditEvent:
        if self.action == AuditAction.REJECT and not (self.comment and self.comment.strip()):
            raise ValueError("A rejection must include a comment explaining why.")
        if self.action != AuditAction.PUBLISH and self.recommendation_id is None:
            raise ValueError(f"'{self.action}' events must reference a recommendation.")
        return self
