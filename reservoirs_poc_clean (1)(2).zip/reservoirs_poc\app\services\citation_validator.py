"""Ground every recommendation in indexed source text.

For each evidence item:
- the cited chunk must exist and belong to the run's field (a cross-field chunk is a hard failure)
- its category must be one the run was allowed to use
- the quote must be found in the chunk text (exactly, or fuzzily ≥ threshold); the displayed quote is
  then replaced by the exact source span, so reviewers always see verbatim text
- an abridged quote is accepted when every part of it is in the same chunk: prose pieces joined with
  "..." / "…" or quoted on separate lines, and table rows with columns left out (each quoted cell must
  be in one source row, in order). Nothing may be added: a header label moved into a row, a cell from
  another row or a rebuilt/transposed table still fails. The displayed quote is the source parts joined by " … "
- page numbers, citation and file name are copied from the chunk, never trusted from the model

`existing_text` must be found in the section. A recommendation with no verified evidence, or whose
existing_text cannot be located for an update/conflict, is ungrounded.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Iterable

from rapidfuzz import fuzz

from app.models import ChangeType, Chunk, Evidence, Recommendation, ReferenceCategory
from app.utils.text_utils import strip_accents, word_count

QUOTE_MIN_SCORE = 90
EXISTING_MIN_SCORE = 92
_MIN_PIECE_WORDS = 3  # a prose piece of an abridged quote must be checkable on its own ("1969" alone is not)

# "...", "…", "[...]", "(…)" — the model's mark for omitted text
_ELLIPSIS = re.compile(r"\s*(?:\[\s*(?:\.{3,}|…)\s*\]|\(\s*(?:\.{3,}|…)\s*\)|\.{3,}|…)\s*")

ChunkLookup = Callable[[str], Chunk | None]


def _fold(text: str) -> str:
    """Lowercase and strip accents one character at a time, so offsets map 1:1 onto the original."""
    out = []
    for ch in text:
        folded = strip_accents(ch).lower()
        out.append(folded[0] if folded else ch)
    return "".join(out)


def locate(needle: str, haystack: str, min_score: float) -> tuple[str, float] | None:
    """The exact span of `haystack` best matching `needle`, with its score; None if below `min_score`.

    Matching ignores case and accents; the returned span is the original source text.
    """
    if not needle.strip() or not haystack.strip():
        return None
    folded_needle, folded_haystack = _fold(needle), _fold(haystack)
    if len(folded_needle) > len(folded_haystack):
        # partial_ratio would align the haystack inside the needle, so text added around a short
        # passage would score 100. A needle longer than the passage must match it as a whole.
        score = fuzz.ratio(folded_needle, folded_haystack)
        return (haystack, score) if score >= min_score else None
    alignment = fuzz.partial_ratio_alignment(folded_needle, folded_haystack)
    if alignment is None or alignment.score < min_score:
        return None
    return haystack[alignment.dest_start : alignment.dest_end], alignment.score


def _row_cells(row: str) -> list[str]:
    """Non-empty cells of a markdown table row, folded and single-spaced, with omission marks removed."""
    cells = (" ".join(_fold(_ELLIPSIS.sub(" ", cell)).split()) for cell in row.strip().strip("|").split("|"))
    return [c for c in cells if c]


def _locate_row(cells: list[str], haystack: str) -> str | None:
    """The source table row containing every quoted cell, in order (columns may be skipped)."""
    for line in haystack.splitlines():
        if "|" not in line:
            continue
        source = iter(_row_cells(line))
        if all(any(cell == candidate for candidate in source) for cell in cells):
            return line.strip()
    return None


def locate_abridged(quote: str, haystack: str, min_score: float) -> tuple[str, bool] | None:
    """Verify a quote that skips text: lines checked separately, prose split at ellipses, table rows by cell.

    Returns the matched source parts joined by " … " and whether any prose part matched only fuzzily;
    None if any part is missing, a prose part is too short to check, or nothing substantive was quoted.
    """
    parts: list[str] = []
    substantive = fuzzy = False
    for line in quote.splitlines():
        if not line.strip():
            continue
        if "|" in line:
            cells = _row_cells(line)
            if not cells:
                continue  # a row of empty cells quotes nothing
            row = _locate_row(cells, haystack)
            if row is None:
                return None
            parts.append(row)
            substantive = substantive or len(cells) >= 2
            continue
        for piece in (p.strip() for p in _ELLIPSIS.split(line)):
            if not re.search(r"\w", piece):
                continue
            if word_count(piece) < _MIN_PIECE_WORDS:
                return None
            found = locate(piece, haystack, min_score)
            if found is None:
                return None
            parts.append(found[0])
            substantive = True
            fuzzy = fuzzy or found[1] < 99.5
    return (" … ".join(parts), fuzzy) if parts and substantive else None


def validate_evidence(
    evidence: Evidence,
    lookup: ChunkLookup,
    field_id: str,
    allowed: Iterable[ReferenceCategory],
) -> Evidence:
    chunk = lookup(evidence.chunk_id)
    if chunk is None:
        return evidence.model_copy(update={"verified": False, "verification_note": "cited passage not found in index"})
    if chunk.field_id != field_id:
        return evidence.model_copy(
            update={"verified": False, "verification_note": f"passage belongs to another field ({chunk.field_id})"}
        )
    from_chunk = {
        "document_id": chunk.document_id,
        "citation": chunk.citation,
        "file_name": chunk.file_name,
        "category": chunk.category,
        "page_start": chunk.page_start,
        "page_end": chunk.page_end,
        "publication_year": chunk.publication_year,
        "passage": chunk.content,
    }
    if chunk.category not in set(allowed):
        return evidence.model_copy(
            update={**from_chunk, "verified": False, "verification_note": f"category '{chunk.category}' not allowed here"}
        )
    found = locate(evidence.quote, chunk.content, QUOTE_MIN_SCORE)
    if found is not None:
        quote, score = found
        note = None if score >= 99.5 else f"fuzzy match {score:.0f}%"
        return evidence.model_copy(update={**from_chunk, "quote": quote, "verified": True, "verification_note": note})
    abridged = locate_abridged(evidence.quote, chunk.content, QUOTE_MIN_SCORE)
    if abridged is not None:
        quote, fuzzy = abridged
        note = "abridged quote: every part found in the cited passage; text between parts omitted" + (
            " (fuzzy match)" if fuzzy else ""
        )
        return evidence.model_copy(update={**from_chunk, "quote": quote, "verified": True, "verification_note": note})
    return evidence.model_copy(
        update={
            **from_chunk,
            "verified": False,
            "verification_note": f"quote not found in the cited passage: \"{evidence.quote}\"",
        }
    )


def validate_recommendation(
    rec: Recommendation,
    section_text: str,
    lookup: ChunkLookup,
    allowed: Iterable[ReferenceCategory],
) -> Recommendation:
    """Return a copy with verified evidence only, failures recorded in `validation_notes`."""
    allowed = list(allowed)
    notes = list(rec.validation_notes)

    checked = [validate_evidence(e, lookup, rec.field_id, allowed) for e in rec.evidence]
    for e in checked:
        if not e.verified:
            notes.append(f"Dropped evidence {e.citation or e.chunk_id}: {e.verification_note}")
    key_checked = [
        validate_evidence(e, lookup, rec.field_id, [ReferenceCategory.KEY, *allowed]) for e in rec.key_evidence
    ]
    for e in key_checked:
        if not e.verified:
            notes.append(f"Dropped key evidence {e.citation or e.chunk_id}: {e.verification_note}")
    comparison = [
        p.model_copy(update={"evidence": validate_evidence(p.evidence, lookup, rec.field_id, [ReferenceCategory.KEY, *allowed])})
        for p in rec.source_comparison
    ]
    for p in comparison:
        if not p.evidence.verified:
            notes.append(f"Dropped compared source {p.evidence.citation or p.evidence.chunk_id}: {p.evidence.verification_note}")

    existing = rec.existing_text
    if existing.strip():
        found = locate(existing, section_text, EXISTING_MIN_SCORE)
        if found is not None:
            existing = found[0]
        elif rec.change_type == ChangeType.NEW_INFORMATION:
            notes.append("Insertion point not found in section; addition will go at the end of the section.")
            existing = ""
        else:
            notes.append("Existing text not found in the section.")

    return rec.model_copy(
        update={
            "existing_text": existing,
            "evidence": [e for e in checked if e.verified],
            "key_evidence": [e for e in key_checked if e.verified],
            "source_comparison": [p for p in comparison if p.evidence.verified],
            "validation_notes": notes,
        }
    )


def is_grounded(rec: Recommendation, section_text: str) -> bool:
    """Reviewable: at least one verified evidence item, and replacement text that exists in the section."""
    if not rec.evidence:
        return False
    if rec.change_type != ChangeType.NEW_INFORMATION:
        return bool(rec.existing_text.strip()) and locate(rec.existing_text, section_text, EXISTING_MIN_SCORE) is not None
    return True
