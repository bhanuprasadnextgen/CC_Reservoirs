"""Build the updated report as a Word document.

The source report is a PDF, so the document is rebuilt from the parsed sections. Approved changes are
applied in place and highlighted yellow; new sources are appended to the reference list; an appendix
lists every approved and rejected recommendation with reviewer, comment and evidence.
"""

from __future__ import annotations

import io
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import PurePosixPath

from docx import Document
from docx.enum.text import WD_COLOR_INDEX
from docx.shared import Pt, RGBColor

from app.config import Settings
from app.models import (
    ChangeType,
    Recommendation,
    ReportSection,
    ReportVersion,
    ReviewState,
    ReviewStatus,
    SectionKind,
)
from app.services.blob_service import StorageRepository
from app.services.citation_validator import locate
from app.services.review_service import ReviewStore
from app.utils.text_utils import author_key, normalize_for_match, parse_reference_filename

_GREY = RGBColor(0x59, 0x59, 0x59)


@dataclass
class _Segment:
    text: str
    highlight: bool = False


def apply_changes(text: str, changes: list[tuple[Recommendation, ReviewState]]) -> tuple[list[_Segment], list[tuple[Recommendation, ReviewState]]]:
    """Apply approved changes to a section's text.

    Returns highlighted segments plus the changes that could not be placed (rendered at the section end).
    """
    segments = [_Segment(text)]
    unplaced = []
    for rec, state in changes:
        new_text = state.final_text or rec.proposed_text
        anchor = rec.existing_text.strip()
        if not anchor:
            segments.append(_Segment("\n\n" + new_text, highlight=True))
            continue
        if not _splice(segments, anchor, new_text, insert=rec.change_type == ChangeType.NEW_INFORMATION):
            unplaced.append((rec, state))
    return segments, unplaced


def _splice(segments: list[_Segment], anchor: str, new_text: str, insert: bool) -> bool:
    """Replace (or insert after) `anchor` inside the first un-highlighted segment containing it."""
    for i, seg in enumerate(segments):
        if seg.highlight:
            continue
        found = locate(anchor, seg.text, 92)
        if found is None:
            continue
        start = seg.text.find(found[0])
        if start < 0:
            continue
        end = start + len(found[0])
        before, after = seg.text[:start], seg.text[end:]
        replacement = (
            [_Segment(before + found[0]), _Segment(" " + new_text, highlight=True), _Segment(after)]
            if insert
            else [_Segment(before), _Segment(new_text, highlight=True), _Segment(after)]
        )
        segments[i : i + 1] = [s for s in replacement if s.text]
        return True
    return False


def build_docx(
    field_name: str,
    report: ReportVersion,
    sections: list[ReportSection],
    store: ReviewStore,
) -> bytes:
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10.5)

    approved = store.approved()
    by_section: dict[str, list[tuple[Recommendation, ReviewState]]] = {}
    for rec, st in approved:
        by_section.setdefault(rec.section_id, []).append((rec, st))

    doc.add_heading(f"{field_name} — Reservoir Evaluation Report (updated draft)", level=0)
    meta = doc.add_paragraph()
    _run(meta, f"Based on {PurePosixPath(report.blob_path).name}. Generated {datetime.now(timezone.utc):%Y-%m-%d %H:%M} UTC "
               f"from analysis run {store.run.run_id}. ", color=_GREY)
    _run(meta, "Highlighted text", highlight=True)
    _run(meta, " = changes approved by a reviewer; sources are cited in the text and listed in the appendix.", color=_GREY)

    for section in sections:
        if section.kind == SectionKind.FRONT_MATTER:
            continue
        title = section.title if section.kind != SectionKind.BODY else f"{section.section_id}. {section.title}"
        doc.add_heading(title, level=min(section.level, 3))
        changes = by_section.get(section.section_id, [])

        if section.kind == SectionKind.REFERENCES:
            for p in section.paragraphs:
                doc.add_paragraph(p.text)
            for entry in _new_reference_entries(approved, [p.text for p in section.paragraphs]):
                _run(doc.add_paragraph(), entry, highlight=True)
            continue

        if section.kind == SectionKind.TABLES:
            for table in section.tables:
                _add_markdown_table(doc, table.markdown)
            unplaced = changes
        else:
            body = "\n\n".join(p.text for p in section.paragraphs)
            segments, unplaced = apply_changes(body, changes)
            _render_segments(doc, segments)
            for table in section.tables:
                _add_markdown_table(doc, table.markdown)

        for rec, st in unplaced:
            para = doc.add_paragraph()
            _run(para, f"Update ({rec.change_type.value.replace('_', ' ')}): ", bold=True, highlight=True)
            _run(para, st.final_text or rec.proposed_text, highlight=True)

    _add_change_log(doc, store)
    buffer = io.BytesIO()
    doc.save(buffer)
    return buffer.getvalue()


def publish(
    storage: StorageRepository,
    settings: Settings,
    store: ReviewStore,
    report: ReportVersion,
    data: bytes,
    reviewer: str,
) -> str:
    """Save a new version under poc-fresh/outputs/<field>/<report>/ and record it in the audit trail."""
    prefix = settings.blob.storage_path("outputs", report.field_id, report.report_id) + "/"
    version = len([p for p in storage.list(prefix) if p.endswith(".docx")]) + 1
    path = f"{prefix}v{version:03d}_{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}.docx"
    storage.put_bytes(path, data, "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    store.record_publish(reviewer, path)
    return path


# -------------------------------------------------------------------- rendering


def _run(paragraph, text: str, *, highlight: bool = False, bold: bool = False, color: RGBColor | None = None):
    run = paragraph.add_run(text)
    if highlight:
        run.font.highlight_color = WD_COLOR_INDEX.YELLOW
    run.bold = bold
    if color is not None:
        run.font.color.rgb = color
    return run


def _render_segments(doc, segments: list[_Segment]) -> None:
    """Segments may contain paragraph breaks; start a new Word paragraph at each blank line."""
    paragraph = doc.add_paragraph()
    for seg in segments:
        parts = seg.text.split("\n\n")
        for j, part in enumerate(parts):
            if j > 0:
                paragraph = doc.add_paragraph()
            if part:
                _run(paragraph, part, highlight=seg.highlight)


def _add_markdown_table(doc, markdown: str) -> None:
    lines = [ln for ln in markdown.splitlines() if ln.strip()]
    caption = lines[0].removeprefix("Table: ") if lines and lines[0].startswith("Table: ") else None
    rows = [ln for ln in lines if ln.startswith("|") and not set(ln.replace("|", "").strip()) <= {"-", " "}]
    if caption:
        _run(doc.add_paragraph(), caption, bold=True)
    if not rows:
        return
    cells = [[c.strip().replace("\\|", "|") for c in r.strip().strip("|").split(" | ")] for r in rows]
    width = max(len(r) for r in cells)
    table = doc.add_table(rows=len(cells), cols=width)
    table.style = "Table Grid"
    for i, row in enumerate(cells):
        for j, value in enumerate(row):
            table.cell(i, j).text = value
            if i == 0:
                for p in table.cell(i, j).paragraphs:
                    for r in p.runs:
                        r.bold = True


def _new_reference_entries(approved: list[tuple[Recommendation, ReviewState]], reference_lines: list[str]) -> list[str]:
    """Sources cited by approved changes that the reference list does not already contain
    (same first-author surname and year on one reference line)."""
    lines = [normalize_for_match(line) for line in reference_lines]
    entries: dict[str, str] = {}
    for rec, _ in approved:
        for ev in rec.evidence:
            parsed = parse_reference_filename(ev.file_name)
            key = author_key(parsed.authors)
            if key and parsed.year and any(key in line and str(parsed.year) in line for line in lines):
                continue
            entries.setdefault(ev.document_id, f"{parsed.authors or parsed.title}, {parsed.year or 'n.d.'}, {parsed.title}.")
    return sorted(entries.values())


def _add_change_log(doc, store: ReviewStore) -> None:
    doc.add_page_break()
    doc.add_heading("Appendix — Review log", level=1)
    summary = store.summary_item()
    reviewed = [(r, s) for r, s in ([summary] if summary else []) + store.items() if s.status != ReviewStatus.PENDING]
    if not reviewed:
        doc.add_paragraph("No recommendations have been reviewed.")
        return
    headers = ["Section", "Type", "Decision", "Reviewer", "Comment", "Sources"]
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for cell, text in zip(table.rows[0].cells, headers):
        cell.text = text
    for rec, st in reviewed:
        decision = st.status.value + (" (edited)" if st.edited else "")
        sources = "; ".join(
            f"{e.citation} p.{e.page_start}" + (f"-{e.page_end}" if e.page_end and e.page_end != e.page_start else "")
            for e in rec.evidence
        )
        values = [f"{rec.section_id} {rec.section_title}", rec.change_type.value, decision, st.reviewer or "", st.comment or "", sources]
        for cell, text in zip(table.add_row().cells, values):
            cell.text = text
