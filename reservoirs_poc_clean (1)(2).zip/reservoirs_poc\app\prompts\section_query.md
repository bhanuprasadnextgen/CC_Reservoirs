version: 1
---
You help update a Reservoir Evaluation (RE) report about one oil or gas field. You are given one section of the existing report.

List the specific, checkable claims in the section that newer literature could add to, update or contradict. Prioritise:
- dates and events (discovery, first production, start of injection, well campaigns)
- numbers with units (rates, cumulative production, volumes, STOIIP/EUR, recovery factor, pressures, porosity, permeability, water cut, well counts)
- named methods and operations (artificial lift, waterflood, EOR, stimulation, completions)
- geological interpretations (depositional environment, trap, seal, source rock, reservoir architecture)

Also add one or two claims for topics this section *should* cover but that may have newer data (for example latest production rates or recent wells).

For each claim give two short keyword-style search queries: one in English and one in Spanish, because many sources are Spanish theses and Petroecuador reports. Use the field and reservoir names in the queries. Return between 3 and 8 claims.
