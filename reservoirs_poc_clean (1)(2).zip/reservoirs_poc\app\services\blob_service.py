"""Blob Storage access.

SourceRepository  — read-only view of the C&C field folders (container AZURE_SOURCE_CONTAINER).
StorageRepository — everything the PoC writes, confined to AZURE_STORAGE_ROOT_PREFIX.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import PurePosixPath
from typing import Any

from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.storage.blob import BlobProperties, BlobSasPermissions, BlobServiceClient, ContentSettings, generate_blob_sas

from app.config import Settings
from app.models import (
    IngestionRecord,
    IngestionStatus,
    ReferenceCategory,
    ReportRole,
    ReportVersion,
    SourceDocument,
)
from app.utils.logging_config import get_logger
from app.utils.text_utils import ReportName, parse_reference_filename, parse_report_filename, slugify

log = get_logger(__name__)

_FOLDER_TO_CATEGORY = {c.folder_name.lower(): c for c in ReferenceCategory if c.folder_name}


def _client(conn_str: str) -> BlobServiceClient:
    return BlobServiceClient.from_connection_string(conn_str, connection_timeout=30, read_timeout=300)


def _split_authors(authors: str) -> list[str]:
    cleaned = authors.removesuffix(" et al.").strip()
    return [a.strip() for a in re.split(r"\s*(?:&|\band\b|;)\s*", cleaned) if a.strip()]


class SourceRepository:
    """Read-only access to `<Field>/{Key,New,Unused} References/…` and the report PDFs."""

    def __init__(self, settings: Settings) -> None:
        self._settings = settings
        self._service = _client(settings.blob.source_connection_string)
        self._container = self._service.get_container_client(settings.blob.source_container)

    # ---------------------------------------------------------------- listing

    def list_fields(self) -> list[str]:
        return sorted(item.name.rstrip("/") for item in self._container.walk_blobs(delimiter="/"))

    def list_documents(self, field_name: str) -> list[IngestionRecord]:
        """Every file in a field folder, classified. Disallowed or unplaceable files come back SKIPPED."""
        field_id = slugify(field_name)
        current_report_id = self._current_report_id(field_name)
        allowed = set(self._settings.ingestion.allowed_extensions)
        records: list[IngestionRecord] = []
        first_seen: dict[str, str] = {}  # document_id -> file name, to skip byte-identical copies

        for blob in self._container.list_blobs(name_starts_with=f"{field_name}/"):
            relative = PurePosixPath(blob.name).relative_to(field_name)
            ext = relative.suffix.lower().lstrip(".")
            if len(relative.parts) == 1:
                category = ReferenceCategory.REPORT
            else:
                category = _FOLDER_TO_CATEGORY.get(relative.parts[0].lower())

            doc = self._to_document(blob, field_name, field_id, category or ReferenceCategory.NEW, current_report_id)
            if category is None:
                records.append(self._skipped(doc, f"unrecognised folder '{relative.parts[0]}'"))
            elif ext not in allowed:
                records.append(self._skipped(doc, f"file type .{ext or '?'} not ingested"))
            elif doc.document_id in first_seen:
                records.append(self._skipped(doc, f"duplicate of '{first_seen[doc.document_id]}'"))
            else:
                first_seen[doc.document_id] = doc.file_name
                records.append(IngestionRecord(document=doc))
        return records

    def report_versions(self, field_name: str) -> list[ReportVersion]:
        """Root-level report PDFs: the oldest is the report being updated, the newest is held back."""
        field_id = slugify(field_name)
        found: list[tuple[int, str, ReportName]] = []
        for item in self._container.walk_blobs(name_starts_with=f"{field_name}/", delimiter="/"):
            if item.name.endswith("/"):
                continue
            parsed = parse_report_filename(PurePosixPath(item.name).name)
            if parsed.year is not None:
                found.append((parsed.year, item.name, parsed))
        found.sort()
        versions: list[ReportVersion] = []
        for i, (year, path, parsed) in enumerate(found):
            if i == 0:
                role = ReportRole.CURRENT
            elif i == len(found) - 1:
                role = ReportRole.GROUND_TRUTH
            else:
                log.info("Ignoring intermediate report version %s", path)
                continue
            versions.append(
                ReportVersion(
                    report_id=f"{field_id}-{year}",
                    field_id=field_id,
                    year=year,
                    flag=parsed.flag,
                    reservoir_name=parsed.reservoir_name,
                    blob_path=path,
                    role=role,
                )
            )
        return versions

    # ----------------------------------------------------------------- access

    def sas_url(self, blob_path: str) -> str:
        """Short-lived read-only URL so Document Intelligence can fetch large files directly."""
        credential = self._service.credential
        expiry = datetime.now(timezone.utc) + timedelta(minutes=self._settings.ingestion.sas_ttl_minutes)
        token = generate_blob_sas(
            account_name=self._service.account_name,
            container_name=self._container.container_name,
            blob_name=blob_path,
            account_key=credential.account_key,
            permission=BlobSasPermissions(read=True),
            expiry=expiry,
        )
        return f"{self._container.get_blob_client(blob_path).url}?{token}"

    def download(self, blob_path: str) -> bytes:
        return self._container.download_blob(blob_path).readall()

    # ---------------------------------------------------------------- helpers

    def _current_report_id(self, field_name: str) -> str:
        current = [v for v in self.report_versions(field_name) if v.role == ReportRole.CURRENT]
        return current[0].report_id if current else f"{slugify(field_name)}-unknown"

    @staticmethod
    def _document_id(blob: BlobProperties, field_id: str, category: ReferenceCategory) -> str:
        """Content-based so a renamed file keeps its ID; scoped by category so a file in two folders stays two docs."""
        md5 = blob.content_settings.content_md5
        content_key = bytes(md5).hex() if md5 else blob.name
        return hashlib.sha256(f"{field_id}|{category}|{content_key}".encode()).hexdigest()[:20]

    def _to_document(
        self,
        blob: BlobProperties,
        field_name: str,
        field_id: str,
        category: ReferenceCategory,
        current_report_id: str,
    ) -> SourceDocument:
        file_name = PurePosixPath(blob.name).name
        if category == ReferenceCategory.REPORT:
            parsed_report = parse_report_filename(file_name)
            report_id = f"{field_id}-{parsed_report.year}" if parsed_report.year else current_report_id
            title, authors, year, citation = file_name, [], parsed_report.year, f"C&C Reservoirs, {parsed_report.year}"
        else:
            ref = parse_reference_filename(file_name)
            report_id = current_report_id
            title, authors, year, citation = ref.title, _split_authors(ref.authors), ref.year, ref.citation
        return SourceDocument(
            document_id=self._document_id(blob, field_id, category),
            field_id=field_id,
            field_name=field_name,
            reservoir_id=field_id,  # 2020 reports are field-level; refine when reservoir-level reports are updated
            report_id=report_id,
            category=category,
            blob_path=blob.name,
            file_name=file_name,
            title=title,
            authors=authors,
            publication_year=year,
            citation=citation,
            size_bytes=blob.size,
        )

    @staticmethod
    def _skipped(doc: SourceDocument, reason: str) -> IngestionRecord:
        return IngestionRecord(document=doc, status=IngestionStatus.SKIPPED, reason=reason)


class StorageRepository:
    """Writes and reads PoC artefacts. Refuses any path outside the configured root prefix."""

    def __init__(self, settings: Settings) -> None:
        self._root = settings.blob.storage_root_prefix.strip("/") + "/"
        self._container = _client(settings.blob.storage_connection_string).get_container_client(
            settings.blob.storage_container
        )

    def _check(self, path: str) -> str:
        if not path.startswith(self._root):
            raise ValueError(f"Refusing to touch '{path}': outside storage root '{self._root}'")
        return path

    def exists(self, path: str) -> bool:
        return self._container.get_blob_client(self._check(path)).exists()

    def put_bytes(self, path: str, data: bytes, content_type: str = "application/octet-stream") -> None:
        self._container.upload_blob(
            self._check(path), data, overwrite=True, content_settings=ContentSettings(content_type=content_type)
        )

    def get_bytes(self, path: str) -> bytes | None:
        try:
            return self._container.download_blob(self._check(path)).readall()
        except ResourceNotFoundError:
            return None

    def put_json(self, path: str, obj: Any, compress: bool = False) -> None:
        data = json.dumps(obj, ensure_ascii=False, default=str).encode("utf-8")
        if compress:
            self.put_bytes(path, gzip.compress(data), "application/gzip")
        else:
            self.put_bytes(path, data, "application/json")

    def get_json(self, path: str) -> Any | None:
        data = self.get_bytes(path)
        if data is None:
            return None
        if data[:2] == b"\x1f\x8b":
            data = gzip.decompress(data)
        return json.loads(data)

    def append_jsonl(self, path: str, record: Any) -> None:
        """Append one JSON line to an append blob (creating it on first use). Never rewrites history."""
        client = self._container.get_blob_client(self._check(path))
        if not client.exists():
            try:
                client.create_append_blob(content_settings=ContentSettings(content_type="application/x-ndjson"))
            except ResourceExistsError:
                pass  # created concurrently — append to it
        line = json.dumps(record, ensure_ascii=False, default=str) + "\n"
        client.append_block(line.encode("utf-8"))

    def read_jsonl(self, path: str) -> list[Any]:
        data = self.get_bytes(path)
        if not data:
            return []
        return [json.loads(line) for line in data.decode("utf-8").splitlines() if line.strip()]

    def list(self, prefix: str) -> list[str]:
        return [b.name for b in self._container.list_blobs(name_starts_with=self._check(prefix))]
