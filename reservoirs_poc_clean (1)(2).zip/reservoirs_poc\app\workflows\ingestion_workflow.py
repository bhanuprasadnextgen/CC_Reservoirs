"""Ingest one field: list → extract (cached) → chunk → embed → index, tracked in a manifest.

Re-runs are idempotent: documents already INDEXED are skipped unless `reindex=True`.
The ground-truth (newest) report is extracted and parsed for evaluation but never indexed,
so analysis can't "find" the answer it is evaluated against.
"""

from __future__ import annotations

import threading
from collections import Counter
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from app.config import Settings, get_settings
from app.models import (
    ExtractedDocument,
    IngestionRecord,
    IngestionStatus,
    ReferenceCategory,
    ReportCitation,
    ReportRole,
    ReportSection,
    ReportVersion,
    SourceDocument,
    _utcnow,
)
from app.services.blob_service import SourceRepository, StorageRepository
from app.services.chunking_service import chunk_document, embedding_text
from app.services.document_intelligence_service import DocumentIntelligenceService
from app.services.embedding_service import EmbeddingService
from app.services.report_parser import parse_report_citations, parse_sections
from app.services.search_service import SearchService
from app.utils.logging_config import get_logger
from app.utils.text_utils import detect_language, slugify

log = get_logger(__name__)

ProgressCallback = Callable[[IngestionRecord, int, int], None]


@dataclass
class IngestionServices:
    settings: Settings
    source: SourceRepository
    storage: StorageRepository
    docintel: DocumentIntelligenceService
    embeddings: EmbeddingService
    search: SearchService

    @classmethod
    def create(cls, settings: Settings | None = None) -> IngestionServices:
        settings = settings or get_settings()
        storage = StorageRepository(settings)
        return cls(
            settings=settings,
            source=SourceRepository(settings),
            storage=storage,
            docintel=DocumentIntelligenceService(settings, storage),
            embeddings=EmbeddingService(settings),
            search=SearchService(settings),
        )


@dataclass
class IngestionResult:
    field_id: str
    records: list[IngestionRecord]
    reports: list[ReportVersion]
    counts: Counter = field(default_factory=Counter)


# ----------------------------------------------------------------- artefact paths


def manifest_path(settings: Settings, field_id: str) -> str:
    return settings.blob.storage_path("runs", "ingestion", f"{field_id}.json")


def sections_path(settings: Settings, field_id: str, report_id: str) -> str:
    return settings.blob.storage_path("runs", "reports", field_id, f"{report_id}.sections.json")


def citations_path(settings: Settings, field_id: str, report_id: str) -> str:
    return settings.blob.storage_path("runs", "reports", field_id, f"{report_id}.citations.json")


def load_manifest(storage: StorageRepository, settings: Settings, field_id: str) -> list[IngestionRecord]:
    data = storage.get_json(manifest_path(settings, field_id)) or []
    return [IngestionRecord.model_validate(r) for r in data]


def load_sections(storage: StorageRepository, settings: Settings, field_id: str, report_id: str) -> list[ReportSection]:
    data = storage.get_json(sections_path(settings, field_id, report_id)) or []
    return [ReportSection.model_validate(s) for s in data]


def load_citations(storage: StorageRepository, settings: Settings, field_id: str, report_id: str) -> list[ReportCitation]:
    data = storage.get_json(citations_path(settings, field_id, report_id)) or []
    return [ReportCitation.model_validate(c) for c in data]


# ------------------------------------------------------------------------ workflow


def ingest_field(
    field_name: str,
    *,
    categories: list[ReferenceCategory] | None = None,
    limit: int | None = None,
    dry_run: bool = False,
    reindex: bool = False,
    services: IngestionServices | None = None,
    progress: ProgressCallback | None = None,
) -> IngestionResult:
    svc = services or IngestionServices.create()
    settings = svc.settings
    field_id = slugify(field_name)

    reports = svc.source.report_versions(field_name)
    report_role = {v.blob_path: v.role for v in reports}
    listed = svc.source.list_documents(field_name)
    previous = {r.document.document_id: r for r in load_manifest(svc.storage, settings, field_id)}

    # Carry forward finished work; everything else is (re)queued.
    records: list[IngestionRecord] = []
    for rec in listed:
        prior = previous.get(rec.document.document_id)
        if prior and prior.status == IngestionStatus.INDEXED and not reindex:
            records.append(prior)
        else:
            records.append(rec)

    # The current report goes first: its sections are needed to chunk it.
    def priority(r: IngestionRecord) -> tuple[int, str]:
        role = report_role.get(r.document.blob_path)
        return (0 if role == ReportRole.CURRENT else 1 if role else 2, r.document.file_name)

    todo = [
        r
        for r in sorted(records, key=priority)
        if r.status in (IngestionStatus.PENDING, IngestionStatus.FAILED)
        or (reindex and r.status == IngestionStatus.INDEXED)
        # Held-back report versions are cheap to redo (cached) and keep their parsed sections current.
        or r.status == IngestionStatus.EXTRACTED
    ]
    if categories:
        allowed = set(categories) | {ReferenceCategory.REPORT}
        todo = [r for r in todo if r.document.category in allowed]
    if limit is not None:
        todo = todo[:limit]

    result = IngestionResult(field_id=field_id, records=records, reports=reports)
    if dry_run:
        result.counts = Counter(r.status.value for r in records)
        return result

    svc.search.ensure_index()
    lock = threading.Lock()
    by_id = {r.document.document_id: i for i, r in enumerate(records)}
    references = [r.document for r in records if r.document.category != ReferenceCategory.REPORT]

    def save(record: IngestionRecord) -> None:
        with lock:
            records[by_id[record.document.document_id]] = record
            svc.storage.put_json(manifest_path(settings, field_id), [r.model_dump(mode="json") for r in records])

    def run_one(record: IngestionRecord) -> IngestionRecord:
        doc = record.document
        role = report_role.get(doc.blob_path)
        try:
            extracted = svc.docintel.extract(doc, svc.source.sas_url)
            doc = doc.model_copy(
                update={"page_count": extracted.page_count, "language": detect_language(extracted.text)}
            )
            if doc.category == ReferenceCategory.REPORT:
                sections = _store_report_artefacts(svc, doc, extracted, references)
                if role != ReportRole.CURRENT:
                    return _finish(record, doc, IngestionStatus.EXTRACTED, reason="report version held back from index")
                chunks = chunk_document(extracted, doc, settings.chunking, report_sections=sections)
            else:
                chunks = chunk_document(extracted, doc, settings.chunking)

            if record.chunk_count:
                svc.search.delete_document(doc.document_id)  # chunk count may have shrunk
            if chunks:
                vectors = svc.embeddings.embed([embedding_text(c) for c in chunks])
                svc.search.upload_chunks(chunks, vectors)
                return _finish(record, doc, IngestionStatus.INDEXED, chunk_count=len(chunks))
            return _finish(record, doc, IngestionStatus.SKIPPED, reason="no extractable text")
        except Exception as err:  # one bad file must not stop the field
            log.exception("failed     %s", doc.file_name)
            return _finish(record, doc, IngestionStatus.FAILED, reason=f"{type(err).__name__}: {err}"[:500])

    # The current report runs alone first so its artefacts exist before references are processed.
    head = [r for r in todo if report_role.get(r.document.blob_path) == ReportRole.CURRENT]
    rest = [r for r in todo if r not in head]
    done = 0
    for rec in head:
        finished = run_one(rec)
        save(finished)
        done += 1
        if progress:
            progress(finished, done, len(todo))

    with ThreadPoolExecutor(max_workers=settings.ingestion.docintel_concurrency) as pool:
        futures = [pool.submit(run_one, r) for r in rest]
        for future in as_completed(futures):
            finished = future.result()
            save(finished)
            done += 1
            if progress:
                progress(finished, done, len(todo))

    result.records = records
    result.counts = Counter(r.status.value for r in records)
    log.info("ingested   %s: %s (embedding tokens %d)", field_name, dict(result.counts), svc.embeddings.total_tokens)
    return result


def _store_report_artefacts(
    svc: IngestionServices, doc: SourceDocument, extracted: ExtractedDocument, references: list[SourceDocument]
) -> list[ReportSection]:
    sections = parse_sections(extracted)
    citations = parse_report_citations(sections, references)
    s = svc.settings
    svc.storage.put_json(sections_path(s, doc.field_id, doc.report_id), [x.model_dump(mode="json") for x in sections])
    svc.storage.put_json(citations_path(s, doc.field_id, doc.report_id), [c.model_dump(mode="json") for c in citations])
    log.info("report     %s: %d sections, %d citations", doc.file_name, len(sections), len(citations))
    return sections


def _finish(
    record: IngestionRecord,
    doc: SourceDocument,
    status: IngestionStatus,
    *,
    reason: str | None = None,
    chunk_count: int = 0,
) -> IngestionRecord:
    log.info("%-10s %s%s", status.value, doc.file_name, f" ({chunk_count} chunks)" if chunk_count else "")
    return record.model_copy(
        update={"document": doc, "status": status, "reason": reason, "chunk_count": chunk_count, "updated_at": _utcnow()}
    )
