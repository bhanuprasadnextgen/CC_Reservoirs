"""Application settings, loaded from environment variables / .env."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Literal
from urllib.parse import urlsplit

from pydantic import Field, field_validator, model_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict
from typing_extensions import Annotated

from app.models import ReferenceCategory

PROJECT_ROOT = Path(__file__).resolve().parent.parent
PROMPTS_DIR = PROJECT_ROOT / "app" / "prompts"


def _section(prefix: str) -> SettingsConfigDict:
    return SettingsConfigDict(
        env_prefix=prefix,
        env_file=PROJECT_ROOT / ".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )


class AppSettings(BaseSettings):
    model_config = _section("APP_")

    env: Literal["dev", "test", "prod"] = "dev"
    log_level: str = "INFO"
    log_dir: Path = Path("logs")
    cache_dir: Path = Path(".cache")

    @field_validator("log_dir", "cache_dir")
    @classmethod
    def _resolve(cls, v: Path) -> Path:
        return v if v.is_absolute() else PROJECT_ROOT / v


class AzureSettings(BaseSettings):
    """Account-level extras."""

    model_config = _section("")

    key_vault_url: str = ""
    applicationinsights_connection_string: str = ""


class BlobSettings(BaseSettings):
    """Source = C&C documents (read-only). Storage = PoC outputs, extraction cache, audit trail."""

    model_config = _section("AZURE_")

    source_connection_string: str = ""
    source_container: str = "report-update"
    storage_connection_string: str = ""
    storage_container: str = "report-update-poc"
    # Everything this PoC writes lives under this folder, isolated from earlier data in the container.
    storage_root_prefix: str = "poc-fresh"

    def storage_path(self, area: Literal["cache", "outputs", "audit", "runs"], *parts: str) -> str:
        """Build a blob path inside the PoC's storage root, e.g. poc-fresh/cache/Lago Agrio/x.json."""
        return "/".join(p.strip("/") for p in (self.storage_root_prefix, area, *parts) if p)


class DocumentIntelligenceSettings(BaseSettings):
    model_config = _section("AZURE_DOCINTEL_")

    endpoint: str = ""
    key: str = ""
    model_id: str = "prebuilt-layout"


class SearchSettings(BaseSettings):
    model_config = _section("AZURE_SEARCH_")

    endpoint: str = ""
    key: str = ""
    index: str = "cc-reservoir-chunks-v3"
    top_k: int = Field(8, ge=1, le=1000)
    use_semantic_ranker: bool = False  # needs the semantic ranker enabled on the search service


class AzureOpenAISettings(BaseSettings):
    model_config = _section("AZURE_OPENAI_")

    endpoint: str = ""
    api_key: str = ""
    api_version: str = "2025-04-01-preview"
    chat_deployment: str = ""
    embedding_deployment: str = "text-embedding-3-large"
    embedding_dimensions: int = 1536

    @field_validator("endpoint")
    @classmethod
    def _base_url_only(cls, v: str) -> str:
        """Accept a full portal URL (…/openai/responses?api-version=…) and keep only the resource base."""
        if not v:
            return v
        parts = urlsplit(v.strip())
        return f"{parts.scheme}://{parts.netloc}/"


class AnthropicSettings(BaseSettings):
    model_config = _section("ANTHROPIC_")

    api_key: str = ""
    base_url: str = ""
    model: str = ""


class LLMSettings(BaseSettings):
    model_config = _section("LLM_")

    provider: Literal["azure_openai", "anthropic"] = "azure_openai"
    temperature: float = Field(0.0, ge=0.0, le=1.0)  # ignored by reasoning models (gpt-5.x)
    reasoning_effort: Literal["minimal", "low", "medium", "high"] = "medium"
    max_output_tokens: int = Field(16000, ge=256)  # includes reasoning tokens for gpt-5.x
    retry_budget_seconds: int = Field(600, ge=30)  # how long one call may wait out rate limits


class ChunkingSettings(BaseSettings):
    model_config = _section("CHUNK_")

    words: int = Field(350, ge=50)
    overlap_words: int = Field(50, ge=0)

    @model_validator(mode="after")
    def _overlap_smaller_than_chunk(self) -> ChunkingSettings:
        if self.overlap_words >= self.words:
            raise ValueError("CHUNK_OVERLAP_WORDS must be smaller than CHUNK_WORDS")
        return self


class IngestionSettings(BaseSettings):
    model_config = _section("INGEST_")

    allowed_extensions: Annotated[list[str], NoDecode] = ["pdf"]
    docintel_concurrency: int = Field(4, ge=1, le=16)
    docintel_max_pages_per_call: int = Field(2000, ge=1)
    sas_ttl_minutes: int = Field(60, ge=5)

    @field_validator("allowed_extensions", mode="before")
    @classmethod
    def _split_csv(cls, v: object) -> object:
        if isinstance(v, str):
            return [part.strip().lower().lstrip(".") for part in v.split(",") if part.strip()]
        return v


class AnalysisSettings(BaseSettings):
    model_config = _section("ANALYSIS_")

    search_categories: Annotated[list[ReferenceCategory], NoDecode] = [
        ReferenceCategory.NEW,
        ReferenceCategory.UNUSED,
    ]
    verify_conflicts_with_key_refs: bool = True
    max_concurrent_sections: int = Field(2, ge=1, le=32)
    evidence_per_section: int = Field(20, ge=5, le=60)
    # Share of evidence slots for Previously Unused references (the rest go to New References).
    # Unused references may only contribute additions, never updates/conflicts.
    unused_share: float = Field(0.05, ge=0.0, le=0.5)
    dossier: bool = True
    dossier_sources: int = Field(8, ge=3, le=20)

    @field_validator("search_categories", mode="before")
    @classmethod
    def _split_csv(cls, v: object) -> object:
        if isinstance(v, str):
            return [part.strip().lower() for part in v.split(",") if part.strip()]
        return v


class Settings:
    """Groups all setting sections. Use get_settings() rather than constructing directly."""

    def __init__(self) -> None:
        self.app = AppSettings()
        self.azure = AzureSettings()
        self.blob = BlobSettings()
        self.docintel = DocumentIntelligenceSettings()
        self.search = SearchSettings()
        self.aoai = AzureOpenAISettings()
        self.anthropic = AnthropicSettings()
        self.llm = LLMSettings()
        self.chunking = ChunkingSettings()
        self.ingestion = IngestionSettings()
        self.analysis = AnalysisSettings()

    def missing_required(self) -> list[str]:
        """Names of settings that must be filled before running against Azure."""
        required = {
            "AZURE_SOURCE_CONNECTION_STRING": self.blob.source_connection_string,
            "AZURE_STORAGE_CONNECTION_STRING": self.blob.storage_connection_string,
            "AZURE_DOCINTEL_ENDPOINT": self.docintel.endpoint,
            "AZURE_SEARCH_ENDPOINT": self.search.endpoint,
            "AZURE_OPENAI_ENDPOINT": self.aoai.endpoint,
            "AZURE_OPENAI_EMBEDDING_DEPLOYMENT": self.aoai.embedding_deployment,
        }
        missing = [name for name, value in required.items() if not value]
        if self.llm.provider == "azure_openai" and not self.aoai.chat_deployment:
            missing.append("AZURE_OPENAI_CHAT_DEPLOYMENT")
        if self.llm.provider == "anthropic" and not self.anthropic.model:
            missing.append("ANTHROPIC_MODEL")
        return missing


@lru_cache
def get_settings() -> Settings:
    return Settings()
