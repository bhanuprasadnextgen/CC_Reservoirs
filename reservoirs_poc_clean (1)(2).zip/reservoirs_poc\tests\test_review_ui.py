from app.models import SourcePosition, SourceStance
from app.ui.review import comparison_table, highlight_passage, stance_summary

from tests.conftest import make_evidence


def test_highlight_marks_each_part_of_an_abridged_quote_and_escapes_html():
    passage = "Rates <5%> fell.\nThe field produced 1,200 bopd in 2022. Water cut rose to 90%."
    html = highlight_passage(passage, "produced 1,200 bopd … Water cut rose")
    assert "<mark>produced 1,200 bopd</mark>" in html and "<mark>Water cut rose</mark>" in html
    assert "&lt;5%&gt;" in html and "<br>" in html


def test_stance_summary_counts_sources():
    positions = [
        SourcePosition(evidence=make_evidence(), stance=s, states="x")
        for s in (SourceStance.SUPPORTS, SourceStance.SUPPORTS, SourceStance.CONTRADICTS)
    ]
    assert stance_summary(positions) == "2 sources support · 1 source contradicts"


def test_comparison_table_keeps_cells_on_one_row():
    p = SourcePosition(evidence=make_evidence(citation="Petroecuador, 2024", publication_year=2024), stance=SourceStance.SUPPORTS,
                       states="| Capacidad |\n2.0 MMbbl")
    row = comparison_table([p]).splitlines()[2]
    assert row == "| Petroecuador, 2024 | 2024 | New reference | ✅ Supports | \\| Capacidad \\| 2.0 MMbbl |"
