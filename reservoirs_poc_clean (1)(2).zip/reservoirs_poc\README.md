# C&C Reservoirs — AI Report Update Assistant (PoC)

Updates existing Reservoir Evaluation (RE) reports using new reference documents.
The AI suggests changes with citations; a human approves, edits or rejects every one.

## Pipeline

```
Blob (field folders) ─► Document Intelligence ─► report_parser / chunking ─► embeddings ─► Azure AI Search
                                                                                              │
Streamlit ◄─ review_service ◄─ citation_validator ◄─ evidence dossier ◄─ report_analysis (LLM) ◄─ hybrid retrieval
                                                     (per suggestion)                              (per report section)
    │
    └─► report_export (DOCX, approved changes highlighted) ─► Blob (versioned) + audit trail
```

## Quick start

Requires **Python 3.11 or newer** (3.10 fails with `cannot import name 'StrEnum'`).
With Conda: `conda create -n cc311 python=3.11 -y && conda activate cc311`, then `pip install -r requirements.txt`.

```bash
python -m venv .venv && .venv/bin/pip install -r requirements.txt   # or: uv venv && uv pip install -r requirements.txt
cp .env.example .env            # fill in the Azure values
source .venv/bin/activate

python -m scripts.check_connections                     # all 5 Azure services reachable
python -m scripts.create_index                          # creates AZURE_SEARCH_INDEX if missing
python -m scripts.ingest_field "Lago Agrio" --dry-run   # list and classify files
python -m scripts.ingest_field "Lago Agrio"             # extract → chunk → embed → index (resumable)
python -m scripts.run_analysis "Lago Agrio"             # "Find updates" from the CLI (optional)
python -m scripts.run_evaluation "Lago Agrio"           # score the latest run against the later report
streamlit run streamlit_app.py                          # review UI
pytest                                                  # offline unit tests
```

On Windows, create the environment with `python -m venv .venv-win` and use `.venv-win\Scripts\python.exe -m pip install -r requirements.txt`,
then run the same commands with `.venv-win\Scripts\python.exe -m …` (e.g. `.venv-win\Scripts\python.exe -m streamlit run streamlit_app.py`).
A `.venv` copied from Linux does not work on Windows. If port 8501 is taken, add `--server.port 8502`.

## Data layout and isolation

Source (read-only), container `AZURE_SOURCE_CONTAINER`:

```
<Field>/
├── DAKS <Field> N2020 Report.pdf            ← oldest: the report being updated
├── DAKS <Field>_<Reservoir> U2026 Report.pdf ← newest: held back for evaluation, never indexed
├── Key References/      ← used to write the report (conflict verification only)
├── Unused References/   ← reviewed but not used (searched)
└── New References/      ← found after the report (searched)
```

Only PDFs are ingested (`INGEST_ALLOWED_EXTENSIONS=pdf`); other files are listed as skipped with a reason.

Everything the PoC writes goes under `AZURE_STORAGE_CONTAINER/AZURE_STORAGE_ROOT_PREFIX` (`poc-fresh/`):
`cache/` (Document Intelligence results), `runs/` (ingestion manifests, parsed reports, analysis runs,
review state, evaluations), `audit/` (append-only review log), `outputs/` (versioned Word reports).
The search index is `AZURE_SEARCH_INDEX` (`cc-reservoir-chunks-v3`).

## How the analysis works

Per report section: the LLM lists checkable claims with English + Spanish queries → hybrid search
(keyword + vector, RRF) restricted to the field and to New/Unused references → related passages from
other report sections are fetched so covered facts aren't re-added → the LLM proposes findings with
verbatim quotes → updates/conflicts are verified against the Key References the report cites →
every quote is checked against the indexed passage (page numbers come from the index, not the model).
Findings that fail validation are kept in a separate "Ungrounded" list and never offered for approval.

### Evidence dossier (per suggestion)

So a reviewer sees the whole picture rather than the one line where a change was found, every suggestion gets
an evidence dossier before validation:

1. The fact is searched again across **all** indexed New, Unused and Key references of the field. The best
   `ANALYSIS_DOSSIER_SOURCES` passages (default 8) are kept, at most 2 per document, so several documents are compared.
2. Each passage is read together with the passages just before and after it in the same document.
3. The LLM records each relevant source's position — supports, contradicts, adds detail, or older value — with a
   verbatim quote, writes a short "context across sources" paragraph (what the report says, what the sources say,
   how the value evolved, whether the change is well supported), and may expand the wording to cite several agreeing sources.
4. The source rules above still apply to any expanded wording, the suggestion's own evidence is always listed,
   and every compared quote goes through the citation validator (unverified ones are dropped).

The dossier costs one extra LLM call per suggestion; set `ANALYSIS_DOSSIER=false` to switch it off.

On the **Review changes** page each card shows the context paragraph, a source comparison table, and each quote
with its surrounding passage (quote highlighted). Suggestions are shown 5 per page to keep the page responsive.

Chunking is layout-aware and section-based: chunks never cross a section, are packed from whole
paragraphs/sentences to ~350 words with ~50 words of sentence-aligned overlap, and tables are separate
chunks split by rows with the header repeated.

## Layout

| Path | Responsibility |
|---|---|
| `app/config.py` | Settings loaded from `.env` |
| `app/models.py` | Pydantic models: documents, chunks, sections, recommendations, review decisions |
| `app/prompts/` | LLM prompts kept as files so they can be tuned without code changes |
| `app/services/blob_service.py` | List, download and upload blobs in the field folder layout |
| `app/services/document_intelligence_service.py` | OCR/layout extraction, cached as JSON so re-runs don't re-bill |
| `app/services/report_parser.py` | Splits the RE report into numbered sections (8.1, 8.2 …) |
| `app/services/chunking_service.py` | Section-bounded ~350-word chunks with page and metadata |
| `app/services/embedding_service.py` | Embedding generation (batch) |
| `app/services/search_service.py` | Index schema, upload, hybrid search with metadata filters |
| `app/services/llm_service.py` | Provider wrapper (Azure OpenAI / Anthropic), structured JSON output |
| `app/services/report_analysis_service.py` | Per-section change, new-info and conflict detection; evidence dossier per suggestion |
| `app/services/citation_validator.py` | Checks every quoted evidence string (including compared sources) exists in the cited chunk/page |
| `app/services/review_service.py` | Approve / edit / reject / undo state and the audit trail |
| `app/services/report_export_service.py` | Builds the updated DOCX with approved changes highlighted |
| `app/workflows/` | Orchestration: ingestion, report update, evaluation against the later report |
| `app/ui/` | One module per Streamlit page; `streamlit_app.py` is the entrypoint |
| `scripts/` | CLI runners: check connections, create index, ingest a field, run analysis, run evaluation |
| `tests/` | Unit tests; small sample inputs go in `tests/fixtures/` |

## Analysis rules (from SME validation, 7 Oct 2026)

- Compare against the most recent report version only; that report is the baseline.
- New References are the primary source (~95% of evidence slots, `ANALYSIS_UNUSED_SHARE=0.05`).
- Previously Unused references may only contribute additions; an update/conflict based only on them is discarded.
- An update/conflict to a cited statement needs a New Reference published after the newest citation the report
  uses for that statement (e.g. report cites 2018 → only 2019+ sources). Additions may use any New Reference.
- Key References are used to verify where a figure in the current report came from when a conflict appears.
- Newer is not automatically correct — prefer the more authoritative source, and flag conflicts for review rather than overwrite.
- Do not correct historical errors; add new information, and replace text only where new evidence changes an interpretation.
- Check the whole report before proposing an addition, in case it is already covered in another section.
- Spanish-language sources are in scope.
