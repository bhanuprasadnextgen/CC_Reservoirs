"""Shared builders for offline tests (no Azure calls)."""

from __future__ import annotations

import pytest

from app.models import ExtractedDocument, ExtractedParagraph, ExtractedTable, ReferenceCategory, SourceDocument


class DocBuilder:
    """Builds an ExtractedDocument in reading order: .heading(), .para(), .table(), then .build()."""

    def __init__(self) -> None:
        self.paragraphs: list[ExtractedParagraph] = []
        self.tables: list[ExtractedTable] = []
        self._offset = 0
        self.page = 1

    def _next(self) -> int:
        self._offset += 100
        return self._offset

    def heading(self, text: str, role: str = "sectionHeading") -> DocBuilder:
        self.paragraphs.append(ExtractedParagraph(text=text, role=role, page=self.page, offset=self._next()))
        return self

    def para(self, text: str, page: int | None = None) -> DocBuilder:
        if page:
            self.page = page
        self.paragraphs.append(ExtractedParagraph(text=text, role=None, page=self.page, offset=self._next()))
        return self

    def table(self, header: list[str], rows: list[list[str]], caption: str | None = None) -> DocBuilder:
        def row(cells: list[str]) -> str:
            return "| " + " | ".join(cells) + " |"

        head = "\n".join([row(header), row(["---"] * len(header))])
        body = [row(r) for r in rows]
        markdown = "\n".join(([f"Table: {caption}"] if caption else []) + [head, *body])
        self.tables.append(
            ExtractedTable(
                markdown=markdown, header=head, rows=body, caption=caption,
                page_start=self.page, page_end=self.page, offset=self._next(),
            )
        )
        return self

    def build(self, document_id: str = "doc1") -> ExtractedDocument:
        return ExtractedDocument(
            document_id=document_id, model_id="prebuilt-layout", page_count=self.page,
            paragraphs=self.paragraphs, tables=self.tables,
        )


@pytest.fixture
def doc_builder() -> DocBuilder:
    return DocBuilder()


def make_source(
    document_id: str = "doc1",
    category: ReferenceCategory = ReferenceCategory.NEW,
    file_name: str = "Hernandez et al., 2016, First sealant application.pdf",
    field_id: str = "lago-agrio",
    authors: list[str] | None = None,
    year: int | None = 2016,
    citation: str | None = "Hernandez et al., 2016",
) -> SourceDocument:
    return SourceDocument(
        document_id=document_id, field_id=field_id, field_name="Lago Agrio", reservoir_id=field_id,
        report_id=f"{field_id}-2020", category=category, blob_path=f"Lago Agrio/x/{file_name}",
        file_name=file_name, authors=authors if authors is not None else ["Hernandez"],
        publication_year=year, citation=citation,
    )


def sentence(n_words: int, tag: str = "w") -> str:
    """A single sentence of exactly n_words words."""
    words = [f"{tag}{i}" for i in range(n_words)]
    words[0] = words[0].capitalize()
    return " ".join(words) + "."


class FakeStorage:
    """In-memory stand-in for StorageRepository."""

    def __init__(self) -> None:
        self.blobs: dict[str, object] = {}

    def put_json(self, path, obj, compress=False):
        import json

        self.blobs[path] = json.loads(json.dumps(obj, default=str))

    def get_json(self, path):
        return self.blobs.get(path)

    def put_bytes(self, path, data, content_type=""):
        self.blobs[path] = data

    def get_bytes(self, path):
        return self.blobs.get(path)

    def exists(self, path):
        return path in self.blobs

    def append_jsonl(self, path, record):
        import json

        self.blobs.setdefault(path, []).append(json.loads(json.dumps(record, default=str)))

    def read_jsonl(self, path):
        return list(self.blobs.get(path, []))

    def list(self, prefix):
        return [p for p in self.blobs if p.startswith(prefix)]


@pytest.fixture
def storage() -> FakeStorage:
    return FakeStorage()


@pytest.fixture
def settings():
    from app.config import Settings

    return Settings()


def make_chunk(chunk_id="c1", content="", field_id="lago-agrio", category=ReferenceCategory.NEW, **kw):
    from app.models import Chunk

    defaults = dict(
        document_id=chunk_id.split("-")[0], field_name="Lago Agrio", reservoir_id=field_id,
        report_id=f"{field_id}-2020", file_name="Hernandez et al., 2016, First sealant.pdf",
        citation="Hernandez et al., 2016", publication_year=2016, chunk_index=0, page_start=2, page_end=3,
    )
    defaults.update(kw)
    return Chunk(chunk_id=chunk_id, field_id=field_id, category=category, content=content, **defaults)


def make_recommendation(evidence=None, change_type="update", existing="", proposed="New text (X, 2020).", **kw):
    from app.models import ChangeType, Recommendation

    return Recommendation(
        run_id="run1", field_id="lago-agrio", report_id="lago-agrio-2020", section_id=kw.pop("section_id", "8.1"),
        section_title="Production", change_type=ChangeType(change_type), existing_text=existing,
        proposed_text=proposed, rationale="because", evidence=evidence or [], **kw,
    )


def make_evidence(chunk_id="c1", quote="", **kw):
    from app.models import Evidence

    fields = dict(document_id="x", file_name="x.pdf", category=ReferenceCategory.NEW)
    fields.update(kw)
    return Evidence(chunk_id=chunk_id, quote=quote, **fields)
