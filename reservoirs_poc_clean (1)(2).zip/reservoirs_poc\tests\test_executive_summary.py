"""Executive summary: skipped by "Find updates", drafted on the Final report page from the approved changes."""

import io

from docx import Document

from app.models import AnalysisRun, ChangeType, ReportRole, ReportSection, ReportVersion, ReviewStatus, SectionKind
from app.services.llm_service import Usage
from app.services.report_analysis_service import ReportAnalysisService, SectionContext, SectionResult, _SummaryUpdate
from app.services.report_export_service import build_docx
from app.services.report_parser import is_executive_summary
from app.services.review_service import ReviewStore
from app.workflows import report_update_workflow as wf

from tests.conftest import make_evidence, make_recommendation

SUMMARY_TEXT = "The Lago Agrio Field was discovered in 1967. At end-2016 cumulative oil was 168.3 MMBO."
NEW_SUMMARY = "The Lago Agrio Field was discovered in 1967. At end-2023 cumulative oil was 201.5 MMBO (Petroecuador, 2024)."
SUMMARY = ReportSection(section_id="1", title="EXECUTIVE SUMMARY", level=1, order=1, text=SUMMARY_TEXT)
PRODUCTION = ReportSection(section_id="8.1", title="PRODUCTION HISTORY", level=2, order=2, text="Cumulative oil was 168.3 MMBO.")
REPORT = ReportVersion(report_id="lago-agrio-2020", field_id="lago-agrio", year=2020, blob_path="x.pdf", role=ReportRole.CURRENT)


class SummaryLLM:
    model_name = "fake"

    def __init__(self, used=("S1",), text=NEW_SUMMARY):
        self.usage = Usage()
        self.used, self.text = list(used), text
        self.prompts = []

    def complete_json(self, system, user, schema):
        assert schema is _SummaryUpdate
        self.usage.add(10, 5)
        self.prompts.append(user)
        return _SummaryUpdate(updated_summary=self.text, used_changes=self.used, rationale="Cumulative updated.", no_change_reason=None)


def _ctx(section=SUMMARY):
    return SectionContext(run_id="run1", field_id="lago-agrio", field_name="Lago Agrio", report_id="lago-agrio-2020",
                          reservoir_name=None, section=section, outline="", citations=[])


def _change(**kw):
    return make_recommendation(
        [make_evidence("c1", "acumulado 201,5 MMBO", citation="Petroecuador, 2024")],
        existing="Cumulative oil was 168.3 MMBO.", proposed="At end-2023 cumulative oil was 201.5 MMBO (Petroecuador, 2024).",
        **kw,
    )


def _summarise(settings, changes, llm=None):
    llm = llm or SummaryLLM()
    return ReportAnalysisService(settings, None, None, llm).summarise(_ctx(), changes), llm


def test_summary_section_is_recognised():
    assert is_executive_summary(SUMMARY)
    assert not is_executive_summary(PRODUCTION)
    assert not is_executive_summary(ReportSection(section_id="TABLES", title="Summary", kind=SectionKind.TABLES, level=1, order=9, text="x"))


def test_summary_rewritten_from_approved_changes_and_carries_their_evidence(settings):
    result, llm = _summarise(settings, [_change()])
    (rec,) = result.recommendations
    assert rec.section_id == "1" and rec.change_type == ChangeType.UPDATE
    assert rec.existing_text == SUMMARY_TEXT and "201.5 MMBO" in rec.proposed_text
    assert [e.citation for e in rec.evidence] == ["Petroecuador, 2024"]
    assert "approved change" in rec.validation_notes[0] and "8.1" in rec.validation_notes[0]
    assert "[S1] section 8.1" in llm.prompts[0] and SUMMARY_TEXT in llm.prompts[0]


def test_no_summary_change_when_model_uses_no_change(settings):
    result, _ = _summarise(settings, [_change()], SummaryLLM(used=[], text=SUMMARY_TEXT))
    assert result.recommendations == [] and result.note


class _Source:
    def report_versions(self, field_name):
        return [REPORT]


class _Analysis:
    prompt_version = "test"

    def __init__(self, settings, llm):
        self.order = []
        self._real = ReportAnalysisService(settings, None, None, llm)

    def analyse_section(self, ctx, instruction=None):
        self.order.append(ctx.section.section_id)
        return SectionResult(section_id=ctx.section.section_id, recommendations=[_change(section_id=ctx.section.section_id)])

    def summarise(self, ctx, changes):
        self.order.append("summary")
        return self._real.summarise(ctx, changes)


def _services(settings, storage, monkeypatch, llm=None):
    monkeypatch.setattr(wf, "load_sections", lambda *a: [SUMMARY, PRODUCTION])
    monkeypatch.setattr(wf, "load_citations", lambda *a: [])
    llm = llm or SummaryLLM()
    return wf.AnalysisServices(settings=settings, source=_Source(), storage=storage, search=None, embeddings=None,
                               llm=llm, analysis=_Analysis(settings, llm))


def test_find_updates_skips_the_summary(settings, storage, monkeypatch):
    svc = _services(settings, storage, monkeypatch)
    seen = []
    run = wf.run_analysis("Lago Agrio", services=svc, progress=lambda sid, done, total: seen.append((sid, done, total)))
    assert svc.analysis.order == ["8.1"]
    assert seen == [("8.1", 1, 1)] and run.sections_total == 1
    assert [r.section_id for r in run.recommendations] == ["8.1"] and run.executive_summary is None


def test_summary_is_drafted_from_approved_changes_reviewed_and_exported(settings, storage, monkeypatch, doc_builder):
    svc = _services(settings, storage, monkeypatch)
    run = wf.run_analysis("Lago Agrio", services=svc)
    store = ReviewStore(storage, settings, run)
    (change,) = run.recommendations
    store.approve(change.recommendation_id, "bhanu", final_text="At end-2023 cumulative oil was 201.6 MMBO (Petroecuador, 2024).")

    assert wf.draft_executive_summary("Lago Agrio", run, store.approved_changes(), svc) is None
    assert "201.6 MMBO" in svc.llm.prompts[-1]  # the reviewer's edited wording, not the AI's
    assert run.llm_calls == 1 and run.executive_summary_basis == [change.recommendation_id]
    assert wf.load_run(storage, settings, "lago-agrio").executive_summary.proposed_text == NEW_SUMMARY

    store = ReviewStore(storage, settings, run)
    summary, state = store.summary_item()
    assert state.status == ReviewStatus.PENDING and not store.summary_is_stale()
    assert [r.section_id for r, _ in store.items()] == ["8.1"]  # not listed with the section changes
    store.approve(summary.recommendation_id, "bhanu")
    assert [r.section_id for r, _ in store.approved()] == ["1", "8.1"]

    sections = [SUMMARY.model_copy(update={"paragraphs": doc_builder.para(SUMMARY_TEXT).paragraphs})]
    text = "\n".join(p.text for p in Document(io.BytesIO(build_docx("Lago Agrio", REPORT, sections, store))).paragraphs)
    assert NEW_SUMMARY in text and "168.3 MMBO" not in text.split("Appendix")[0]

    store.undo(change.recommendation_id, "bhanu")
    assert store.summary_is_stale()


def test_draft_returns_a_note_when_nothing_changes(settings, storage, monkeypatch):
    svc = _services(settings, storage, monkeypatch, SummaryLLM(used=[], text=SUMMARY_TEXT))
    run = AnalysisRun(field_id="lago-agrio", report_id="lago-agrio-2020", categories_searched=[], recommendations=[_change()])
    store = ReviewStore(storage, settings, run)
    store.approve(run.recommendations[0].recommendation_id, "bhanu")
    assert wf.draft_executive_summary("Lago Agrio", run, store.approved_changes(), svc)
    assert run.executive_summary is None
