"""Split an extracted RE report into sections and trace its citations to source documents.

Layout of a DAKS RE report (seen in Lago Agrio N2020):
    title page, table of contents                       -> FRONT_MATTER (ignored)
    1. EXECUTIVE SUMMARY … 8.3 OTHER … PRACTICES        -> BODY sections (analysed)
    KEY REFERENCES                                       -> REFERENCES (citation tracing)
    TABLE OF PARAMETERS / TABLES & FIGURES               -> one TABLES section holding the captioned
                                                            data tables (Table 1, 2, 3 …) (analysed)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from rapidfuzz import fuzz

from app.models import (
    ExtractedDocument,
    ExtractedParagraph,
    ExtractedTable,
    ReferenceCategory,
    ReportCitation,
    ReportSection,
    SectionKind,
    SourceDocument,
)
from app.utils.text_utils import author_key, normalize_for_match

_NUMBERED_HEADING = re.compile(r"^(?P<num>\d{1,2}(?:\.\d{1,2}){0,3})\.?\s+(?P<title>[A-ZÁÉÍÓÚÑ].{1,150})$")
_TOC_LINE = re.compile(r"(?:\.{3,}|\s)\s*\d{1,3}$")  # "6.1 STRATIGRAPHY ........ 7"
_HEADING_ROLES = {"sectionHeading", "title"}

REFERENCES_ID = "REF"
TABLES_ID = "TABLES"
FRONT_ID = "FRONT"


def _special_heading(text: str) -> tuple[str, str, SectionKind] | None:
    upper = text.upper()
    if re.search(r"\b(KEY\s+)?REFERENCES\b", upper) and len(text.split()) <= 4:
        return REFERENCES_ID, "Key References", SectionKind.REFERENCES
    if "TABLE OF PARAMETERS" in upper or "TABLES & FIGURES" in upper or "TABLES AND FIGURES" in upper:
        return TABLES_ID, "Tables", SectionKind.TABLES
    if "TABLE OF CONTENTS" in upper or upper.strip() == "CONTENTS":
        return FRONT_ID, "Front matter", SectionKind.FRONT_MATTER
    return None


@dataclass
class _Draft:
    section_id: str
    title: str
    kind: SectionKind
    order: int
    paragraphs: list[ExtractedParagraph] = field(default_factory=list)
    tables: list[ExtractedTable] = field(default_factory=list)


def parse_sections(doc: ExtractedDocument) -> list[ReportSection]:
    """Reading-order walk: headings open sections, paragraphs and tables fill the open one."""
    items: list[tuple[int, ExtractedParagraph | ExtractedTable]] = [(p.offset, p) for p in doc.paragraphs]
    items += [(t.offset, t) for t in doc.tables]
    items.sort(key=lambda pair: pair[0])

    drafts: list[_Draft] = [_Draft(FRONT_ID, "Front matter", SectionKind.FRONT_MATTER, 0)]
    for _, item in items:
        current = drafts[-1]
        if isinstance(item, ExtractedTable):
            current.tables.append(item)
            continue

        heading = _as_heading(item, current.kind)
        if heading is not None:
            section_id, title, kind = heading
            if kind == SectionKind.TABLES and current.kind == SectionKind.TABLES:
                continue  # "TABLES & FIGURES" pages continue the one TABLES section
            drafts.append(_Draft(section_id, title, kind, len(drafts)))
            continue
        if item.role == "title":
            continue  # running titles that survived de-duplication
        current.paragraphs.append(item)

    sections = [_finish(d) for d in drafts]
    return _dedupe(sections)


def _as_heading(p: ExtractedParagraph, current_kind: SectionKind) -> tuple[str, str, SectionKind] | None:
    text = p.text.strip()
    # Real appendix headings are upper-case ("KEY REFERENCES", "… I TABLES & FIGURES"); mixed-case
    # front-matter lines like "Accessing Reservoir Table of Parameters" must not open the appendix.
    special = _special_heading(text)
    if special and text.isupper():
        return special
    if current_kind in (SectionKind.REFERENCES, SectionKind.TABLES):
        return None  # numbered lines inside the appendix are not body headings
    match = _NUMBERED_HEADING.match(text)
    if not match:
        return None
    looks_like_heading = p.role in _HEADING_ROLES or match.group("title").isupper()
    if not looks_like_heading or _TOC_LINE.search(text):
        return None
    return match.group("num"), match.group("title").strip(), SectionKind.BODY


def _finish(d: _Draft) -> ReportSection:
    if d.kind == SectionKind.TABLES:
        # Keep only captioned data tables; uncaptioned grids here are figure artefacts.
        tables = [t for t in d.tables if t.caption and t.caption.lower().startswith("table")]
        paragraphs: list[ExtractedParagraph] = []
        text = "\n\n".join(t.markdown for t in tables)
    else:
        tables, paragraphs = d.tables, d.paragraphs
        text = "\n\n".join([*(p.text for p in paragraphs), *(t.markdown for t in tables)])

    pages = [p.page for p in paragraphs] + [pg for t in tables for pg in (t.page_start, t.page_end)]
    level = d.section_id.count(".") + 1 if d.kind == SectionKind.BODY else 1
    parent = d.section_id.rsplit(".", 1)[0] if d.kind == SectionKind.BODY and "." in d.section_id else None
    return ReportSection(
        section_id=d.section_id,
        title=d.title,
        kind=d.kind,
        level=level,
        parent_id=parent,
        order=d.order,
        text=text,
        page_start=min(pages) if pages else None,
        page_end=max(pages) if pages else None,
        paragraphs=paragraphs,
        tables=tables,
    )


def _dedupe(sections: list[ReportSection]) -> list[ReportSection]:
    """If a section id appears twice (e.g. a TOC line slipped through), keep the one with more text."""
    best: dict[str, ReportSection] = {}
    for s in sections:
        if s.section_id not in best or len(s.text) > len(best[s.section_id].text):
            best[s.section_id] = s
    kept = sorted(best.values(), key=lambda s: s.order)
    return [s.model_copy(update={"order": i}) for i, s in enumerate(kept)]


def analysable(sections: list[ReportSection]) -> list[ReportSection]:
    """Sections the assistant checks for updates: body and tables with actual content."""
    return [s for s in sections if s.kind in (SectionKind.BODY, SectionKind.TABLES) and s.text.strip()]


_SUMMARY_TITLE = re.compile(r"\b(?:EXECUTIVE\s+)?SUMMARY\b|\bRESUMEN(?:\s+EJECUTIVO)?\b", re.IGNORECASE)


def is_executive_summary(section: ReportSection) -> bool:
    """The top-level summary section. It is not checked against sources; it is rewritten from the other sections' changes."""
    return section.kind == SectionKind.BODY and section.level == 1 and bool(_SUMMARY_TITLE.search(section.title))


# ---------------------------------------------------------------------- citations

_YEAR = r"(?:19|20)\d{2}"
_YEARS = rf"{_YEAR}[a-z]?(?:\s*,\s*{_YEAR}[a-z]?)*"  # "1998" or "1998, 1999" or "2016a, 2016b"
_PARENTHETICAL = re.compile(rf"\(([^()]*?{_YEAR}[^()]*)\)")
_AUTHOR_YEAR = re.compile(rf"^\s*(?P<authors>[A-ZÁÉÍÓÚÑ][^,;()]*?)(?:,)?\s+(?P<years>{_YEARS})\s*$")
_NARRATIVE = re.compile(rf"(?P<authors>[A-ZÁÉÍÓÚÑ][\w'’\-]+(?:\s+et\s+al\.?)?)\s+\((?P<years>{_YEARS})\)")
_REF_ENTRY = re.compile(rf"^(?P<surname>[A-ZÁÉÍÓÚÑ][^,]+),.*?,\s*(?P<year>{_YEAR})[a-z]?,")
_NOT_AUTHORS = {"in", "since", "by", "from", "until", "the", "of", "january", "february", "march", "april", "may",
                "june", "july", "august", "september", "october", "november", "december", "end", "year", "mid"}


def cited_works(text: str) -> list[tuple[str, int]]:
    """(authors, year) for every in-text citation: "(Smith, 1989; Baby et al., 1998, 1999)" and "Baby et al. (1998)".

    One author group with several years ("Baby et al., 1998, 1999") counts as one citation per year.
    """
    works: list[tuple[str, int]] = []
    matches = [m for group in _PARENTHETICAL.findall(text) for m in map(_AUTHOR_YEAR.match, group.split(";")) if m]
    for m in [*matches, *_NARRATIVE.finditer(text)]:
        if author_key(m.group("authors")) in _NOT_AUTHORS:
            continue
        works += [(m.group("authors"), int(year)) for year in re.findall(_YEAR, m.group("years"))]
    return works


@dataclass
class _Found:
    citation: str
    surname: str
    year: int
    section_ids: set[str]


def parse_report_citations(
    sections: list[ReportSection], references: list[SourceDocument]
) -> list[ReportCitation]:
    """Find (Author, Year) citations in the report and link each to a reference file when possible.

    Used to trace where an existing figure came from (Rod's verification step).
    """
    found: dict[tuple[str, int], _Found] = {}

    def add(authors: str, year: int, section_id: str) -> None:
        authors = " ".join(authors.split()).strip(" ,.")
        key = author_key(authors)
        if not key or key in _NOT_AUTHORS:
            return
        entry = found.setdefault((key, year), _Found(f"{authors}, {year}", authors, year, set()))
        entry.section_ids.add(section_id)

    for section in sections:
        if section.kind == SectionKind.REFERENCES:
            for p in section.paragraphs:
                m = _REF_ENTRY.match(p.text)
                if m:
                    add(m.group("surname"), int(m.group("year")), section.section_id)
            continue
        if section.kind == SectionKind.FRONT_MATTER:
            continue
        for authors, year in cited_works(section.text):
            add(authors, year, section.section_id)

    citations = []
    for (key, year), f in sorted(found.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        doc = match_reference(f.surname, year, references)
        citations.append(
            ReportCitation(
                citation=f.citation,
                surname=f.surname,
                year=year,
                section_ids=sorted(f.section_ids),
                document_id=doc.document_id if doc else None,
            )
        )
    return citations


_CATEGORY_PREFERENCE = {ReferenceCategory.KEY: 0, ReferenceCategory.UNUSED: 1, ReferenceCategory.NEW: 2}


def _author_tokens(authors: str) -> str:
    text = normalize_for_match(authors)
    text = re.sub(r"\bet\.? ?al\.?|\band\b|\by\b|&|,", " ", text)
    return " ".join(text.split())


def match_reference(authors: str, year: int, references: list[SourceDocument], min_score: float = 70) -> SourceDocument | None:
    """The reference file a citation like "Hernandez and Bustillos, 2016" points to.

    Same year required. The first-author surname must match (fuzzily, to absorb file-name typos such as
    Estupifian/Estupiñan); ties between papers by the same first author in the same year (Hernandez &
    Bustillos 2016 vs Hernandez et al. 2016) are broken by comparing the full author string.
    Key References win remaining ties, since they were used to write the report.
    """
    key = author_key(authors)
    cited_et_al = "et al" in authors.lower()
    cited = _author_tokens(authors)
    best: tuple[float, int, SourceDocument] | None = None
    for doc in references:
        if doc.publication_year != year:
            continue
        doc_authors = " ".join(doc.authors) if doc.authors else (doc.citation or "").rsplit(",", 1)[0]
        doc_key = author_key(doc_authors)
        if not doc_key or fuzz.ratio(key, doc_key) < 80:
            continue
        # token_sort (not token_set): uncited co-authors lower the score, so "Hernandez et al." prefers the
        # et-al paper over "Hernandez & Bustillos".
        score = fuzz.token_sort_ratio(cited, _author_tokens(doc_authors))
        score += 10 if cited_et_al == ("et al" in (doc.citation or "").lower()) else 0
        rank = (score, -_CATEGORY_PREFERENCE.get(doc.category, 9), doc)
        if score >= min_score and (best is None or rank[:2] > best[:2]):
            best = rank
    return best[2] if best else None


def citation_years(text: str) -> list[int]:
    """Years of the (Author, Year) citations in a piece of report text."""
    return [year for _, year in cited_works(text)]


def find_section(sections: list[ReportSection], text: str) -> ReportSection | None:
    """The section whose text contains `text` (normalised), if any."""
    needle = normalize_for_match(text)
    for s in sections:
        if needle and needle in normalize_for_match(s.text):
            return s
    return None
