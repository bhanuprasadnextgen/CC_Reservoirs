"""Verify every Azure service in .env is reachable. Never prints secrets.

Usage:  python -m scripts.check_connections
"""

from __future__ import annotations

import sys

from app.config import get_settings


def _ok(name: str, detail: str) -> None:
    print(f"  [OK]   {name}: {detail}")


def _fail(name: str, err: Exception) -> None:
    print(f"  [FAIL] {name}: {type(err).__name__}: {str(err).splitlines()[0][:200]}")


def check_blob(label: str, conn_str: str, container: str) -> bool:
    from azure.storage.blob import BlobServiceClient

    try:
        client = BlobServiceClient.from_connection_string(
            conn_str, connection_timeout=20, read_timeout=60
        ).get_container_client(container)
        top_level = [item.name for item in client.walk_blobs(delimiter="/")]
        _ok(f"Blob {label}", f"{client.account_name}/{container} — {len(top_level)} top-level entries")
        for name in top_level:
            print(f"           {name}")
        return True
    except Exception as e:
        _fail(f"Blob {label}", e)
        return False


def check_docintel(s) -> bool:
    from azure.ai.documentintelligence import DocumentIntelligenceAdministrationClient
    from azure.core.credentials import AzureKeyCredential

    try:
        client = DocumentIntelligenceAdministrationClient(s.docintel.endpoint, AzureKeyCredential(s.docintel.key))
        details = client.get_resource_details()
        _ok("Document Intelligence", f"reachable, custom models {details.custom_document_models.count}"
            f"/{details.custom_document_models.limit}; using '{s.docintel.model_id}'")
        return True
    except Exception as e:
        _fail("Document Intelligence", e)
        return False


def check_search(s) -> bool:
    from azure.core.credentials import AzureKeyCredential
    from azure.search.documents.indexes import SearchIndexClient

    try:
        client = SearchIndexClient(s.search.endpoint, AzureKeyCredential(s.search.key))
        names = list(client.list_index_names())
        exists = s.search.index in names
        _ok("AI Search", f"indexes {names or '[]'}; '{s.search.index}' "
            f"{'exists' if exists else 'not created yet (Phase 3 creates it)'}")
        return True
    except Exception as e:
        _fail("AI Search", e)
        return False


def check_openai(s) -> bool:
    from openai import AzureOpenAI

    client = AzureOpenAI(azure_endpoint=s.aoai.endpoint, api_key=s.aoai.api_key, api_version=s.aoai.api_version)
    ok = True
    try:
        emb = client.embeddings.create(
            model=s.aoai.embedding_deployment, input="reservoir", dimensions=s.aoai.embedding_dimensions
        )
        _ok("OpenAI embeddings", f"'{s.aoai.embedding_deployment}' → {len(emb.data[0].embedding)} dims")
    except Exception as e:
        _fail("OpenAI embeddings", e)
        ok = False
    try:
        resp = client.responses.create(model=s.aoai.chat_deployment, input="Reply with the single word: ready")
        _ok("OpenAI chat", f"'{s.aoai.chat_deployment}' replied {resp.output_text.strip()[:40]!r}")
    except Exception as e:
        _fail("OpenAI chat", e)
        ok = False
    return ok


def main() -> int:
    s = get_settings()
    missing = s.missing_required()
    if missing:
        print("Missing settings:", ", ".join(missing))
        return 1

    print("Checking Azure connections…")
    results = [
        check_blob("source", s.blob.source_connection_string, s.blob.source_container),
        check_blob("storage", s.blob.storage_connection_string, s.blob.storage_container),
        check_docintel(s),
        check_search(s),
        check_openai(s),
    ]
    print(f"\n{sum(results)}/{len(results)} checks passed")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
