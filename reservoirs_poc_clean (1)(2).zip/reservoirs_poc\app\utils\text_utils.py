"""Text helpers: file-name metadata, language detection, normalisation, sentence splitting."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import PurePosixPath

# ------------------------------------------------------------------ normalisation


def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


_QUOTES = str.maketrans({"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-", "­": ""})


def normalize_for_match(text: str) -> str:
    """Lowercase, accent-free, single-spaced text for fuzzy quote comparison."""
    text = strip_accents(text.translate(_QUOTES)).lower()
    text = re.sub(r"(\w)-\s+(\w)", r"\1\2", text)  # re-join words hyphenated across lines
    return re.sub(r"\s+", " ", text).strip()


def slugify(name: str) -> str:
    """Stable identifier from a display name: 'Lago Agrio' -> 'lago-agrio'."""
    return re.sub(r"[^a-z0-9]+", "-", strip_accents(name).lower()).strip("-")


def word_count(text: str) -> int:
    return len(text.split())


# ------------------------------------------------------------- reference file names

_YEAR = r"(?:19|20)\d{2}"
_REFERENCE_NAME = re.compile(
    rf"^(?P<authors>.+?)[,\s]+(?P<year>{_YEAR})(?:\s*-\s*(?P<year_end>{_YEAR}))?\b\s*[,.]?\s*(?P<title>.*)$"
)
_TRAILING_FIELD_TAG = re.compile(r"\s+-\s+[A-Z][A-Z0-9 ]+$")  # e.g. " - LAGO AGRIO"
_ET_AL = re.compile(r",?\s*et\.?\s*al\.?,?", re.IGNORECASE)


@dataclass(frozen=True)
class ReferenceName:
    authors: str  # as cleaned for display, e.g. "Hernandez et al."
    year: int | None
    title: str
    citation: str  # short in-text form, e.g. "Hernandez et al., 2016"
    first_author_key: str  # normalised first word of first author, for matching report citations


def _clean_authors(raw: str) -> str:
    authors = re.sub(r"\s+", " ", raw).strip(" ,.")
    if _ET_AL.search(authors):
        authors = _ET_AL.sub("", authors).strip(" ,.") + " et al."
    return authors


def author_key(authors: str) -> str:
    """First word of the first author, normalised: 'Hernández et al.' -> 'hernandez'."""
    words = re.findall(r"[A-Za-zÀ-ÿ']+", authors)
    return normalize_for_match(words[0]) if words else ""


def parse_reference_filename(file_name: str) -> ReferenceName:
    """Parse 'Authors, Year, Title.pdf' (and the variants seen in the C&C folders)."""
    stem = re.sub(r"\s+", " ", PurePosixPath(file_name).stem).strip()
    match = _REFERENCE_NAME.match(stem)
    if not match or not match.group("authors").strip(" ,."):
        return ReferenceName(authors="", year=None, title=stem, citation=stem, first_author_key="")

    authors = _clean_authors(match.group("authors"))
    year = int(match.group("year_end") or match.group("year"))
    title = _TRAILING_FIELD_TAG.sub("", match.group("title")).strip(" ,.-") or stem
    return ReferenceName(
        authors=authors,
        year=year,
        title=title,
        citation=f"{authors}, {year}",
        first_author_key=author_key(authors),
    )


# ---------------------------------------------------------------- report file names

_REPORT_NAME = re.compile(rf"^DAKS\s+(?P<name>.+?)\s+(?P<flag>[NU])(?P<year>{_YEAR})\s+Report$", re.IGNORECASE)


@dataclass(frozen=True)
class ReportName:
    field_name: str
    reservoir_name: str | None
    flag: str | None  # "N" / "U"
    year: int | None


def parse_report_filename(file_name: str) -> ReportName:
    """'DAKS Lago Agrio_Upper Hollin U2026 Report.pdf' -> field, reservoir, flag, year."""
    stem = PurePosixPath(file_name).stem.strip()
    match = _REPORT_NAME.match(stem)
    if not match:
        year = re.search(_YEAR, stem)
        return ReportName(field_name=stem, reservoir_name=None, flag=None, year=int(year.group()) if year else None)
    field, _, reservoir = match.group("name").partition("_")
    return ReportName(
        field_name=field.strip(),
        reservoir_name=reservoir.strip() or None,
        flag=match.group("flag").upper(),
        year=int(match.group("year")),
    )


# ------------------------------------------------------------------------ language

_STOPWORDS = {
    "en": set("the of and to in is was were for on with by as that this from at are be which has have".split()),
    "es": set("el la los las de del y en que por con para una un se es fue son al lo como su sus más".split()),
}


Language = str  # "en" | "es" | "zh"
DEFAULT_LANGUAGE: Language = "en"
_CJK = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")


def detect_language_or_none(text: str, sample_words: int = 3000, min_words: int = 20) -> Language | None:
    """'zh' when Chinese characters dominate, else 'en' / 'es' by stop-word frequency;
    None when the text is too short or has no clear signal."""
    sample = text[: sample_words * 6]
    cjk = len(_CJK.findall(sample))
    latin_words = len(re.findall(r"[A-Za-zÀ-ÿ]{2,}", sample))
    if cjk >= min_words and cjk >= latin_words:
        return "zh"
    words = re.findall(r"[a-záéíóúñü]+", text.lower())[:sample_words]
    if len(words) < min_words:
        return None
    scores = {lang: sum(w in stop for w in words) for lang, stop in _STOPWORDS.items()}
    if scores["en"] == scores["es"]:
        return None
    return max(scores, key=scores.__getitem__)


def detect_language(text: str, fallback: Language = DEFAULT_LANGUAGE) -> Language:
    """Always a language code ('en', 'es' or 'zh'): the detected language, else `fallback`."""
    return detect_language_or_none(text) or fallback


# ----------------------------------------------------------------------- sentences

_ABBREVIATIONS = r"(?:et al|e\.g|i\.e|Fig|Figs|Eq|No|Nos|approx|ca|cf|vs|Dr|Mr|Ms|Inc|Ltd|Co|St|Mt|Sr|Jr|aprox|p|pp|vol)"
_SENTENCE_END = re.compile(r"(?:(?<=[.!?])|(?<=[.!?][\"')\]]))\s+(?=[\"'(\[]?[A-ZÁÉÍÓÚÑ¿¡0-9])")
_ABBREV_TAIL = re.compile(rf"\b{_ABBREVIATIONS}\.$", re.IGNORECASE)
_INITIAL_TAIL = re.compile(r"\b[A-Z]\.$")


def split_sentences(text: str) -> list[str]:
    """Split prose into sentences without breaking on 'et al.', 'Fig.', initials or decimals."""
    pieces = [p for p in _SENTENCE_END.split(text.strip()) if p]
    sentences: list[str] = []
    for piece in pieces:
        if sentences and (_ABBREV_TAIL.search(sentences[-1]) or _INITIAL_TAIL.search(sentences[-1])):
            sentences[-1] = f"{sentences[-1]} {piece}"
        else:
            sentences.append(piece)
    return [s.strip() for s in sentences if s.strip()]
