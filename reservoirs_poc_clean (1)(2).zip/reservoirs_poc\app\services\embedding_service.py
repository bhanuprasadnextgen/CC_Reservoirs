"""Batch embeddings from Azure OpenAI."""

from __future__ import annotations

from openai import APIConnectionError, APITimeoutError, AzureOpenAI, InternalServerError, RateLimitError
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

from app.config import Settings
from app.utils.logging_config import get_logger

log = get_logger(__name__)

_BATCH = 64
_MAX_TOKENS = 7_500  # model limit is 8,192 tokens per input


def _estimated_tokens(text: str) -> float:
    """Rough token count: ~4 ASCII characters per token, ~1 token per non-ASCII character (CJK, accents)."""
    ascii_chars = sum(1 for ch in text if ord(ch) < 128)
    return ascii_chars / 4 + (len(text) - ascii_chars)


def _fit(text: str) -> str:
    """Trim an input so it stays under the embedding model's token limit (guards outliers only)."""
    if not text.strip():
        return " "
    if _estimated_tokens(text) <= _MAX_TOKENS:
        return text
    lo, hi = 0, len(text)
    while lo < hi:  # binary search the longest prefix that fits
        mid = (lo + hi + 1) // 2
        if _estimated_tokens(text[:mid]) <= _MAX_TOKENS:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo]


def azure_openai_client(settings: Settings) -> AzureOpenAI:
    return AzureOpenAI(
        azure_endpoint=settings.aoai.endpoint,
        api_key=settings.aoai.api_key,
        api_version=settings.aoai.api_version,
        timeout=120,
        max_retries=0,  # tenacity handles retries with longer back-off
    )


class EmbeddingService:
    def __init__(self, settings: Settings, client: AzureOpenAI | None = None) -> None:
        self._client = client or azure_openai_client(settings)
        self._deployment = settings.aoai.embedding_deployment
        self._dimensions = settings.aoai.embedding_dimensions
        self.total_tokens = 0

    @property
    def dimensions(self) -> int:
        return self._dimensions

    def embed(self, texts: list[str]) -> list[list[float]]:
        vectors: list[list[float]] = []
        for start in range(0, len(texts), _BATCH):
            batch = [_fit(t) for t in texts[start : start + _BATCH]]
            vectors.extend(self._embed_batch(batch))
        return vectors

    def embed_one(self, text: str) -> list[float]:
        return self.embed([text])[0]

    @retry(
        retry=retry_if_exception_type((RateLimitError, APIConnectionError, APITimeoutError, InternalServerError)),
        wait=wait_exponential(multiplier=2, min=2, max=60),
        stop=stop_after_attempt(6),
        reraise=True,
    )
    def _embed_batch(self, batch: list[str]) -> list[list[float]]:
        response = self._client.embeddings.create(model=self._deployment, input=batch, dimensions=self._dimensions)
        self.total_tokens += response.usage.total_tokens if response.usage else 0
        return [item.embedding for item in sorted(response.data, key=lambda d: d.index)]
