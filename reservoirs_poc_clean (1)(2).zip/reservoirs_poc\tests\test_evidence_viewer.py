import io
import threading

import pypdfium2 as pdfium
from PIL import Image

from app.services.evidence_viewer import PdfCache, find_boxes, page_count, page_words, pdf_page_words, render_page


def _text_pdf(lines: list[str]) -> bytes:
    """A one-page US-letter PDF with each line in 12 pt Helvetica, 20 pt apart, starting 72 pt from the top."""
    ops = "BT /F1 12 Tf 72 720 Td " + " ".join(f"({line}) Tj 0 -20 Td" for line in lines) + " ET"
    objects = [
        "<< /Type /Catalog /Pages 2 0 R >>",
        "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
        f"<< /Length {len(ops)} >>\nstream\n{ops}\nendstream",
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out, offsets = b"%PDF-1.4\n", []
    for n, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{n} 0 obj\n{body}\nendobj\n".encode()
    xref = len(out)
    out += f"xref\n0 {len(objects) + 1}\n0000000000 65535 f \n".encode()
    out += "".join(f"{o:010d} 00000 n \n" for o in offsets).encode()
    out += f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF".encode()
    return out


def _word(text, x, y):
    return {"content": text, "polygon": [x, y, x + 0.5, y, x + 0.5, y + 0.2, x, y + 0.2]}


LINE_1 = "El Campo Lago Agrio fue descubierto en abril de 1967".split()
LINE_2 = "Lago Agrio - 01 alcanzó 2955 BPPD".split()
PAGES = page_words([{"pages": [
    {"pageNumber": 1, "width": 8.5, "height": 11.0,
     "words": [_word(w, 0.5 + 0.6 * i, 1.0) for i, w in enumerate(LINE_1)] + [_word(w, 0.5 + 0.6 * i, 2.0) for i, w in enumerate(LINE_2)]},
    {"pageNumber": 2, "width": 8.5, "height": 11.0, "words": [_word("Otro", 1.0, 1.0)]},
]}])


def test_quote_words_are_found_accent_and_case_insensitive():
    boxes = find_boxes(PAGES, [1], "descubierto en ABRIL de 1967")
    assert len(boxes[1]) == 5 and boxes[1][0][1] == 1.0


def test_abridged_quote_highlights_each_part_only():
    boxes = find_boxes(PAGES, [1, 2], "El Campo Lago Agrio … alcanzó 2955 BPPD")
    ys = sorted({b[1] for b in boxes[1]})
    assert ys == [1.0, 2.0] and len(boxes[1]) == 4 + 3
    assert 2 not in boxes


def test_text_not_on_page_is_not_highlighted():
    assert find_boxes(PAGES, [1], "production started in 1975 from forty wells") == {}


def test_render_page_draws_highlight():
    doc = pdfium.PdfDocument.new()
    doc.new_page(612, 792)  # 8.5 x 11 in
    buffer = io.BytesIO()
    doc.save(buffer)
    pdf = buffer.getvalue()
    assert page_count(pdf) == 1

    plain = Image.open(io.BytesIO(render_page(pdf, 1, PAGES[1], [])))
    marked = Image.open(io.BytesIO(render_page(pdf, 1, PAGES[1], [(1.0, 1.0, 3.0, 1.2)])))
    x, y = int(2.0 * marked.width / 8.5), int(1.1 * marked.height / 11.0)
    assert plain.getpixel((x, y)) == (255, 255, 255)
    assert marked.getpixel((x, y)) != (255, 255, 255)


def test_text_layer_gives_word_boxes_from_the_top_left():
    pdf = _text_pdf(["Production commenced in May 1972", "with 24 producers"])
    page = pdf_page_words(pdf, [1])[1]
    assert (page["width"], page["height"]) == (612, 792)
    texts = [w for w, _ in page["words"]]
    assert texts == ["Production", "commenced", "in", "May", "1972", "with", "24", "producers"]
    first, second_line = page["words"][0][1], page["words"][5][1]
    assert 60 < first[1] < 72 < first[5] < 80  # baseline 72 pt from the top
    assert second_line[1] > first[1] + 15  # the next line is lower on the page
    boxes = find_boxes(pdf_page_words(pdf, [1]), [1], "May 1972 … with 24 producers")
    assert len(boxes[1]) == 5


def test_scanned_page_has_no_words():
    doc = pdfium.PdfDocument.new()
    doc.new_page(612, 792)
    buffer = io.BytesIO()
    doc.save(buffer)
    assert pdf_page_words(buffer.getvalue(), [1])[1]["words"] == []


def test_pdf_cache_prefetches_once_and_serves_from_memory():
    calls = []
    cache = PdfCache(lambda p: calls.append(p) or p.encode())
    cache.prefetch(["a.pdf", "b.pdf", "a.pdf"])
    assert cache.get("a.pdf") == b"a.pdf" and cache.get("b.pdf") == b"b.pdf"
    assert cache.get("a.pdf") == b"a.pdf" and cache.is_cached("a.pdf")
    assert sorted(calls) == ["a.pdf", "b.pdf"]


def test_pdf_cache_clicked_document_jumps_the_queue():
    release = threading.Event()
    started = []

    def download(path):
        started.append(path)
        if path == "slow.pdf":
            release.wait(5)
        return path.encode()

    cache = PdfCache(download, workers=1)
    cache.prefetch(["slow.pdf", "queued.pdf"])  # one worker: queued.pdf waits behind slow.pdf
    assert cache.get("queued.pdf") == b"queued.pdf"  # fetched now, not after slow.pdf
    release.set()
    assert cache.get("slow.pdf") == b"slow.pdf"
    assert started.count("queued.pdf") == 1


def test_pdf_cache_evicts_oldest_and_retries_failed_downloads():
    fail = {"bad.pdf": True}

    def download(path):
        if fail.pop(path, False):
            raise OSError("network")
        return b"x" * 10

    cache = PdfCache(download, max_bytes=25)
    for p in ("1.pdf", "2.pdf", "3.pdf"):
        cache.get(p)
    assert not cache.is_cached("1.pdf") and cache.is_cached("3.pdf")
    cache.prefetch(["bad.pdf"])
    try:
        cache.get("bad.pdf")
    except OSError:
        pass
    assert cache.get("bad.pdf") == b"x" * 10  # a failed prefetch does not stick
