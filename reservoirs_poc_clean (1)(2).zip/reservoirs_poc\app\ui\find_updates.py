from __future__ import annotations

from collections import Counter

import streamlit as st

from app.ui import common
from app.workflows.report_update_workflow import checked_sections, run_analysis


def _summary(run) -> None:
    by_type = Counter(r.change_type.value for r in run.recommendations)
    cols = st.columns(4)
    cols[0].metric("Suggestions", len(run.recommendations))
    cols[1].metric("Updates", by_type.get("update", 0))
    cols[2].metric("New information", by_type.get("new_information", 0))
    cols[3].metric("Conflicts", by_type.get("conflict", 0))
    finished = f"{run.finished_at:%Y-%m-%d %H:%M} UTC" if run.finished_at else "in progress / interrupted"
    st.caption(
        f"Run `{run.run_id[:8]}` · {run.sections_done}/{run.sections_total} sections · finished {finished} · "
        f"model {run.model} · {run.llm_calls} LLM calls, {run.llm_input_tokens + run.llm_output_tokens:,} tokens"
    )
    if run.errors:
        with st.expander(f"{len(run.errors)} section(s) failed", icon="⚠️"):
            for e in run.errors:
                st.write(e)
    if run.section_notes:
        with st.expander("Sections with no suggested changes"):
            for sid, note in run.section_notes.items():
                st.markdown(f"**{sid}** — {note}")


def render() -> None:
    st.header(f"{common.field_name()} — find updates")
    report = common.current_report()
    secs = common.sections(common.field_id(), report.report_id) if report else []
    if not secs:
        st.warning("Ingest this field first (see Overview).")
        return

    run = common.current_run()
    if run:
        _summary(run)
        st.divider()

    st.subheader("Check the whole report")
    st.caption(
        "Each section is compared with the New and previously Unused references. Conflicts are checked against "
        "the Key references the report cites. Nothing changes in the report until a reviewer approves it."
    )
    if st.button("Find updates", type="primary", disabled=not common.reviewer(), help=None if common.reviewer() else "Enter your name in the sidebar first"):
        _run(None, None, None)

    if run:
        st.divider()
        st.subheader("Re-check one section")
        st.caption("Ask the assistant to look again at one section, optionally with a focus. Replaces that section's suggestions in the current run.")
        targets = checked_sections(secs)
        section = st.selectbox("Section", targets, format_func=lambda s: f"{s.section_id} {s.title}")
        instruction = st.text_input("Focus (optional)", placeholder="e.g. latest production rates and well count after 2016")
        if st.button("Re-check section", disabled=not common.reviewer()):
            _run([section.section_id], instruction or None, run)


def _run(section_ids, instruction, base_run) -> None:
    total = len(section_ids) if section_ids else len(checked_sections(common.sections(common.field_id(), common.current_report().report_id)))
    bar = st.progress(0.0, text="Starting…")
    with st.status("Analysing report sections…", expanded=True) as status:
        def progress(section_id: str, done: int, total_: int) -> None:
            bar.progress(done / max(total_, 1), text=f"{done}/{total_} sections")
            st.write(f"Section {section_id} done")

        run = run_analysis(
            common.field_name(),
            section_ids=section_ids,
            instruction=instruction,
            base_run=base_run,
            services=common.services(),
            progress=progress,
        )
        status.update(label=f"Done — {len(run.recommendations)} suggestions across {total} section(s)", state="complete")
    common.set_run(run)
    st.rerun()
