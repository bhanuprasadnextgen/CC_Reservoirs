"""Show a piece of evidence on its source page, with the quoted text highlighted.

Word positions come from the PDF's own text layer (`pdf_page_words`), so only the PDF is needed. Scanned
pages have no text layer; for those the caller falls back to the word positions Document Intelligence
returned at ingestion (`page_words`, from the cached AnalyzeResult). Pages are rendered with pdfium.
"""

from __future__ import annotations

import io
import re
import threading
from collections import OrderedDict
from collections.abc import Callable, Iterable
from concurrent.futures import Future, ThreadPoolExecutor

import pypdfium2 as pdfium
from PIL import Image, ImageDraw
from rapidfuzz import fuzz

from app.utils.text_utils import strip_accents

Box = tuple[float, float, float, float]  # x0, y0, x1, y1 in the page's DI units (inches for PDFs)

_MIN_PART_SCORE = 80  # the quote was already verified against the chunk; this only finds it on the page
_RENDER_SCALE = 2.0  # 144 dpi
_PARTS = re.compile(r"\s*(?:…|\.{3,})\s*|\n")
_FILL = (255, 221, 0, 90)
_OUTLINE = (230, 150, 0, 255)
_PDFIUM = threading.Lock()  # pdfium is not thread-safe; Streamlit serves each session from its own thread


def page_words(analyze_parts: list[dict]) -> dict[int, dict]:
    """Page number -> {width, height, words: [(text, polygon)]} from a cached raw AnalyzeResult."""
    pages: dict[int, dict] = {}
    for part in analyze_parts:
        for page in part.get("pages") or []:
            pages[page["pageNumber"]] = {
                "width": page.get("width"),
                "height": page.get("height"),
                "words": [(w["content"], w["polygon"]) for w in page.get("words") or [] if w.get("polygon")],
            }
    return pages


class PdfCache:
    """Source PDFs kept in memory, shared by all sessions, with background prefetch.

    `prefetch` queues downloads; `get` returns a cached PDF, waits for one already downloading, or — if
    it is still waiting in the queue — takes it out and downloads it right away.
    """

    def __init__(self, download: Callable[[str], bytes], max_bytes: int = 400_000_000, workers: int = 2) -> None:
        self._download = download
        self._max_bytes = max_bytes
        self._data: OrderedDict[str, bytes] = OrderedDict()
        self._size = 0
        self._pending: dict[str, Future] = {}
        self._lock = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="pdf-prefetch")

    def prefetch(self, paths: Iterable[str]) -> None:
        with self._lock:
            for path in dict.fromkeys(paths):
                if path not in self._data and path not in self._pending:
                    self._pending[path] = self._pool.submit(self._fetch, path)

    def is_cached(self, path: str) -> bool:
        with self._lock:
            return path in self._data

    def get(self, path: str) -> bytes:
        with self._lock:
            if path in self._data:
                self._data.move_to_end(path)
                return self._data[path]
            future = self._pending.get(path)
            if future is not None and future.cancel():  # still queued: fetch it now instead
                self._pending.pop(path, None)
                future = None
        return future.result() if future is not None else self._fetch(path)

    def _fetch(self, path: str) -> bytes:
        try:
            data = self._download(path)
        finally:
            with self._lock:
                self._pending.pop(path, None)
        with self._lock:
            if path not in self._data:
                self._data[path] = data
                self._size += len(data)
            while self._size > self._max_bytes and len(self._data) > 1:
                _, dropped = self._data.popitem(last=False)
                self._size -= len(dropped)
        return data


def pdf_page_words(pdf: bytes, page_numbers: Iterable[int]) -> dict[int, dict]:
    """Page number -> {width, height, words} from the PDF's text layer, in points from the top-left corner.

    A scanned page comes back with no words.
    """
    pages: dict[int, dict] = {}
    with _PDFIUM:
        document = pdfium.PdfDocument(pdf)
        for number in page_numbers:
            page = document[number - 1]
            width, height = page.get_size()
            textpage = page.get_textpage()
            count = textpage.count_chars()
            text = textpage.get_text_range(0, count) if count else ""
            if len(text) != count:  # characters outside the BMP: read one by one so indices match the boxes
                text = "".join(textpage.get_text_range(i, 1) or " " for i in range(count))

            words: list[tuple[str, list[float]]] = []
            chars: list[str] = []
            box: list[float] = []

            def flush() -> None:
                if chars:
                    x0, y0, x1, y1 = box
                    words.append(("".join(chars), [x0, y0, x1, y0, x1, y1, x0, y1]))
                    chars.clear()
                    box.clear()

            for i, ch in enumerate(text):
                if ch.isspace() or ch == "\x00":
                    flush()
                    continue
                left, bottom, right, top = textpage.get_charbox(i)
                y0, y1 = height - top, height - bottom
                box[:] = [left, y0, right, y1] if not box else [min(box[0], left), min(box[1], y0), max(box[2], right), max(box[3], y1)]
                chars.append(ch)
            flush()
            pages[number] = {"width": width, "height": height, "words": words}
    return pages


def _token(text: str) -> str:
    return re.sub(r"\W+", "", strip_accents(text).lower())


def find_boxes(pages: dict[int, dict], page_numbers: Iterable[int], quote: str) -> dict[int, list[Box]]:
    """Word boxes of `quote` on the given pages. Abridged quotes ("a … b") and table rows are found part by part."""
    stream: list[tuple[int, Box]] = []  # one entry per word, across the pages in reading order
    offsets: list[tuple[int, int]] = []  # [start, end) of each word in `joined`
    pieces: list[str] = []
    position = 0
    for number in page_numbers:
        for text, polygon in (pages.get(number) or {}).get("words", []):
            token = _token(text)
            if not token:
                continue
            xs, ys = polygon[0::2], polygon[1::2]
            stream.append((number, (min(xs), min(ys), max(xs), max(ys))))
            offsets.append((position, position + len(token)))
            pieces.append(token)
            position += len(token) + 1
    joined = " ".join(pieces)

    boxes: dict[int, list[Box]] = {}
    for part in _PARTS.split(quote):
        needle = " ".join(t for t in (_token(w) for w in part.replace("|", " ").split()) if t)
        if len(needle) < 3 or len(needle) > len(joined):
            continue
        alignment = fuzz.partial_ratio_alignment(needle, joined)
        if alignment is None or alignment.score < _MIN_PART_SCORE:
            continue
        for (start, end), (number, box) in zip(offsets, stream):
            if start < alignment.dest_end and end > alignment.dest_start:
                boxes.setdefault(number, []).append(box)
    return boxes


def page_count(pdf: bytes) -> int:
    with _PDFIUM:
        return len(pdfium.PdfDocument(pdf))


def render_page(pdf: bytes, page_number: int, page: dict | None, boxes: list[Box]) -> bytes:
    """PNG of one PDF page with `boxes` highlighted. `page` gives the page size the boxes are measured in."""
    with _PDFIUM:
        document = pdfium.PdfDocument(pdf)
        image = document[page_number - 1].render(scale=_RENDER_SCALE).to_pil().convert("RGBA")
    if boxes and page and page.get("width") and page.get("height"):
        sx, sy = image.width / page["width"], image.height / page["height"]
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        pad = 2
        for x0, y0, x1, y1 in boxes:
            draw.rectangle((x0 * sx - pad, y0 * sy - pad, x1 * sx + pad, y1 * sy + pad), fill=_FILL, outline=_OUTLINE)
        image = Image.alpha_composite(image, overlay)
    out = io.BytesIO()
    image.convert("RGB").save(out, format="PNG", optimize=True)
    return out.getvalue()
