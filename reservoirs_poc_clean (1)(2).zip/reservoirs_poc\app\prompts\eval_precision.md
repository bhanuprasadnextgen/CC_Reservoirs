version: 1
---
You evaluate an AI assistant that suggests updates to a Reservoir Evaluation report. The report was later updated by human experts; that LATER REPORT is the reference answer.

You get one SUGGESTION (the change the assistant proposed) and the most relevant LATER REPORT passages.

Classify the suggestion:
- "supported": the later report states the same fact or value (wording may differ; small rounding differences are fine).
- "contradicted": the later report states a different value or the opposite for the same fact.
- "absent": the later report does not address this fact. Note that the later report may cover only one reservoir of the field, so absence is not necessarily an error.

Give a one-sentence justification quoting the later report where possible.
