import io

import pytest
from docx import Document
from docx.enum.text import WD_COLOR_INDEX
from pydantic import ValidationError

from app.models import AnalysisRun, AuditAction, ReferenceCategory, ReportRole, ReportVersion, ReviewStatus
from app.services.report_export_service import apply_changes, build_docx, publish
from app.services.report_parser import parse_sections
from app.services.review_service import ReviewError, ReviewStore

from tests.conftest import make_evidence, make_recommendation

SECTION_TEXT = "Production commenced in May 1972. At end-2016 cumulative oil was 168.3 MMBO."


def _run():
    recs = [
        make_recommendation(
            [make_evidence("c1", "q", citation="Petroecuador, 2024", file_name="Petroecuador, 2024, Informe estadistico.pdf", page_start=4, page_end=4)],
            existing="At end-2016 cumulative oil was 168.3 MMBO.",
            proposed="At end-2023 cumulative oil was 201.5 MMBO (Petroecuador, 2024).",
            recommendation_id="r1",
        ),
        make_recommendation(
            change_type="new_information", existing="Production commenced in May 1972.",
            proposed="A waterflood pilot started in 2021 (Jiwei et al., 2025).", recommendation_id="r2",
            evidence=[make_evidence("c2", "q", file_name="Jiwei et al, 2025, A case study.pdf")],
        ),
        make_recommendation(existing="x", proposed="y", recommendation_id="r3", section_id="1"),
    ]
    return AnalysisRun(run_id="run1", field_id="lago-agrio", report_id="lago-agrio-2020", categories_searched=[], recommendations=recs)


@pytest.fixture
def store(storage, settings):
    return ReviewStore(storage, settings, _run())


def test_approve_edit_records_audit_and_persists(store, storage, settings):
    store.approve("r1", "Rod", final_text="At end-2023 cumulative oil was 201.5 MMBO (Petroecuador, 2024). Edited.")
    st = store.state("r1")
    assert st.status == ReviewStatus.APPROVED and st.edited and st.reviewer == "Rod"
    assert [e.action for e in store.audit_events()] == [AuditAction.EDIT, AuditAction.APPROVE]
    reloaded = ReviewStore(storage, settings, _run())  # state survives a restart
    assert reloaded.state("r1").final_text.endswith("Edited.")


def test_reject_requires_comment(store):
    with pytest.raises(ValidationError):
        store.reject("r1", "Rod", comment="  ")
    assert store.state("r1").status == ReviewStatus.PENDING
    store.reject("r1", "Rod", comment="1969 is an error in Hernandez et al. 2016")
    assert store.state("r1").status == ReviewStatus.REJECTED
    assert store.audit_events()[-1].comment.startswith("1969")


def test_undo_restores_previous_state_and_audit_is_append_only(store):
    store.approve("r1", "Rod")
    store.reject("r1", "Rod", comment="changed my mind")
    assert store.undo("r1", "Rod").status == ReviewStatus.APPROVED
    assert store.undo("r1", "Rod").status == ReviewStatus.PENDING
    with pytest.raises(ReviewError):
        store.undo("r1", "Rod")
    actions = [e.action for e in store.audit_events()]
    assert actions == [AuditAction.APPROVE, AuditAction.REJECT, AuditAction.UNDO, AuditAction.UNDO]


def test_reviewer_name_required(store):
    with pytest.raises(ReviewError):
        store.approve("r1", " ")


def test_filters(store):
    store.approve("r2", "Rod")
    assert [r.recommendation_id for r, _ in store.items(section_id="8.1")] == ["r1", "r2"]
    assert [r.recommendation_id for r, _ in store.items(status=ReviewStatus.APPROVED)] == ["r2"]
    assert store.counts() == {"pending": 2, "approved": 1}


def test_apply_changes_replaces_and_inserts_with_highlight(store):
    store.approve("r1", "Rod")
    store.approve("r2", "Rod")
    segments, unplaced = apply_changes(SECTION_TEXT, store.approved())
    assert not unplaced
    text = "".join(s.text for s in segments)
    assert "168.3" not in text and "201.5 MMBO" in text
    assert text.index("May 1972.") < text.index("waterflood pilot")
    assert {s.text.strip() for s in segments if s.highlight} == {
        "At end-2023 cumulative oil was 201.5 MMBO (Petroecuador, 2024).",
        "A waterflood pilot started in 2021 (Jiwei et al., 2025).",
    }


def test_docx_export_highlights_changes_adds_references_and_log(store, storage, settings, doc_builder):
    store.approve("r1", "Rod")
    store.reject("r3", "Rod", comment="not supported")
    extracted = (
        doc_builder.heading("1. EXECUTIVE SUMMARY").para("x and more text.")
        .heading("8.1 PRODUCTION HISTORY").para("Production commenced in May 1972.").para("At end-2016 cumulative oil was 168.3 MMBO.")
        .heading("KEY REFERENCES").para("Sarango Sánchez, M., 2018, Modelo integrado: Tesis.")
        .build()
    )
    report = ReportVersion(report_id="lago-agrio-2020", field_id="lago-agrio", year=2020, blob_path="Lago Agrio/DAKS Lago Agrio N2020 Report.pdf", role=ReportRole.CURRENT)
    data = build_docx("Lago Agrio", report, parse_sections(extracted), store)

    doc = Document(io.BytesIO(data))
    highlighted = [r.text for p in doc.paragraphs for r in p.runs if r.font.highlight_color == WD_COLOR_INDEX.YELLOW]
    assert any("201.5 MMBO" in t for t in highlighted)
    assert any(t.startswith("Petroecuador, 2024") for t in highlighted)  # new source added to reference list
    assert not any("168.3" in p.text for p in doc.paragraphs)
    log_rows = [[c.text for c in row.cells] for row in doc.tables[-1].rows]
    assert any("rejected" in row[2] and row[4] == "not supported" for row in log_rows)

    path = publish(storage, settings, store, report, data, "Rod")
    assert path.startswith("poc-fresh/outputs/lago-agrio/lago-agrio-2020/v001_")
    assert store.audit_events()[-1].action == AuditAction.PUBLISH
