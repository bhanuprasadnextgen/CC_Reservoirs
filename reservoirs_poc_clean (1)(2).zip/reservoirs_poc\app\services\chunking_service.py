"""Layout-aware, section-based chunking.

1. Sections come from the document layout: the report's numbered sections, or Document Intelligence
   headings for reference documents. A chunk never crosses a section boundary.
2. Inside a section, whole paragraphs are packed up to ~CHUNK_WORDS. A paragraph that does not fit
   is added sentence by sentence; sentences are never cut (except pathological >limit run-ons).
3. Consecutive chunks share ~CHUNK_OVERLAP_WORDS of trailing sentences.
4. Tables are separate chunks in markdown; long tables are split by rows with the header repeated.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from app.config import ChunkingSettings
from app.models import (
    Chunk,
    ExtractedDocument,
    ExtractedParagraph,
    ExtractedTable,
    ReportSection,
    SectionKind,
    SourceDocument,
)
from app.utils.text_utils import detect_language, detect_language_or_none, split_sentences, word_count

_HEADING_ROLES = {"sectionHeading", "title"}
_MIN_TAIL_WORDS = 40  # a final chunk adding fewer new words than this is folded into the previous one
_TAIL_FOLD_ALLOWANCE = 1.2  # …as is one whose merge keeps the previous chunk within 120% of the limit


@dataclass
class _Sentence:
    text: str
    page: int
    paragraph: int  # index of the source paragraph inside the section
    words: int


@dataclass
class _Section:
    section_id: str | None
    title: str | None
    paragraphs: list[ExtractedParagraph] = field(default_factory=list)
    tables: list[ExtractedTable] = field(default_factory=list)


def chunk_document(
    extracted: ExtractedDocument,
    doc: SourceDocument,
    settings: ChunkingSettings,
    report_sections: list[ReportSection] | None = None,
) -> list[Chunk]:
    """Chunk one document. Pass `report_sections` for the RE report so chunks follow its numbering."""
    doc_language = doc.language or detect_language(extracted.text)
    if report_sections is not None:
        sections = [
            _Section(s.section_id, s.title, list(s.paragraphs), list(s.tables))
            for s in report_sections
            if s.kind in (SectionKind.BODY, SectionKind.TABLES) and s.text.strip()
        ]
    else:
        sections = _sections_from_layout(extracted)

    chunks: list[Chunk] = []

    def emit(content: str, section: _Section, page_start: int, page_end: int) -> None:
        chunks.append(
            Chunk(
                chunk_id=f"{doc.document_id}-{len(chunks):05d}",
                document_id=doc.document_id,
                field_id=doc.field_id,
                field_name=doc.field_name,
                reservoir_id=doc.reservoir_id,
                report_id=doc.report_id,
                category=doc.category,
                file_name=doc.file_name,
                citation=doc.citation,
                publication_year=doc.publication_year,
                # Per passage (English abstracts sit inside Spanish theses); short or unclear text such as
                # table rows takes the document's language. Always "en" or "es".
                language=detect_language_or_none(content) or doc_language,
                section_id=section.section_id,
                section_title=section.title,
                page_start=page_start,
                page_end=page_end,
                chunk_index=len(chunks),
                content=content,
            )
        )

    for section in sections:
        for content, p_start, p_end in _pack_paragraphs(section.paragraphs, settings):
            emit(content, section, p_start, p_end)
        for table in section.tables:
            for content in _split_table(table, settings.words):
                emit(content, section, table.page_start, table.page_end)
    return chunks


def embedding_text(chunk: Chunk) -> str:
    """Contextual header + content. Sent to the embedding model only; `content` stays raw for quoting."""
    header = " | ".join(
        part
        for part in (
            f"Field: {chunk.field_name}",
            f"Source: {chunk.citation}" if chunk.citation else "",
            f"Section: {chunk.section_title}" if chunk.section_title else "",
        )
        if part
    )
    return f"{header}\n{chunk.content}"


# ----------------------------------------------------------------- section building


def _sections_from_layout(extracted: ExtractedDocument) -> list[_Section]:
    """Reference documents: every DI heading opens a new section; text before the first heading is its own."""
    items: list[tuple[int, ExtractedParagraph | ExtractedTable]] = [(p.offset, p) for p in extracted.paragraphs]
    items += [(t.offset, t) for t in extracted.tables]
    items.sort(key=lambda pair: pair[0])

    sections = [_Section(section_id="s0", title=None)]
    for _, item in items:
        if isinstance(item, ExtractedTable):
            sections[-1].tables.append(item)
        elif item.role in _HEADING_ROLES and word_count(item.text) <= 25:
            sections.append(_Section(section_id=f"s{len(sections)}", title=item.text.strip()))
        else:
            sections[-1].paragraphs.append(item)
    return [s for s in sections if s.paragraphs or s.tables]


# ------------------------------------------------------------------- prose packing


_CHARS_PER_WORD = 6  # size estimate for text without spaces (e.g. Chinese), where split() sees one "word"


def _size(text: str) -> int:
    """Chunk-size units: words, or characters/6 for unspaced scripts — whichever is larger."""
    return max(len(text.split()), len(text) // _CHARS_PER_WORD)


def _to_sentences(paragraphs: list[ExtractedParagraph], limit: int) -> list[_Sentence]:
    out: list[_Sentence] = []
    for i, p in enumerate(paragraphs):
        for sentence in split_sentences(p.text) or [p.text]:
            # A run-on longer than the chunk limit (OCR noise, lists without punctuation, unspaced
            # Chinese text) is hard-split: by words when there are spaces, else by characters.
            words = sentence.split()
            if len(words) > 1 and len(words) >= _size(sentence) // 2:
                pieces = [" ".join(words[k : k + limit]) for k in range(0, len(words), limit)]
            else:
                step = limit * _CHARS_PER_WORD
                pieces = [sentence[k : k + step] for k in range(0, len(sentence), step)]
            out.extend(_Sentence(piece, p.page, i, _size(piece)) for piece in pieces if piece.strip())
    return out


def _render(sentences: list[_Sentence]) -> str:
    """Sentences of the same paragraph joined by spaces; paragraphs separated by blank lines."""
    parts: list[str] = []
    for i, s in enumerate(sentences):
        if i and s.paragraph != sentences[i - 1].paragraph:
            parts.append("\n\n")
        elif i:
            parts.append(" ")
        parts.append(s.text)
    return "".join(parts)


def _pack_paragraphs(paragraphs: list[ExtractedParagraph], settings: ChunkingSettings) -> list[tuple[str, int, int]]:
    limit, overlap = settings.words, settings.overlap_words
    sentences = _to_sentences(paragraphs, limit)
    if not sentences:
        return []

    groups: list[list[_Sentence]] = []
    fresh_counts: list[int] = []  # words in each group that are not overlap
    current: list[_Sentence] = []
    current_words = 0
    fresh = 0  # sentences in `current` that are not overlap carried from the previous chunk

    def paragraph_words(index: int) -> int:
        para = sentences[index].paragraph
        return sum(s.words for s in sentences[index:] if s.paragraph == para)

    i = 0
    while i < len(sentences):
        s = sentences[i]
        starts_paragraph = i == 0 or sentences[i - 1].paragraph != s.paragraph
        # Prefer breaking at a paragraph boundary when the whole next paragraph won't fit
        # and the current chunk is already reasonably full.
        if (
            fresh
            and starts_paragraph
            and current_words + paragraph_words(i) > limit
            and current_words >= limit // 2
        ) or (fresh and current_words + s.words > limit):
            groups.append(current)
            fresh_counts.append(sum(x.words for x in current[len(current) - fresh :]))
            current = _overlap_tail(current, overlap)
            current_words = sum(x.words for x in current)
            fresh = 0
            continue
        current.append(s)
        current_words += s.words
        fresh += 1
        i += 1
    if fresh:
        groups.append(current)
        fresh_counts.append(sum(x.words for x in current[len(current) - fresh :]))

    # Fold a trailing chunk that adds little beyond its overlap into its predecessor.
    if len(groups) > 1 and (
        fresh_counts[-1] < _MIN_TAIL_WORDS
        or sum(x.words for x in groups[-2]) + fresh_counts[-1] <= limit * _TAIL_FOLD_ALLOWANCE
    ):
        tail = groups.pop()
        prev = groups[-1]
        groups[-1] = prev + [s for s in tail if all(s is not q for q in prev)]

    return [(_render(g), min(s.page for s in g), max(s.page for s in g)) for g in groups]


def _overlap_tail(sentences: list[_Sentence], overlap: int) -> list[_Sentence]:
    """Trailing whole sentences totalling at most `overlap` words."""
    tail: list[_Sentence] = []
    total = 0
    for s in reversed(sentences):
        if total + s.words > overlap:
            break
        tail.insert(0, s)
        total += s.words
    return tail


# -------------------------------------------------------------------------- tables


def _split_table(table: ExtractedTable, limit: int) -> list[str]:
    """Whole table if it fits, else row groups each carrying the caption and header."""
    if word_count(table.markdown) <= limit or not table.rows:
        return [table.markdown]
    prefix = f"Table: {table.caption}\n" if table.caption else ""
    budget = max(limit - word_count(prefix + table.header), 20)

    pieces: list[list[str]] = []
    rows: list[str] = []
    words = 0
    for row in table.rows:
        row_words = word_count(row)
        if rows and words + row_words > budget:
            pieces.append(rows)
            rows, words = [], 0
        rows.append(row)
        words += row_words
    if rows:
        pieces.append(rows)

    total = len(pieces)
    return [
        f"{prefix}(part {n} of {total})\n{table.header}\n" + "\n".join(group) for n, group in enumerate(pieces, start=1)
    ]
